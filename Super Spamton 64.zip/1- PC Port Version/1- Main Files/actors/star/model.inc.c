Gfx star_star_surface_rgba16_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 star_star_surface_rgba16_rgba16[] = {
	#include "actors/star/star_surface.rgba16.inc.c"
};

Gfx star_star_eye_rgba16_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 star_star_eye_rgba16_rgba16[] = {
	#include "actors/star/star_eye.rgba16.inc.c"
};

Vtx star_000_displaylist_mesh_layer_1_vtx_0[27] = {
	{{{-36, -19, 42},0, {-16, 1008},{0xAD, 0xA1, 0xF2, 0xFF}}},
	{{{-1, -27, 53},0, {1008, 1008},{0x20, 0x9B, 0x46, 0xFF}}},
	{{{-124, 33, 197},0, {496, 496},{0xB5, 0x18, 0x64, 0xFF}}},
	{{{6, 20, 69},0, {1008, -16},{0x56, 0x2E, 0x52, 0xFF}}},
	{{{-35, 17, 53},0, {-16, -16},{0xB8, 0x5A, 0xCA, 0xFF}}},
	{{{0, 8, -89},0, {-16, -16},{0x0, 0x2, 0x81, 0xFF}}},
	{{{190, -201, 0},0, {-16, -16},{0x56, 0xA2, 0x3, 0xFF}}},
	{{{0, -129, 0},0, {-16, -16},{0x0, 0x81, 0xA, 0xFF}}},
	{{{146, -42, 0},0, {-16, -16},{0x7D, 0xEA, 0xB, 0xFF}}},
	{{{257, 84, 0},0, {-16, -16},{0x78, 0x2B, 0x3, 0xFF}}},
	{{{96, 99, 0},0, {-16, -16},{0x36, 0x73, 0xB, 0xFF}}},
	{{{0, 246, 0},0, {-16, -16},{0x0, 0x7F, 0x4, 0xFF}}},
	{{{-95, 99, 0},0, {-16, -16},{0xC9, 0x72, 0xB, 0xFF}}},
	{{{-256, 84, 0},0, {-16, -16},{0x88, 0x2B, 0x3, 0xFF}}},
	{{{-145, -42, 0},0, {-16, -16},{0x83, 0xEA, 0xB, 0xFF}}},
	{{{-189, -201, 0},0, {-16, -16},{0xAA, 0xA2, 0x3, 0xFF}}},
	{{{-189, -201, 0},0, {-16, -16},{0xAA, 0xA2, 0x3, 0xFF}}},
	{{{0, -129, 0},0, {-16, -16},{0x0, 0x81, 0xA, 0xFF}}},
	{{{0, 8, 65},0, {-16, -16},{0x0, 0x2, 0x7F, 0xFF}}},
	{{{190, -201, 0},0, {-16, -16},{0x56, 0xA2, 0x3, 0xFF}}},
	{{{146, -42, 0},0, {-16, -16},{0x7D, 0xEA, 0xB, 0xFF}}},
	{{{257, 84, 0},0, {-16, -16},{0x78, 0x2B, 0x3, 0xFF}}},
	{{{96, 99, 0},0, {-16, -16},{0x36, 0x73, 0xB, 0xFF}}},
	{{{0, 246, 0},0, {-16, -16},{0x0, 0x7F, 0x4, 0xFF}}},
	{{{-95, 99, 0},0, {-16, -16},{0xC9, 0x72, 0xB, 0xFF}}},
	{{{-256, 84, 0},0, {-16, -16},{0x88, 0x2B, 0x3, 0xFF}}},
	{{{-145, -42, 0},0, {-16, -16},{0x83, 0xEA, 0xB, 0xFF}}},
};

Gfx star_000_displaylist_mesh_layer_1_tri_0[] = {
	gsSPVertex(star_000_displaylist_mesh_layer_1_vtx_0 + 0, 16, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSP1Triangle(1, 3, 2, 0),
	gsSP1Triangle(3, 4, 2, 0),
	gsSP1Triangle(4, 0, 2, 0),
	gsSP1Triangle(5, 6, 7, 0),
	gsSP1Triangle(5, 8, 6, 0),
	gsSP1Triangle(9, 8, 5, 0),
	gsSP1Triangle(10, 9, 5, 0),
	gsSP1Triangle(10, 5, 11, 0),
	gsSP1Triangle(5, 12, 11, 0),
	gsSP1Triangle(5, 13, 12, 0),
	gsSP1Triangle(5, 14, 13, 0),
	gsSP1Triangle(5, 15, 14, 0),
	gsSP1Triangle(5, 7, 15, 0),
	gsSPVertex(star_000_displaylist_mesh_layer_1_vtx_0 + 16, 11, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSP1Triangle(1, 3, 2, 0),
	gsSP1Triangle(3, 4, 2, 0),
	gsSP1Triangle(2, 4, 5, 0),
	gsSP1Triangle(2, 5, 6, 0),
	gsSP1Triangle(7, 2, 6, 0),
	gsSP1Triangle(7, 8, 2, 0),
	gsSP1Triangle(8, 9, 2, 0),
	gsSP1Triangle(9, 10, 2, 0),
	gsSP1Triangle(10, 0, 2, 0),
	gsSPEndDisplayList(),
};

Vtx star_001_displaylist_mesh_layer_4_vtx_0[8] = {
	{{{60, -71, 41},0, {1024, 1024},{0x6, 0xD7, 0x78, 0xFF}}},
	{{{-85, 11, 76},0, {0, 527},{0xB, 0xE1, 0x7B, 0xFF}}},
	{{{-85, -71, 62},0, {0, 1024},{0x12, 0xEB, 0x7C, 0xFF}}},
	{{{60, 11, 76},0, {1024, 527},{0x0, 0xCE, 0x75, 0xFF}}},
	{{{68, 9, 73},0, {1024, 508},{0x0, 0x24, 0x7A, 0xFF}}},
	{{{68, 97, 47},0, {1024, 0},{0x0, 0x24, 0x7A, 0xFF}}},
	{{{-67, 97, 47},0, {0, 0},{0x0, 0x24, 0x7A, 0xFF}}},
	{{{-67, 9, 73},0, {0, 508},{0x0, 0x24, 0x7A, 0xFF}}},
};

Gfx star_001_displaylist_mesh_layer_4_tri_0[] = {
	gsSPVertex(star_001_displaylist_mesh_layer_4_vtx_0 + 0, 8, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSP1Triangle(0, 3, 1, 0),
	gsSP1Triangle(4, 5, 6, 0),
	gsSP1Triangle(4, 6, 7, 0),
	gsSPEndDisplayList(),
};


Gfx mat_star_star_main[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, ENVIRONMENT, 0, 0, 0, TEXEL0, 0, 0, 0, ENVIRONMENT),
	gsSPSetGeometryMode(G_TEXTURE_GEN),
	gsSPTexture(1983, 1983, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, star_star_surface_rgba16_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_star_star_main[] = {
	gsDPPipeSync(),
	gsSPClearGeometryMode(G_TEXTURE_GEN),
	gsSPEndDisplayList(),
};

Gfx mat_star_star_eye[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
	gsSPClearGeometryMode(G_CULL_BACK),
	gsDPSetTextureConvert(G_TC_CONV),
	gsDPSetTextureFilter(G_TF_POINT),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, star_star_eye_rgba16_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_star_star_eye[] = {
	gsDPPipeSync(),
	gsSPSetGeometryMode(G_CULL_BACK),
	gsDPSetTextureConvert(G_TC_FILT),
	gsDPSetTextureFilter(G_TF_BILERP),
	gsSPEndDisplayList(),
};

Gfx star_000_displaylist_mesh_layer_1[] = {
	gsSPDisplayList(mat_star_star_main),
	gsSPDisplayList(star_000_displaylist_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_star_star_main),
	gsSPEndDisplayList(),
};

Gfx star_001_displaylist_mesh_layer_4[] = {
	gsSPDisplayList(mat_star_star_eye),
	gsSPDisplayList(star_001_displaylist_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_star_star_eye),
	gsSPEndDisplayList(),
};

Gfx star_material_revert_render_settings[] = {
	gsDPPipeSync(),
	gsSPSetGeometryMode(G_LIGHTING),
	gsSPClearGeometryMode(G_TEXTURE_GEN),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPSetEnvColor(255, 255, 255, 255),
	gsDPSetAlphaCompare(G_AC_NONE),
	gsSPEndDisplayList(),
};

