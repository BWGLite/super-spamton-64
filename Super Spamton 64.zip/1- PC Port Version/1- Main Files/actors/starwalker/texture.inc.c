Gfx starwalker_walk_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 starwalker_walk_rgba16[] = {
	#include "actors/toad/walk.rgba16.inc.c"
};

Gfx starwalker_walkeye_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 starwalker_walkeye_rgba16[] = {
	#include "actors/toad/walkeye.rgba16.inc.c"
};

