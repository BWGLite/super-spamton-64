// 0x0501C41C
const struct Animation *const peach_seg5_anims_0501C41C[] = {
    &peach_seg5_anim_0500C638,
    &peach_seg5_anim_0500E6B4,
    &peach_seg5_anim_0500ED94,
    &peach_seg5_anim_0500F474,
    &peach_seg5_anim_0500FE84,
    &peach_seg5_anim_05011050,
    &peach_seg5_anim_05012F40,
    &peach_seg5_anim_05015468,
    &peach_seg5_anim_05016798,
    &peach_seg5_anim_05018664,
	&peach_anim_lean_kiss,
    &peach_seg5_anim_0501C404,
    NULL,
};
