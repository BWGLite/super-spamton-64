#ifndef INTRO_HEADER_H
#define INTRO_HEADER_H

#include "types.h"

// geo
extern const GeoLayout intro_geo_0002D0[];
extern const GeoLayout intro_geo_00035C[];
extern const GeoLayout intro_geo_0003B8[];
extern const GeoLayout intro_geo_000414[];

// leveldata
extern Lights1 SPAM_Blu_Gran_f3d_lights;
extern Lights1 SPAM_Dark_Blue_f3d_lights;
extern Lights1 SPAM_Dark_Green_f3d_lights;
extern Lights1 SPAM_Grn_Gran_f3d_lights;
extern Lights1 SPAM_Dark_Red_f3d_lights;
extern Lights1 SPAM_Red_Gran_f3d_lights;
extern Lights1 SPAM_Dark_Yellow_f3d_lights;
extern Lights1 SPAM_Yel_Gran_f3d_lights;
extern Lights1 SPAM_Wood_f3d_lights;
extern Lights1 SPAM_Brn_Gran_f3d_lights;
extern Lights1 SPAM_Red_Flat_f3d_lights;
extern Lights1 SPAM_Yellow_Flat_f3d_lights;
extern Lights1 SPAM_Pnk_Gran_f3d_lights;
extern Lights1 SPAM_Dark_Pink_f3d_lights;
extern u8 SPAM_Granite_Blue_rgba16[];
extern u8 SPAM_DarkGran_Blue_rgba16[];
extern u8 SPAM_DarkGran_Green_rgba16[];
extern u8 SPAM_Granite_Green_rgba16[];
extern u8 SPAM_DarkGran_Red_rgba16[];
extern u8 SPAM_Granite_red_rgba16[];
extern u8 SPAM_DarkGran_Yellow_rgba16[];
extern u8 SPAM_Granite_Yellow_rgba16[];
extern u8 SPAM_Wood_rgba16[];
extern u8 SPAM_Granite_Brown_rgba16[];
extern u8 SPAM_Flat_Red_rgba16[];
extern u8 SPAM_Flat_Yellow_rgba16[];
extern u8 SPAM_Granite_Pink_rgba16[];
extern u8 SPAM_DarkGran_Piink_rgba16[];
extern Vtx SPAM_SPAM_mesh_vtx_0[45];
extern Gfx SPAM_SPAM_mesh_tri_0[];
extern Vtx SPAM_SPAM_mesh_vtx_1[124];
extern Gfx SPAM_SPAM_mesh_tri_1[];
extern Vtx SPAM_SPAM_mesh_vtx_2[81];
extern Gfx SPAM_SPAM_mesh_tri_2[];
extern Vtx SPAM_SPAM_mesh_vtx_3[35];
extern Gfx SPAM_SPAM_mesh_tri_3[];
extern Vtx SPAM_SPAM_mesh_vtx_4[70];
extern Gfx SPAM_SPAM_mesh_tri_4[];
extern Vtx SPAM_SPAM_mesh_vtx_5[24];
extern Gfx SPAM_SPAM_mesh_tri_5[];
extern Vtx SPAM_SPAM_mesh_vtx_6[216];
extern Gfx SPAM_SPAM_mesh_tri_6[];
extern Vtx SPAM_SPAM_mesh_vtx_7[99];
extern Gfx SPAM_SPAM_mesh_tri_7[];
extern Vtx SPAM_SPAM_mesh_vtx_8[1220];
extern Gfx SPAM_SPAM_mesh_tri_8[];
extern Vtx SPAM_SPAM_mesh_vtx_9[256];
extern Gfx SPAM_SPAM_mesh_tri_9[];
extern Vtx SPAM_SPAM_mesh_vtx_10[152];
extern Gfx SPAM_SPAM_mesh_tri_10[];
extern Vtx SPAM_SPAM_mesh_vtx_11[316];
extern Gfx SPAM_SPAM_mesh_tri_11[];
extern Vtx SPAM_SPAM_mesh_vtx_12[85];
extern Gfx SPAM_SPAM_mesh_tri_12[];
extern Vtx SPAM_SPAM_mesh_vtx_13[172];
extern Gfx SPAM_SPAM_mesh_tri_13[];
extern Gfx mat_SPAM_Blu_Gran_f3d[];
extern Gfx mat_SPAM_Dark_Blue_f3d[];
extern Gfx mat_SPAM_Dark_Green_f3d[];
extern Gfx mat_SPAM_Grn_Gran_f3d[];
extern Gfx mat_SPAM_Dark_Red_f3d[];
extern Gfx mat_SPAM_Red_Gran_f3d[];
extern Gfx mat_SPAM_Dark_Yellow_f3d[];
extern Gfx mat_SPAM_Yel_Gran_f3d[];
extern Gfx mat_SPAM_Wood_f3d[];
extern Gfx mat_SPAM_Brn_Gran_f3d[];
extern Gfx mat_SPAM_Red_Flat_f3d[];
extern Gfx mat_SPAM_Yellow_Flat_f3d[];
extern Gfx mat_SPAM_Pnk_Gran_f3d[];
extern Gfx mat_SPAM_Dark_Pink_f3d[];
extern Gfx SPAM_SPAM_mesh[];

extern const Gfx intro_seg7_dl_0700C6A0[];
extern const f32 intro_seg7_table_0700C790[];
extern const f32 intro_seg7_table_0700C880[];

// script
extern const LevelScript level_intro_entry_1[];
extern const LevelScript level_intro_entry_2[];
extern const LevelScript level_intro_entry_3[];
extern const LevelScript level_intro_entry_4[];
extern const LevelScript script_intro_L1[];
extern const LevelScript script_intro_L2[];
extern const LevelScript script_intro_L3[];
extern const LevelScript script_intro_L4[];
extern const LevelScript script_intro_L5[];

#endif
