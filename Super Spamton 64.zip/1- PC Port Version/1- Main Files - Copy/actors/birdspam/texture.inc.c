Gfx birdspam_birdface_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 birdspam_birdface_rgba16[] = {
	#include "actors/bird/birdface.rgba16.inc.c"
};

