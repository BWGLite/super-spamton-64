#include "texture.inc.c"

Lights1 birdspam_bird_main_lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFE, 0xFE, 0xFE, 0x28, 0x28, 0x28);

Vtx birdspam_000_offset_001_mesh_layer_1_vtx_0[69] = {
	{{{97, 4, -32},0, {476, 204},{0x6B, 0xE4, 0xC2, 0xFF}}},
	{{{10, 31, -56},0, {476, 204},{0xEC, 0x4E, 0x9D, 0xFF}}},
	{{{76, 49, 0},0, {476, 204},{0x2E, 0x76, 0x0, 0xFF}}},
	{{{10, 31, 56},0, {476, 204},{0xEC, 0x4E, 0x63, 0xFF}}},
	{{{97, 4, 32},0, {476, 204},{0x52, 0xFA, 0x61, 0xFF}}},
	{{{80, -53, 0},0, {476, 204},{0x31, 0x8B, 0x0, 0xFF}}},
	{{{17, -17, -52},0, {476, 204},{0xC2, 0x91, 0x1, 0xFF}}},
	{{{17, -17, 52},0, {476, 204},{0xC2, 0x91, 0xFF, 0xFF}}},
	{{{97, 4, 32},0, {397, 212},{0x52, 0xFA, 0x61, 0xFF}}},
	{{{80, -53, 0},0, {397, 212},{0x31, 0x8B, 0x0, 0xFF}}},
	{{{97, 4, -32},0, {397, 212},{0x6B, 0xE4, 0xC2, 0xFF}}},
	{{{76, 49, 0},0, {397, 212},{0x2E, 0x76, 0x0, 0xFF}}},
	{{{122, -99, 43},0, {377, 75},{0x66, 0xB, 0x4A, 0xFF}}},
	{{{133, -45, 46},0, {377, 75},{0x5D, 0xB, 0x56, 0xFF}}},
	{{{97, -28, 47},0, {377, 75},{0x8, 0x2D, 0x77, 0xFF}}},
	{{{112, 12, 27},0, {377, 75},{0x27, 0x68, 0x3D, 0xFF}}},
	{{{72, 6, 1},0, {377, 75},{0xD2, 0x76, 0xF6, 0xFF}}},
	{{{97, -28, 47},0, {377, 75},{0x8, 0x2D, 0x77, 0xFF}}},
	{{{112, 12, 27},0, {377, 75},{0x27, 0x68, 0x3D, 0xFF}}},
	{{{112, 12, -28},0, {377, 75},{0x26, 0x68, 0xC2, 0xFF}}},
	{{{97, -28, -48},0, {377, 75},{0xEA, 0x25, 0x88, 0xFF}}},
	{{{133, -45, -47},0, {377, 75},{0x5D, 0xB, 0xAA, 0xFF}}},
	{{{122, -99, -44},0, {377, 75},{0x7E, 0x7, 0xF3, 0xFF}}},
	{{{133, -45, 46},0, {364, 274},{0x5D, 0xB, 0x56, 0xFF}}},
	{{{122, -99, 43},0, {350, 44},{0x66, 0xB, 0x4A, 0xFF}}},
	{{{122, -99, -44},0, {5, 44},{0x7E, 0x7, 0xF3, 0xFF}}},
	{{{133, -45, -47},0, {-9, 274},{0x5D, 0xB, 0xAA, 0xFF}}},
	{{{112, 12, 27},0, {287, 513},{0x27, 0x68, 0x3D, 0xFF}}},
	{{{112, 12, -28},0, {68, 513},{0x26, 0x68, 0xC2, 0xFF}}},
	{{{17, -17, 52},0, {444, 224},{0xC2, 0x91, 0xFF, 0xFF}}},
	{{{97, 4, 32},0, {502, 264},{0x52, 0xFA, 0x61, 0xFF}}},
	{{{-2, -41, 100},0, {418, 225},{0xC8, 0xB6, 0x57, 0xFF}}},
	{{{97, 4, 32},0, {502, 264},{0x52, 0xFA, 0x61, 0xFF}}},
	{{{10, 31, 56},0, {471, 193},{0xEC, 0x4E, 0x63, 0xFF}}},
	{{{-2, -41, 100},0, {418, 225},{0xC8, 0xB6, 0x57, 0xFF}}},
	{{{17, -17, 52},0, {444, 224},{0xC2, 0x91, 0xFF, 0xFF}}},
	{{{17, -17, 52},0, {476, 302},{0xC2, 0x91, 0xFF, 0xFF}}},
	{{{10, 31, 56},0, {472, 276},{0xEC, 0x4E, 0x63, 0xFF}}},
	{{{-98, 37, 0},0, {414, 272},{0x84, 0x1A, 0x0, 0xFF}}},
	{{{76, 49, 0},0, {508, 266},{0x2E, 0x76, 0x0, 0xFF}}},
	{{{10, 31, -56},0, {472, 276},{0xEC, 0x4E, 0x9D, 0xFF}}},
	{{{17, -17, -52},0, {476, 302},{0xC2, 0x91, 0x1, 0xFF}}},
	{{{10, 31, -56},0, {471, 193},{0xEC, 0x4E, 0x9D, 0xFF}}},
	{{{97, 4, -32},0, {502, 264},{0x6B, 0xE4, 0xC2, 0xFF}}},
	{{{-2, -41, -100},0, {418, 225},{0xC8, 0xB6, 0xA9, 0xFF}}},
	{{{17, -17, -52},0, {444, 224},{0xC2, 0x91, 0x1, 0xFF}}},
	{{{123, -59, 0},0, {377, 75},{0xF, 0x82, 0x0, 0xFF}}},
	{{{118, -39, -28},0, {377, 75},{0x65, 0x24, 0xBB, 0xFF}}},
	{{{223, -47, 0},0, {377, 75},{0x7F, 0xFD, 0x0, 0xFF}}},
	{{{118, -39, 27},0, {377, 75},{0x65, 0x24, 0x45, 0xFF}}},
	{{{122, -99, 43},0, {481, 183},{0x66, 0xB, 0x4A, 0xFF}}},
	{{{97, -28, 47},0, {481, 183},{0x8, 0x2D, 0x77, 0xFF}}},
	{{{72, -106, 38},0, {481, 183},{0xCE, 0xA2, 0x45, 0xFF}}},
	{{{78, -98, 85},0, {481, 183},{0x11, 0xBF, 0x6C, 0xFF}}},
	{{{50, -41, 37},0, {481, 183},{0xB8, 0xBF, 0x52, 0xFF}}},
	{{{20, -26, 78},0, {481, 183},{0xB9, 0x0, 0x6A, 0xFF}}},
	{{{72, 6, 1},0, {481, 183},{0xD2, 0x76, 0xF6, 0xFF}}},
	{{{17, -33, -17},0, {481, 183},{0x90, 0x1F, 0xCD, 0xFF}}},
	{{{97, -28, -48},0, {481, 183},{0xEA, 0x25, 0x88, 0xFF}}},
	{{{129, -121, -52},0, {481, 183},{0x3B, 0xAA, 0xB7, 0xFF}}},
	{{{122, -99, -44},0, {481, 183},{0x7E, 0x7, 0xF3, 0xFF}}},
	{{{108, -128, 89},0, {481, 183},{0x3E, 0xF1, 0x6E, 0xFF}}},
	{{{129, -121, -52},0, {481, 183},{0x3B, 0xAA, 0xB7, 0xFF}}},
	{{{72, -106, 38},0, {481, 183},{0xCE, 0xA2, 0x45, 0xFF}}},
	{{{21, -98, -3},0, {481, 183},{0x8C, 0xCD, 0xF5, 0xFF}}},
	{{{17, -33, -17},0, {481, 183},{0x90, 0x1F, 0xCD, 0xFF}}},
	{{{78, -98, 85},0, {481, 183},{0x11, 0xBF, 0x6C, 0xFF}}},
	{{{50, -41, 37},0, {481, 183},{0xB8, 0xBF, 0x52, 0xFF}}},
	{{{20, -26, 78},0, {481, 183},{0xB9, 0x0, 0x6A, 0xFF}}},
};

Gfx birdspam_000_offset_001_mesh_layer_1_tri_0[] = {
	gsSPVertex(birdspam_000_offset_001_mesh_layer_1_vtx_0 + 0, 16, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSP1Triangle(2, 3, 4, 0),
	gsSP1Triangle(0, 5, 6, 0),
	gsSP1Triangle(6, 5, 7, 0),
	gsSP1Triangle(7, 5, 4, 0),
	gsSP1Triangle(8, 9, 10, 0),
	gsSP1Triangle(11, 8, 10, 0),
	gsSP1Triangle(12, 13, 14, 0),
	gsSP1Triangle(13, 15, 14, 0),
	gsSPVertex(birdspam_000_offset_001_mesh_layer_1_vtx_0 + 16, 16, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSP1Triangle(0, 2, 3, 0),
	gsSP1Triangle(3, 4, 0, 0),
	gsSP1Triangle(4, 3, 5, 0),
	gsSP1Triangle(6, 4, 5, 0),
	gsSP1Triangle(7, 8, 9, 0),
	gsSP1Triangle(7, 9, 10, 0),
	gsSP1Triangle(10, 11, 7, 0),
	gsSP1Triangle(10, 12, 11, 0),
	gsSP1Triangle(13, 14, 15, 0),
	gsSPVertex(birdspam_000_offset_001_mesh_layer_1_vtx_0 + 32, 14, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSP1Triangle(1, 3, 2, 0),
	gsSP1Triangle(4, 5, 6, 0),
	gsSP1Triangle(6, 5, 7, 0),
	gsSP1Triangle(6, 7, 8, 0),
	gsSP1Triangle(6, 8, 9, 0),
	gsSP1Triangle(4, 6, 9, 0),
	gsSP1Triangle(10, 11, 12, 0),
	gsSP1Triangle(11, 13, 12, 0),
	gsSP1Triangle(13, 10, 12, 0),
	gsSPVertex(birdspam_000_offset_001_mesh_layer_1_vtx_0 + 46, 16, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSP1Triangle(1, 3, 2, 0),
	gsSP1Triangle(0, 2, 3, 0),
	gsSP1Triangle(4, 5, 6, 0),
	gsSP1Triangle(6, 5, 7, 0),
	gsSP1Triangle(5, 8, 7, 0),
	gsSP1Triangle(5, 9, 8, 0),
	gsSP1Triangle(9, 5, 10, 0),
	gsSP1Triangle(10, 11, 9, 0),
	gsSP1Triangle(12, 11, 10, 0),
	gsSP1Triangle(13, 11, 12, 0),
	gsSP1Triangle(14, 13, 12, 0),
	gsSP1Triangle(13, 14, 4, 0),
	gsSP1Triangle(13, 4, 15, 0),
	gsSP1Triangle(4, 6, 15, 0),
	gsSP1Triangle(13, 15, 6, 0),
	gsSPVertex(birdspam_000_offset_001_mesh_layer_1_vtx_0 + 62, 7, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSP1Triangle(1, 3, 2, 0),
	gsSP1Triangle(1, 4, 3, 0),
	gsSP1Triangle(5, 3, 4, 0),
	gsSP1Triangle(5, 6, 3, 0),
	gsSP1Triangle(3, 0, 2, 0),
	gsSPEndDisplayList(),
};

Vtx birdspam_000_offset_001_mesh_layer_1_vtx_1[9] = {
	{{{129, -142, -67},0, {774, 161},{0x3E, 0xA4, 0xC1, 0xFF}}},
	{{{130, -142, 67},0, {774, 161},{0x4E, 0xA9, 0xCF, 0xFF}}},
	{{{164, -142, 0},0, {774, 161},{0x46, 0xA3, 0xCC, 0xFF}}},
	{{{21, -142, 0},0, {774, 161},{0x4F, 0xAB, 0xCC, 0xFF}}},
	{{{129, -142, -67},0, {774, 161},{0x41, 0x9B, 0xD5, 0xFF}}},
	{{{64, -142, -60},0, {774, 161},{0x46, 0xA3, 0xCC, 0xFF}}},
	{{{130, -142, 67},0, {774, 161},{0x42, 0x9D, 0xD4, 0xFF}}},
	{{{21, -142, 0},0, {774, 161},{0x3F, 0xA5, 0xC1, 0xFF}}},
	{{{64, -142, 60},0, {774, 161},{0x46, 0xA3, 0xCC, 0xFF}}},
};

Gfx birdspam_000_offset_001_mesh_layer_1_tri_1[] = {
	gsSPVertex(birdspam_000_offset_001_mesh_layer_1_vtx_1 + 0, 9, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSP1Triangle(3, 4, 5, 0),
	gsSP1Triangle(6, 7, 8, 0),
	gsSPEndDisplayList(),
};

Vtx birdspam_000_offset_003_mesh_layer_1_vtx_0[6] = {
	{{{109, 1, 41},0, {377, 75},{0xE, 0x7D, 0xF2, 0xFF}}},
	{{{71, -3, -34},0, {377, 75},{0x9, 0x7D, 0xEE, 0xFF}}},
	{{{28, 7, 13},0, {377, 75},{0xC, 0x7D, 0xEC, 0xFF}}},
	{{{24, -5, -60},0, {377, 75},{0x7, 0x7D, 0xEA, 0xFF}}},
	{{{-15, -4, -67},0, {377, 75},{0xB, 0x7C, 0xE8, 0xFF}}},
	{{{-23, 13, 5},0, {377, 75},{0x11, 0x7B, 0xE5, 0xFF}}},
};

Gfx birdspam_000_offset_003_mesh_layer_1_tri_0[] = {
	gsSPVertex(birdspam_000_offset_003_mesh_layer_1_vtx_0 + 0, 6, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSP1Triangle(2, 1, 3, 0),
	gsSP1Triangle(2, 3, 4, 0),
	gsSP1Triangle(2, 4, 5, 0),
	gsSPEndDisplayList(),
};

Vtx birdspam_000_offset_004_mesh_layer_1_vtx_0[6] = {
	{{{-23, 13, -5},0, {377, 75},{0x11, 0x7B, 0x1B, 0xFF}}},
	{{{-15, -4, 67},0, {377, 75},{0xB, 0x7C, 0x18, 0xFF}}},
	{{{28, 7, -13},0, {377, 75},{0xC, 0x7D, 0x14, 0xFF}}},
	{{{24, -5, 60},0, {377, 75},{0x7, 0x7D, 0x16, 0xFF}}},
	{{{71, -3, 34},0, {377, 75},{0x9, 0x7D, 0x12, 0xFF}}},
	{{{109, 1, -41},0, {377, 75},{0xE, 0x7D, 0xE, 0xFF}}},
};

Gfx birdspam_000_offset_004_mesh_layer_1_tri_0[] = {
	gsSPVertex(birdspam_000_offset_004_mesh_layer_1_vtx_0 + 0, 6, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSP1Triangle(2, 1, 3, 0),
	gsSP1Triangle(2, 3, 4, 0),
	gsSP1Triangle(2, 4, 5, 0),
	gsSPEndDisplayList(),
};


Gfx mat_birdspam_bird_main[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, ENVIRONMENT, TEXEL0, 0, SHADE, 0, 0, 0, 0, ENVIRONMENT),
	gsSPClearGeometryMode(G_CULL_BACK),
	gsDPSetTextureConvert(G_TC_CONV),
	gsDPSetTextureFilter(G_TF_POINT),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, birdspam_birdface_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_CLAMP | G_TX_NOMIRROR, 4, 0, G_TX_CLAMP | G_TX_NOMIRROR, 4, 0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 255, 512),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 4, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 4, 0, G_TX_CLAMP | G_TX_NOMIRROR, 4, 0),
	gsDPSetTileSize(0, 0, 0, 60, 60),
	gsSPSetLights1(birdspam_bird_main_lights),
	gsSPEndDisplayList(),
};

Gfx mat_revert_birdspam_bird_main[] = {
	gsDPPipeSync(),
	gsSPSetGeometryMode(G_CULL_BACK),
	gsDPSetTextureConvert(G_TC_FILT),
	gsDPSetTextureFilter(G_TF_BILERP),
	gsSPEndDisplayList(),
};

Gfx mat_birdspam_bird_halo[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, ENVIRONMENT, 0, 0, 0, ENVIRONMENT, 0, 0, 0, ENVIRONMENT, 0, 0, 0, ENVIRONMENT),
	gsSPClearGeometryMode(G_CULL_BACK),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetEnvColor(254, 254, 254, 255),
	gsSPEndDisplayList(),
};

Gfx mat_revert_birdspam_bird_halo[] = {
	gsDPPipeSync(),
	gsSPSetGeometryMode(G_CULL_BACK),
	gsSPEndDisplayList(),
};

Gfx birdspam_000_offset_001_mesh_layer_1[] = {
	gsSPDisplayList(mat_birdspam_bird_main),
	gsSPDisplayList(birdspam_000_offset_001_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_birdspam_bird_main),
	gsSPDisplayList(mat_birdspam_bird_halo),
	gsSPDisplayList(birdspam_000_offset_001_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_birdspam_bird_halo),
	gsSPEndDisplayList(),
};

Gfx birdspam_000_offset_003_mesh_layer_1[] = {
	gsSPDisplayList(mat_birdspam_bird_main),
	gsSPDisplayList(birdspam_000_offset_003_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_birdspam_bird_main),
	gsSPEndDisplayList(),
};

Gfx birdspam_000_offset_004_mesh_layer_1[] = {
	gsSPDisplayList(mat_birdspam_bird_main),
	gsSPDisplayList(birdspam_000_offset_004_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_birdspam_bird_main),
	gsSPEndDisplayList(),
};

Gfx birdspam_material_revert_render_settings[] = {
	gsDPPipeSync(),
	gsSPSetGeometryMode(G_LIGHTING),
	gsSPClearGeometryMode(G_TEXTURE_GEN),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPSetEnvColor(255, 255, 255, 255),
	gsDPSetAlphaCompare(G_AC_NONE),
	gsSPEndDisplayList(),
};

