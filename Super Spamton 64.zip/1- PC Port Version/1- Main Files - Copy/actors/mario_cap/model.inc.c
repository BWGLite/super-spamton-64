Lights1 mario_cap_cap_lights = gdSPDefLights1(
	0x3E, 0x3E, 0x3E,
	0xFF, 0xFF, 0xFF, 0x25, 0x53, 0x58);

Lights1 mario_cap_wing2_lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFE, 0xFE, 0xFE, 0x28, 0x28, 0x28);

Lights1 mario_cap_wing1_lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFE, 0xFE, 0xFE, 0x28, 0x28, 0x28);

Gfx mario_cap_m_mark_txt_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 mario_cap_m_mark_txt_rgba16[] = {
	#include "actors/mario_cap/m_mark_txt.rgba16.inc.c"
};

Gfx mario_cap_mario_cap_wing_tip_rgba16_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 mario_cap_mario_cap_wing_tip_rgba16_rgba16[] = {
	#include "actors/mario_cap/mario_cap_wing_tip_rgba16.rgba16.inc.c"
};

Gfx mario_cap_mario_cap_wing_rgba16_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 mario_cap_mario_cap_wing_rgba16_rgba16[] = {
	#include "actors/mario_cap/mario_cap_wing_rgba16.rgba16.inc.c"
};

Gfx mario_cap_metal_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 mario_cap_metal_rgba16[] = {
	#include "actors/mario_cap/mario_cap_metal.rgba16.inc.c"
};

Gfx mario_cap_mario_cap_metalwing_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 mario_cap_mario_cap_metalwing_rgba16[] = {
	#include "actors/mario_cap/mario_cap_metal_wing_unused.rgba16.inc.c"
};

Gfx mario_cap_mario_cap_metalwingtip_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 mario_cap_mario_cap_metalwingtip_rgba16[] = {
	#include "actors/mario_cap/mario_cap_metal_wing_tip_unused.rgba16.inc.c"
};

Vtx mario_cap_000_displaylist_mesh_layer_1_vtx_0[47] = {
	{{{-112, -7, 126},0, {366, 233},{0xCD, 0x0, 0x74, 0xFF}}},
	{{{-122, 14, 77},0, {493, 104},{0x84, 0x5, 0x1C, 0xFF}}},
	{{{-124, -7, 77},0, {366, 104},{0x84, 0x6, 0x1D, 0xFF}}},
	{{{-112, 14, 126},0, {493, 233},{0xCD, 0x0, 0x74, 0xFF}}},
	{{{-7, -34, 126},0, {204, 896},{0x0, 0x0, 0x7F, 0xFF}}},
	{{{-112, -48, 126},0, {122, 233},{0x0, 0x0, 0x7F, 0xFF}}},
	{{{-7, -48, 126},0, {122, 896},{0x0, 0x0, 0x7F, 0xFF}}},
	{{{-7, 44, 126},0, {671, 896},{0x0, 0x0, 0x7F, 0xFF}}},
	{{{8, -34, 126},0, {204, 1120},{0x0, 0x0, 0x7F, 0xFF}}},
	{{{8, 44, 126},0, {671, 1120},{0x0, 0x0, 0x7F, 0xFF}}},
	{{{112, 14, 126},0, {493, 1778},{0x33, 0x0, 0x74, 0xFF}}},
	{{{112, -7, 126},0, {366, 1778},{0x33, 0x0, 0x74, 0xFF}}},
	{{{112, -48, 126},0, {122, 1778},{0x0, 0x0, 0x7F, 0xFF}}},
	{{{8, -48, 126},0, {122, 1120},{0x0, 0x0, 0x7F, 0xFF}}},
	{{{122, 14, 77},0, {493, 1907},{0x7C, 0x5, 0x1C, 0xFF}}},
	{{{124, -7, 77},0, {366, 1907},{0x7C, 0x6, 0x1D, 0xFF}}},
	{{{112, 14, 126},0, {493, 1778},{0x33, 0x0, 0x74, 0xFF}}},
	{{{112, 59, 126},0, {763, 1778},{0x0, 0x0, 0x7F, 0xFF}}},
	{{{8, 44, 126},0, {671, 1120},{0x0, 0x0, 0x7F, 0xFF}}},
	{{{8, 59, 126},0, {763, 1120},{0x0, 0x0, 0x7F, 0xFF}}},
	{{{-112, 59, 126},0, {763, 233},{0x0, 0x0, 0x7F, 0xFF}}},
	{{{-112, 14, 126},0, {493, 233},{0xCD, 0x0, 0x74, 0xFF}}},
	{{{-7, 44, 126},0, {671, 896},{0x0, 0x0, 0x7F, 0xFF}}},
	{{{-7, 59, 126},0, {763, 896},{0x0, 0x0, 0x7F, 0xFF}}},
	{{{-112, -7, 121},0, {366, 233},{0x33, 0x0, 0x8C, 0xFF}}},
	{{{-124, -7, 72},0, {366, 104},{0x7C, 0xFA, 0xE3, 0xFF}}},
	{{{-122, 14, 72},0, {493, 104},{0x7C, 0xFB, 0xE4, 0xFF}}},
	{{{-112, 14, 121},0, {493, 233},{0x33, 0x0, 0x8C, 0xFF}}},
	{{{-7, -34, 121},0, {204, 896},{0x0, 0x0, 0x81, 0xFF}}},
	{{{-7, 44, 121},0, {671, 896},{0x0, 0x0, 0x81, 0xFF}}},
	{{{-112, 59, 121},0, {763, 233},{0x0, 0x0, 0x81, 0xFF}}},
	{{{-7, 59, 121},0, {763, 896},{0x0, 0x0, 0x81, 0xFF}}},
	{{{-7, 44, 121},0, {671, 896},{0x0, 0x0, 0x81, 0xFF}}},
	{{{8, -34, 121},0, {204, 1120},{0x0, 0x0, 0x81, 0xFF}}},
	{{{-7, -34, 121},0, {204, 896},{0x0, 0x0, 0x81, 0xFF}}},
	{{{8, 44, 121},0, {671, 1120},{0x0, 0x0, 0x81, 0xFF}}},
	{{{112, 14, 121},0, {493, 1778},{0xCD, 0x0, 0x8C, 0xFF}}},
	{{{112, 59, 121},0, {763, 1778},{0x0, 0x0, 0x81, 0xFF}}},
	{{{8, 59, 121},0, {763, 1120},{0x0, 0x0, 0x81, 0xFF}}},
	{{{112, -7, 121},0, {366, 1778},{0xCD, 0x0, 0x8C, 0xFF}}},
	{{{112, -48, 121},0, {122, 1778},{0x0, 0x0, 0x81, 0xFF}}},
	{{{8, -48, 121},0, {122, 1120},{0x0, 0x0, 0x81, 0xFF}}},
	{{{122, 14, 72},0, {493, 1907},{0x84, 0xFB, 0xE4, 0xFF}}},
	{{{124, -7, 72},0, {366, 1907},{0x84, 0xFA, 0xE3, 0xFF}}},
	{{{-112, -48, 121},0, {122, 233},{0x0, 0x0, 0x81, 0xFF}}},
	{{{-7, -48, 121},0, {122, 896},{0x0, 0x0, 0x81, 0xFF}}},
	{{{-112, -7, 121},0, {366, 233},{0x33, 0x0, 0x8C, 0xFF}}},
};

Gfx mario_cap_000_displaylist_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_cap_000_displaylist_mesh_layer_1_vtx_0 + 0, 16, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSP1Triangle(0, 3, 1, 0),
	gsSP1Triangle(4, 3, 0, 0),
	gsSP1Triangle(0, 5, 4, 0),
	gsSP1Triangle(5, 6, 4, 0),
	gsSP1Triangle(4, 7, 3, 0),
	gsSP1Triangle(7, 4, 8, 0),
	gsSP1Triangle(7, 8, 9, 0),
	gsSP1Triangle(9, 8, 10, 0),
	gsSP1Triangle(11, 10, 8, 0),
	gsSP1Triangle(11, 8, 12, 0),
	gsSP1Triangle(8, 13, 12, 0),
	gsSP1Triangle(11, 14, 10, 0),
	gsSP1Triangle(11, 15, 14, 0),
	gsSPVertex(mario_cap_000_displaylist_mesh_layer_1_vtx_0 + 16, 16, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSP1Triangle(1, 3, 2, 0),
	gsSP1Triangle(4, 5, 6, 0),
	gsSP1Triangle(6, 7, 4, 0),
	gsSP1Triangle(8, 9, 10, 0),
	gsSP1Triangle(8, 10, 11, 0),
	gsSP1Triangle(12, 8, 11, 0),
	gsSP1Triangle(12, 11, 13, 0),
	gsSP1Triangle(14, 13, 11, 0),
	gsSP1Triangle(13, 14, 15, 0),
	gsSPVertex(mario_cap_000_displaylist_mesh_layer_1_vtx_0 + 32, 15, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSP1Triangle(0, 3, 1, 0),
	gsSP1Triangle(3, 4, 1, 0),
	gsSP1Triangle(4, 3, 5, 0),
	gsSP1Triangle(5, 3, 6, 0),
	gsSP1Triangle(7, 1, 4, 0),
	gsSP1Triangle(7, 8, 1, 0),
	gsSP1Triangle(1, 8, 9, 0),
	gsSP1Triangle(7, 4, 10, 0),
	gsSP1Triangle(7, 10, 11, 0),
	gsSP1Triangle(12, 2, 13, 0),
	gsSP1Triangle(14, 2, 12, 0),
	gsSPEndDisplayList(),
};

Vtx mario_cap_001_displaylist_mesh_layer_5_vtx_0[8] = {
	{{{-206, -22, -60},0, {974, 2002},{0xA6, 0xED, 0x58, 0xFF}}},
	{{{-137, 6, 17},0, {-16, 2002},{0xA6, 0xED, 0x58, 0xFF}}},
	{{{-267, 181, -78},0, {974, -16},{0xA6, 0xED, 0x58, 0xFF}}},
	{{{-198, 209, -1},0, {-16, -16},{0xA6, 0xED, 0x58, 0xFF}}},
	{{{268, 181, -78},0, {974, -16},{0x5A, 0xED, 0x58, 0xFF}}},
	{{{138, 6, 17},0, {-16, 2002},{0x5A, 0xED, 0x58, 0xFF}}},
	{{{207, -22, -60},0, {974, 2002},{0x5A, 0xED, 0x58, 0xFF}}},
	{{{199, 209, -1},0, {-16, -16},{0x5A, 0xED, 0x58, 0xFF}}},
};

Gfx mario_cap_001_displaylist_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_cap_001_displaylist_mesh_layer_5_vtx_0 + 0, 8, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSP1Triangle(1, 3, 2, 0),
	gsSP1Triangle(4, 5, 6, 0),
	gsSP1Triangle(4, 7, 5, 0),
	gsSPEndDisplayList(),
};

Vtx mario_cap_001_displaylist_mesh_layer_4_vtx_0[8] = {
	{{{-137, 6, 17},0, {974, 2002},{0xA6, 0xED, 0x58, 0xFF}}},
	{{{-68, 33, 92},0, {-16, 2002},{0xA7, 0xED, 0x59, 0xFF}}},
	{{{-198, 209, -1},0, {974, -16},{0xA6, 0xED, 0x58, 0xFF}}},
	{{{-130, 236, 74},0, {-16, -16},{0xA6, 0xED, 0x58, 0xFF}}},
	{{{199, 209, -1},0, {974, -16},{0x5A, 0xED, 0x58, 0xFF}}},
	{{{69, 33, 92},0, {-16, 2002},{0x59, 0xED, 0x59, 0xFF}}},
	{{{138, 6, 17},0, {974, 2002},{0x5A, 0xED, 0x58, 0xFF}}},
	{{{131, 236, 74},0, {-16, -16},{0x5A, 0xED, 0x58, 0xFF}}},
};

Gfx mario_cap_001_displaylist_mesh_layer_4_tri_0[] = {
	gsSPVertex(mario_cap_001_displaylist_mesh_layer_4_vtx_0 + 0, 8, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSP1Triangle(1, 3, 2, 0),
	gsSP1Triangle(4, 5, 6, 0),
	gsSP1Triangle(4, 7, 5, 0),
	gsSPEndDisplayList(),
};


Gfx mat_mario_cap_cap[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0),
	gsDPSetRenderMode(G_RM_AA_ZB_TEX_EDGE, G_RM_AA_ZB_TEX_EDGE2),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, mario_cap_m_mark_txt_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 8, 0, 7, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 2047, 256),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 252),
	gsSPSetLights1(mario_cap_cap_lights),
	gsSPEndDisplayList(),
};

Gfx mat_mariovanish_cap_cap[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, mario_cap_m_mark_txt_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 8, 0, 7, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 2047, 256),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 252),
	gsSPSetLights1(mario_cap_cap_lights),
	gsSPEndDisplayList(),
};

Gfx mat_mario_cap_wing2[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, PRIMITIVE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, PRIMITIVE, 0),
	gsSPClearGeometryMode(G_CULL_BACK),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, mario_cap_mario_cap_wing_tip_rgba16_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 7, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPLoadSync(),
	gsDPLoadTile(7, 0, 0, 124, 252),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 252),
	gsDPSetPrimColor(0, 0, 254, 254, 254, 255),
	gsSPSetLights1(mario_cap_wing2_lights),
	gsSPEndDisplayList(),
};

Gfx mat_revert_mario_cap_wing2[] = {
	gsDPPipeSync(),
	gsSPSetGeometryMode(G_CULL_BACK),
	gsSPEndDisplayList(),
};

Gfx mat_mario_cap_wing1[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0),
	gsSPClearGeometryMode(G_CULL_BACK),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, mario_cap_mario_cap_wing_rgba16_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 7, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPLoadSync(),
	gsDPLoadTile(7, 0, 0, 124, 252),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 252),
	gsSPSetLights1(mario_cap_wing1_lights),
	gsSPEndDisplayList(),
};

Gfx mat_revert_mario_cap_wing1[] = {
	gsDPPipeSync(),
	gsSPSetGeometryMode(G_CULL_BACK),
	gsSPEndDisplayList(),
};

Gfx mat_mario_cap_metalwingtip[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, PRIMITIVE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, PRIMITIVE, 0),
	gsSPClearGeometryMode(G_CULL_BACK),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, mario_cap_mario_cap_metalwingtip_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 7, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPLoadSync(),
	gsDPLoadTile(7, 0, 0, 124, 252),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 252),
	gsDPSetPrimColor(0, 0, 254, 254, 254, 255),
	gsSPSetLights1(mario_cap_wing2_lights),
	gsSPEndDisplayList(),
};

Gfx mat_revert_mario_cap_metalwingtip[] = {
	gsDPPipeSync(),
	gsSPSetGeometryMode(G_CULL_BACK),
	gsSPEndDisplayList(),
};

Gfx mat_mario_cap_metalwing[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0),
	gsSPClearGeometryMode(G_CULL_BACK),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, mario_cap_mario_cap_metalwing_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 7, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPLoadSync(),
	gsDPLoadTile(7, 0, 0, 124, 252),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 252),
	gsSPSetLights1(mario_cap_wing1_lights),
	gsSPEndDisplayList(),
};

Gfx mat_revert_mario_cap_metalwing[] = {
	gsDPPipeSync(),
	gsSPSetGeometryMode(G_CULL_BACK),
	gsSPEndDisplayList(),
};

Gfx mat_mario_cap_metalcap[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, ENVIRONMENT, 0, 0, 0, TEXEL0, 0, 0, 0, ENVIRONMENT),
	gsSPSetGeometryMode(G_TEXTURE_GEN),
	gsSPTexture(4031, 1983, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b, 64, mario_cap_metal_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 6, 0),
	gsDPLoadSync(),
	gsDPLoadTile(7, 0, 0, 252, 124),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 0, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 6, 0),
	gsDPSetTileSize(0, 0, 0, 252, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_mario_cap_metalcap[] = {
	gsDPPipeSync(),
	gsSPClearGeometryMode(G_TEXTURE_GEN),
	gsSPEndDisplayList(),
};



Gfx mario_cap_000_displaylist_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_cap_cap),
	gsSPDisplayList(mario_cap_000_displaylist_mesh_layer_1_tri_0),
	gsSPEndDisplayList(),
};

Gfx mariovanish_cap_000_displaylist_mesh_layer_1[] = {
	gsSPDisplayList(mat_mariovanish_cap_cap),
	gsSPDisplayList(mario_cap_000_displaylist_mesh_layer_1_tri_0),
	gsSPEndDisplayList(),
};

Gfx mario_cap_001_displaylist_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_cap_wing2),
	gsSPDisplayList(mario_cap_001_displaylist_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_cap_wing2),
	gsSPEndDisplayList(),
};

Gfx mario_cap_001_displaylist_mesh_layer_4[] = {
	gsSPDisplayList(mat_mario_cap_wing1),
	gsSPDisplayList(mario_cap_001_displaylist_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_mario_cap_wing1),
	gsSPEndDisplayList(),
};

Gfx mario_cap_000_displaylist_mesh_layer_1_metal[] = {
	gsSPDisplayList(mat_mario_cap_metalcap),
	gsSPDisplayList(mario_cap_000_displaylist_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_cap_metalcap),
	gsSPEndDisplayList(),
};

Gfx mario_cap_001_displaylist_mesh_layer_5_metal[] = {
	gsSPDisplayList(mat_mario_cap_metalwingtip),
	gsSPDisplayList(mario_cap_001_displaylist_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_cap_metalwingtip),
	gsSPEndDisplayList(),
};

Gfx mario_cap_001_displaylist_mesh_layer_4_metal[] = {
	gsSPDisplayList(mat_mario_cap_metalwing),
	gsSPDisplayList(mario_cap_001_displaylist_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_mario_cap_metalwing),
	gsSPEndDisplayList(),
};

Gfx mario_cap_seg3_dl_03022F48[] = {
	gsSPDisplayList(mat_mario_cap_cap),
	gsSPDisplayList(mario_cap_000_displaylist_mesh_layer_1_tri_0),
	gsSPEndDisplayList(),
};


Gfx mario_cap_material_revert_render_settings[] = {
	gsDPPipeSync(),
	gsSPSetGeometryMode(G_LIGHTING),
	gsSPClearGeometryMode(G_TEXTURE_GEN),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPSetEnvColor(255, 255, 255, 255),
	gsDPSetAlphaCompare(G_AC_NONE),
	gsSPEndDisplayList(),
};

