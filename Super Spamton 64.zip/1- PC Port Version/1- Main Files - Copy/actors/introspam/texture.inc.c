Gfx introspam_Head1_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 introspam_Head1_rgba16[] = {
	#include "actors/peach/Head1.rgba16.inc.c"
};

Gfx introspam_map_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 introspam_map_rgba16[] = {
	#include "actors/peach/map.rgba16.inc.c"
};

