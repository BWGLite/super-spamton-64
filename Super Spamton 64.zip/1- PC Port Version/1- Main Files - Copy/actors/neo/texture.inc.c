Gfx neo_SpamtonNEOWing2_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 neo_SpamtonNEOWing2_rgba16[] = {
	#include "actors/mario/SpamtonNEOWing2.rgba16.inc.c"
};

Gfx neo_SpamtonNEOWing1_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 neo_SpamtonNEOWing1_rgba16[] = {
	#include "actors/mario/SpamtonNEOWing1.rgba16.inc.c"
};

Gfx neo_StaticWing2_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 neo_StaticWing2_rgba16[] = {
	#include "actors/mario/StaticWing2.rgba16.inc.c"
};

Gfx neo_StaticWing1_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 neo_StaticWing1_rgba16[] = {
	#include "actors/mario/StaticWing1.rgba16.inc.c"
};

Gfx neo_Head1_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 neo_Head1_rgba16[] = {
	#include "actors/mario/NEOHead1.rgba16.inc.c"
};

Gfx neo_Head2_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 neo_Head2_rgba16[] = {
	#include "actors/mario/NEOHead2.rgba16.inc.c"
};

Gfx neo_Head3_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 neo_Head3_rgba16[] = {
	#include "actors/mario/NEOHead3.rgba16.inc.c"
};

Gfx neo_Head4_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 neo_Head4_rgba16[] = {
	#include "actors/mario/NEOHead4.rgba16.inc.c"
};

Gfx neo_halo_ia8_aligner[] = {gsSPEndDisplayList()};
u8 neo_halo_ia8[] = {
	#include "actors/mario/halo.ia8.inc.c"
};

Gfx neo_Blaster_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 neo_Blaster_rgba16[] = {
	#include "actors/mario/Blaster.rgba16.inc.c"
};

Gfx neo_pipis_label_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 neo_pipis_label_rgba16[] = {
	#include "actors/mario/pipis_label.rgba16.inc.c"
};

Gfx neo_wing_2_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 neo_wing_2_rgba16[] = {
	#include "actors/mario/wing_2.rgba16.inc.c"
};

Gfx neo_wing1_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 neo_wing1_rgba16[] = {
	#include "actors/mario/wing1.rgba16.inc.c"
};

Gfx neo_blackmetal_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 neo_blackmetal_rgba16[] = {
	#include "actors/mario/blackmetal.rgba16.inc.c"
};

Gfx neo_purplemetal_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 neo_purplemetal_rgba16[] = {
	#include "actors/mario/purplemetal.rgba16.inc.c"
};

Gfx neo_SpamtonNEOmetalwing2_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 neo_SpamtonNEOmetalwing2_rgba16[] = {
	#include "actors/mario/SpamtonNEOmetalwing2.rgba16.inc.c"
};

Gfx neo_SpamtonNEOmetalwing1_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 neo_SpamtonNEOmetalwing1_rgba16[] = {
	#include "actors/mario/SpamtonNEOmetalwing1.rgba16.inc.c"
};

Gfx neo_metal_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 neo_metal_rgba16[] = {
	#include "actors/mario/metal.rgba16.inc.c"
};

Gfx neo_metal_pipis_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 neo_metal_pipis_rgba16[] = {
	#include "actors/mario/metal_pipis.rgba16.inc.c"
};

Gfx neo_gold_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 neo_gold_rgba16[] = {
	#include "actors/mario/gold.rgba16.inc.c"
};

Gfx neo_SpamtonNEOgoldwing2_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 neo_SpamtonNEOgoldwing2_rgba16[] = {
	#include "actors/mario/SpamtonNEOgoldwing2.rgba16.inc.c"
};

Gfx neo_SpamtonNEOgoldwing1_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 neo_SpamtonNEOgoldwing1_rgba16[] = {
	#include "actors/mario/SpamtonNEOgoldwing1.rgba16.inc.c"
};

