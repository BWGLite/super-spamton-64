Lights1 dumpster_dump_main_lights = gdSPDefLights1(
	0xE, 0x2D, 0x35,
	0x1D, 0x5B, 0x6A, 0x28, 0x28, 0x28);

Lights1 dumpster_dump_dark_lights = gdSPDefLights1(
	0xF, 0x27, 0x2E,
	0x1E, 0x4F, 0x5D, 0x28, 0x28, 0x28);

Lights1 dumpster_dump_black_lights = gdSPDefLights1(
	0x0, 0x0, 0x0,
	0x0, 0x0, 0x0, 0x28, 0x28, 0x28);

Lights1 dumpster_dump_blue_lights = gdSPDefLights1(
	0x5, 0x18, 0x2A,
	0xA, 0x30, 0x55, 0x28, 0x28, 0x28);

Lights1 dumpster_dump_orange_lights = gdSPDefLights1(
	0x38, 0x2D, 0x27,
	0x71, 0x5B, 0x4E, 0x28, 0x28, 0x28);

Lights1 dumpster_dump_yellow_lights = gdSPDefLights1(
	0x3D, 0x3C, 0x30,
	0x7A, 0x78, 0x61, 0x28, 0x28, 0x28);

Vtx dumpster_000_displaylist_mesh_layer_1_vtx_0[40] = {
	{{{-154, 190, 117},0, {-16, 1008},{0x0, 0x0, 0x7F, 0xFF}}},
	{{{-154, 0, 117},0, {-16, 1008},{0x0, 0x0, 0x7F, 0xFF}}},
	{{{154, 0, 117},0, {-16, 1008},{0x0, 0x0, 0x7F, 0xFF}}},
	{{{-123, 190, 117},0, {-16, 1008},{0x0, 0x0, 0x7F, 0xFF}}},
	{{{123, 190, 117},0, {-16, 1008},{0x0, 0x0, 0x7F, 0xFF}}},
	{{{154, 190, 117},0, {-16, 1008},{0x0, 0x0, 0x7F, 0xFF}}},
	{{{154, 0, 117},0, {-16, 1008},{0x7F, 0x0, 0x0, 0xFF}}},
	{{{154, 0, -103},0, {-16, 1008},{0x7F, 0x0, 0x0, 0xFF}}},
	{{{154, 190, -103},0, {-16, 1008},{0x7F, 0x0, 0x0, 0xFF}}},
	{{{154, 190, 117},0, {-16, 1008},{0x7F, 0x0, 0x0, 0xFF}}},
	{{{154, 190, -103},0, {-16, 1008},{0x0, 0x0, 0x81, 0xFF}}},
	{{{154, 0, -103},0, {-16, 1008},{0x0, 0x0, 0x81, 0xFF}}},
	{{{-154, 0, -103},0, {-16, 1008},{0x0, 0x0, 0x81, 0xFF}}},
	{{{123, 190, -103},0, {-16, 1008},{0x0, 0x0, 0x81, 0xFF}}},
	{{{-123, 190, -103},0, {-16, 1008},{0x0, 0x0, 0x81, 0xFF}}},
	{{{-154, 190, -103},0, {-16, 1008},{0x0, 0x0, 0x81, 0xFF}}},
	{{{-154, 191, 116},0, {-16, 1008},{0x0, 0x61, 0xAF, 0xFF}}},
	{{{154, 191, 116},0, {-16, 1008},{0x0, 0x61, 0xAF, 0xFF}}},
	{{{154, 178, 100},0, {-16, 1008},{0x0, 0x61, 0xAF, 0xFF}}},
	{{{-154, 178, 100},0, {-16, 1008},{0x0, 0x61, 0xAF, 0xFF}}},
	{{{154, 191, 116},0, {-16, 1008},{0x7F, 0x0, 0x0, 0xFF}}},
	{{{154, 22, 257},0, {-16, 1008},{0x7F, 0x0, 0x0, 0xFF}}},
	{{{154, 9, 242},0, {-16, 1008},{0x7F, 0x0, 0x0, 0xFF}}},
	{{{154, 178, 100},0, {-16, 1008},{0x7F, 0x0, 0x0, 0xFF}}},
	{{{154, 22, 257},0, {-16, 1008},{0x0, 0x9F, 0x51, 0xFF}}},
	{{{-154, 22, 257},0, {-16, 1008},{0x0, 0x9F, 0x51, 0xFF}}},
	{{{-154, 9, 242},0, {-16, 1008},{0x0, 0x9F, 0x51, 0xFF}}},
	{{{154, 9, 242},0, {-16, 1008},{0x0, 0x9F, 0x51, 0xFF}}},
	{{{-154, 22, 257},0, {-16, 1008},{0x81, 0x0, 0x0, 0xFF}}},
	{{{-154, 191, 116},0, {-16, 1008},{0x81, 0x0, 0x0, 0xFF}}},
	{{{-154, 178, 100},0, {-16, 1008},{0x81, 0x0, 0x0, 0xFF}}},
	{{{-154, 9, 242},0, {-16, 1008},{0x81, 0x0, 0x0, 0xFF}}},
	{{{-154, 0, -103},0, {-16, 1008},{0x81, 0x0, 0x0, 0xFF}}},
	{{{-154, 0, 117},0, {-16, 1008},{0x81, 0x0, 0x0, 0xFF}}},
	{{{-154, 190, 117},0, {-16, 1008},{0x81, 0x0, 0x0, 0xFF}}},
	{{{-154, 190, -103},0, {-16, 1008},{0x81, 0x0, 0x0, 0xFF}}},
	{{{154, 9, 242},0, {-16, 1008},{0x0, 0xAF, 0x9F, 0xFF}}},
	{{{-154, 9, 242},0, {-16, 1008},{0x0, 0xAF, 0x9F, 0xFF}}},
	{{{-154, 178, 100},0, {-16, 1008},{0x0, 0xAF, 0x9F, 0xFF}}},
	{{{154, 178, 100},0, {-16, 1008},{0x0, 0xAF, 0x9F, 0xFF}}},
};

Gfx dumpster_000_displaylist_mesh_layer_1_tri_0[] = {
	gsSPVertex(dumpster_000_displaylist_mesh_layer_1_vtx_0 + 0, 16, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSP1Triangle(3, 0, 2, 0),
	gsSP1Triangle(2, 4, 3, 0),
	gsSP1Triangle(2, 5, 4, 0),
	gsSP1Triangle(6, 7, 8, 0),
	gsSP1Triangle(6, 8, 9, 0),
	gsSP1Triangle(10, 11, 12, 0),
	gsSP1Triangle(13, 10, 12, 0),
	gsSP1Triangle(12, 14, 13, 0),
	gsSP1Triangle(12, 15, 14, 0),
	gsSPVertex(dumpster_000_displaylist_mesh_layer_1_vtx_0 + 16, 16, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSP1Triangle(0, 2, 3, 0),
	gsSP1Triangle(4, 5, 6, 0),
	gsSP1Triangle(4, 6, 7, 0),
	gsSP1Triangle(8, 9, 10, 0),
	gsSP1Triangle(8, 10, 11, 0),
	gsSP1Triangle(12, 13, 14, 0),
	gsSP1Triangle(12, 14, 15, 0),
	gsSPVertex(dumpster_000_displaylist_mesh_layer_1_vtx_0 + 32, 8, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSP1Triangle(0, 2, 3, 0),
	gsSP1Triangle(4, 5, 6, 0),
	gsSP1Triangle(4, 6, 7, 0),
	gsSPEndDisplayList(),
};

Vtx dumpster_000_displaylist_mesh_layer_1_vtx_1[4] = {
	{{{154, 22, 257},0, {-16, 1008},{0x0, 0x51, 0x61, 0xFF}}},
	{{{154, 191, 116},0, {-16, 1008},{0x0, 0x51, 0x61, 0xFF}}},
	{{{-154, 191, 116},0, {-16, 1008},{0x0, 0x51, 0x61, 0xFF}}},
	{{{-154, 22, 257},0, {-16, 1008},{0x0, 0x51, 0x61, 0xFF}}},
};

Gfx dumpster_000_displaylist_mesh_layer_1_tri_1[] = {
	gsSPVertex(dumpster_000_displaylist_mesh_layer_1_vtx_1 + 0, 4, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSP1Triangle(0, 2, 3, 0),
	gsSPEndDisplayList(),
};

Vtx dumpster_000_displaylist_mesh_layer_1_vtx_2[20] = {
	{{{123, 112, 91},0, {86, 906},{0x0, 0x7F, 0x0, 0xFF}}},
	{{{123, 112, -77},0, {906, 906},{0x0, 0x7F, 0x0, 0xFF}}},
	{{{-123, 112, -77},0, {906, 86},{0x0, 0x7F, 0x0, 0xFF}}},
	{{{-123, 112, 91},0, {86, 86},{0x0, 0x7F, 0x0, 0xFF}}},
	{{{123, 112, -77},0, {906, 906},{0x81, 0x0, 0x0, 0xFF}}},
	{{{123, 112, 91},0, {86, 906},{0x81, 0x0, 0x0, 0xFF}}},
	{{{123, 190, 91},0, {86, 906},{0x81, 0x0, 0x0, 0xFF}}},
	{{{123, 190, -77},0, {906, 906},{0x81, 0x0, 0x0, 0xFF}}},
	{{{123, 112, 91},0, {86, 906},{0x0, 0x0, 0x81, 0xFF}}},
	{{{-123, 112, 91},0, {86, 86},{0x0, 0x0, 0x81, 0xFF}}},
	{{{-123, 190, 91},0, {86, 86},{0x0, 0x0, 0x81, 0xFF}}},
	{{{123, 190, 91},0, {86, 906},{0x0, 0x0, 0x81, 0xFF}}},
	{{{-123, 112, -77},0, {906, 86},{0x0, 0x0, 0x7F, 0xFF}}},
	{{{123, 112, -77},0, {906, 906},{0x0, 0x0, 0x7F, 0xFF}}},
	{{{123, 190, -77},0, {906, 906},{0x0, 0x0, 0x7F, 0xFF}}},
	{{{-123, 190, -77},0, {906, 86},{0x0, 0x0, 0x7F, 0xFF}}},
	{{{-123, 112, 91},0, {86, 86},{0x7F, 0x0, 0x0, 0xFF}}},
	{{{-123, 112, -77},0, {906, 86},{0x7F, 0x0, 0x0, 0xFF}}},
	{{{-123, 190, -77},0, {906, 86},{0x7F, 0x0, 0x0, 0xFF}}},
	{{{-123, 190, 91},0, {86, 86},{0x7F, 0x0, 0x0, 0xFF}}},
};

Gfx dumpster_000_displaylist_mesh_layer_1_tri_2[] = {
	gsSPVertex(dumpster_000_displaylist_mesh_layer_1_vtx_2 + 0, 16, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSP1Triangle(0, 2, 3, 0),
	gsSP1Triangle(4, 5, 6, 0),
	gsSP1Triangle(4, 6, 7, 0),
	gsSP1Triangle(8, 9, 10, 0),
	gsSP1Triangle(8, 10, 11, 0),
	gsSP1Triangle(12, 13, 14, 0),
	gsSP1Triangle(12, 14, 15, 0),
	gsSPVertex(dumpster_000_displaylist_mesh_layer_1_vtx_2 + 16, 4, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSP1Triangle(0, 2, 3, 0),
	gsSPEndDisplayList(),
};

Vtx dumpster_000_displaylist_mesh_layer_1_vtx_3[16] = {
	{{{123, 190, 117},0, {-16, 906},{0x0, 0x7F, 0x0, 0xFF}}},
	{{{154, 190, 117},0, {-16, 1008},{0x0, 0x7F, 0x0, 0xFF}}},
	{{{154, 190, -103},0, {1008, 1008},{0x0, 0x7F, 0x0, 0xFF}}},
	{{{123, 190, -77},0, {906, 906},{0x0, 0x7F, 0x0, 0xFF}}},
	{{{123, 190, -103},0, {1008, 906},{0x0, 0x7F, 0x0, 0xFF}}},
	{{{-123, 190, -77},0, {906, 86},{0x0, 0x7F, 0x0, 0xFF}}},
	{{{-123, 190, -103},0, {1008, 86},{0x0, 0x7F, 0x0, 0xFF}}},
	{{{123, 190, 91},0, {86, 906},{0x0, 0x7F, 0x0, 0xFF}}},
	{{{123, 190, 91},0, {86, 906},{0x0, 0x7F, 0x0, 0xFF}}},
	{{{-123, 190, 117},0, {-16, 86},{0x0, 0x7F, 0x0, 0xFF}}},
	{{{123, 190, 117},0, {-16, 906},{0x0, 0x7F, 0x0, 0xFF}}},
	{{{-123, 190, 91},0, {86, 86},{0x0, 0x7F, 0x0, 0xFF}}},
	{{{-154, 190, 117},0, {-16, -16},{0x0, 0x7F, 0x0, 0xFF}}},
	{{{-123, 190, -103},0, {1008, 86},{0x0, 0x7F, 0x0, 0xFF}}},
	{{{-123, 190, -77},0, {906, 86},{0x0, 0x7F, 0x0, 0xFF}}},
	{{{-154, 190, -103},0, {1008, -16},{0x0, 0x7F, 0x0, 0xFF}}},
};

Gfx dumpster_000_displaylist_mesh_layer_1_tri_3[] = {
	gsSPVertex(dumpster_000_displaylist_mesh_layer_1_vtx_3 + 0, 16, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSP1Triangle(2, 3, 0, 0),
	gsSP1Triangle(2, 4, 3, 0),
	gsSP1Triangle(4, 5, 3, 0),
	gsSP1Triangle(4, 6, 5, 0),
	gsSP1Triangle(3, 7, 0, 0),
	gsSP1Triangle(8, 9, 10, 0),
	gsSP1Triangle(8, 11, 9, 0),
	gsSP1Triangle(12, 9, 11, 0),
	gsSP1Triangle(11, 13, 12, 0),
	gsSP1Triangle(11, 14, 13, 0),
	gsSP1Triangle(13, 15, 12, 0),
	gsSPEndDisplayList(),
};

Vtx dumpster_000_displaylist_mesh_layer_1_vtx_4[4] = {
	{{{-147, 124, -105},0, {-16, 1008},{0x0, 0x0, 0x81, 0xFF}}},
	{{{34, 124, -105},0, {1008, 1008},{0x0, 0x0, 0x81, 0xFF}}},
	{{{34, 21, -105},0, {1008, -16},{0x0, 0x0, 0x81, 0xFF}}},
	{{{-147, 21, -105},0, {-16, -16},{0x0, 0x0, 0x81, 0xFF}}},
};

Gfx dumpster_000_displaylist_mesh_layer_1_tri_4[] = {
	gsSPVertex(dumpster_000_displaylist_mesh_layer_1_vtx_4 + 0, 4, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSP1Triangle(0, 2, 3, 0),
	gsSPEndDisplayList(),
};

Vtx dumpster_000_displaylist_mesh_layer_1_vtx_5[8] = {
	{{{77, 59, -105},0, {-16, 1008},{0x0, 0x0, 0x81, 0xFF}}},
	{{{144, 59, -105},0, {1008, 1008},{0x0, 0x0, 0x81, 0xFF}}},
	{{{144, 21, -105},0, {1008, -16},{0x0, 0x0, 0x81, 0xFF}}},
	{{{77, 21, -105},0, {-16, -16},{0x0, 0x0, 0x81, 0xFF}}},
	{{{-33, 156, -111},0, {-16, 1008},{0x0, 0x0, 0x81, 0xFF}}},
	{{{81, 156, -111},0, {1008, 1008},{0x0, 0x0, 0x81, 0xFF}}},
	{{{81, 103, -111},0, {1008, -16},{0x0, 0x0, 0x81, 0xFF}}},
	{{{-33, 103, -111},0, {-16, -16},{0x0, 0x0, 0x81, 0xFF}}},
};

Gfx dumpster_000_displaylist_mesh_layer_1_tri_5[] = {
	gsSPVertex(dumpster_000_displaylist_mesh_layer_1_vtx_5 + 0, 8, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSP1Triangle(0, 2, 3, 0),
	gsSP1Triangle(4, 5, 6, 0),
	gsSP1Triangle(4, 6, 7, 0),
	gsSPEndDisplayList(),
};


Gfx mat_dumpster_dump_main[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsSPSetLights1(dumpster_dump_main_lights),
	gsSPEndDisplayList(),
};

Gfx mat_dumpster_dump_dark[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsSPSetLights1(dumpster_dump_dark_lights),
	gsSPEndDisplayList(),
};

Gfx mat_dumpster_dump_black[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsSPSetLights1(dumpster_dump_black_lights),
	gsSPEndDisplayList(),
};

Gfx mat_dumpster_dump_blue[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsSPSetLights1(dumpster_dump_blue_lights),
	gsSPEndDisplayList(),
};

Gfx mat_dumpster_dump_orange[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsSPSetLights1(dumpster_dump_orange_lights),
	gsSPEndDisplayList(),
};

Gfx mat_dumpster_dump_yellow[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsSPSetLights1(dumpster_dump_yellow_lights),
	gsSPEndDisplayList(),
};

Gfx dumpster_000_displaylist_mesh_layer_1[] = {
	gsSPDisplayList(mat_dumpster_dump_main),
	gsSPDisplayList(dumpster_000_displaylist_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_dumpster_dump_dark),
	gsSPDisplayList(dumpster_000_displaylist_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_dumpster_dump_black),
	gsSPDisplayList(dumpster_000_displaylist_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_dumpster_dump_blue),
	gsSPDisplayList(dumpster_000_displaylist_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_dumpster_dump_orange),
	gsSPDisplayList(dumpster_000_displaylist_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_dumpster_dump_yellow),
	gsSPDisplayList(dumpster_000_displaylist_mesh_layer_1_tri_5),
	gsSPEndDisplayList(),
};

Gfx dumpster_material_revert_render_settings[] = {
	gsDPPipeSync(),
	gsSPSetGeometryMode(G_LIGHTING),
	gsSPClearGeometryMode(G_TEXTURE_GEN),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPSetEnvColor(255, 255, 255, 255),
	gsDPSetAlphaCompare(G_AC_NONE),
	gsSPEndDisplayList(),
};

