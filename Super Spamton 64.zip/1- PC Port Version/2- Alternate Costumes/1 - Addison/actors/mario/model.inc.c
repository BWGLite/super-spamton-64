Lights1 mario_Spamton_Suit_f3d_v4_001_lights = gdSPDefLights1(
	0xD, 0xD, 0xD,
	0x1B, 0x1A, 0x1B, 0x28, 0x28, 0x28);

Lights1 mario_Spamton_Hands_f3d_v4_001_lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFE, 0xFE, 0xFE, 0x28, 0x28, 0x28);

Lights1 mario_face_0___eye_open_v4_001_lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFE, 0xFE, 0xFE, 0x28, 0x28, 0x28);

Lights1 mario_Spamton_Hair_f3d_v4_001_lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFE, 0xFE, 0xFE, 0x28, 0x28, 0x28);

Lights1 mario_face_1___eye_half_v4_001_lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFE, 0xFE, 0xFE, 0x28, 0x28, 0x28);

Lights1 mario_face_2___eye_closed_v4_001_lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFE, 0xFE, 0xFE, 0x28, 0x28, 0x28);

Lights1 mario_face_7___eye_X_v4_001_lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFE, 0xFE, 0xFE, 0x28, 0x28, 0x28);

Lights1 mario_Spamton_Wing2_f3d_v4_001_lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFE, 0xFE, 0xFE, 0x28, 0x28, 0x28);

Lights1 mario_Spamton_Wing1_f3d_v4_001_lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFE, 0xFE, 0xFE, 0x28, 0x28, 0x28);

Lights1 mario_pipis_001_lights = gdSPDefLights1(
	0x0, 0x5F, 0x7F,
	0x0, 0xBF, 0xFE, 0x28, 0x28, 0x28);

Lights1 mario_wing_2_v4_001_lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFE, 0xFE, 0xFE, 0x28, 0x28, 0x28);

Lights1 mario_wing_1_v4_001_lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFE, 0xFE, 0xFE, 0x28, 0x28, 0x28);

Lights1 mario_Spamton_Legs_f3d_v4_001_lights = gdSPDefLights1(
	0x5A, 0x73, 0xE,
	0xB4, 0xE6, 0x1D, 0x28, 0x28, 0x28);

Lights1 mario_Spamton_Metal_Wing2_001_lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFE, 0xFE, 0xFE, 0x28, 0x28, 0x28);

Lights1 mario_Spamton_Metal_Wing1_001_lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFE, 0xFE, 0xFE, 0x28, 0x28, 0x28);

Lights1 mario_metalwing2_001_lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFE, 0xFE, 0xFE, 0x28, 0x28, 0x28);

Lights1 mario_metakwing1_001_lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFE, 0xFE, 0xFE, 0x28, 0x28, 0x28);

Lights1 mario_Trans_Wing2_001_lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFE, 0xFE, 0xFE, 0x28, 0x28, 0x28);

Lights1 mario_Trans_Wing1_001_lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFE, 0xFE, 0xFE, 0x28, 0x28, 0x28);

Gfx mario_Head1_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 mario_Head1_rgba16[] = {
	#include "actors/mario/Head1.rgba16.inc.c"
};

Gfx mario_Head2_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 mario_Head2_rgba16[] = {
	#include "actors/mario/Head2.rgba16.inc.c"
};

Gfx mario_Head3_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 mario_Head3_rgba16[] = {
	#include "actors/mario/Head3.rgba16.inc.c"
};

Gfx mario_Head4_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 mario_Head4_rgba16[] = {
	#include "actors/mario/Head4.rgba16.inc.c"
};

Gfx mario_neo_wing2_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 mario_neo_wing2_rgba16[] = {
	#include "actors/mario/neo_wing2.rgba16.inc.c"
};

Gfx mario_neo_wing1_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 mario_neo_wing1_rgba16[] = {
	#include "actors/mario/neo_wing1.rgba16.inc.c"
};

Gfx mario_pipis_label_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 mario_pipis_label_rgba16[] = {
	#include "actors/mario/pipis_label.rgba16.inc.c"
};

Gfx mario_wing_2_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 mario_wing_2_rgba16[] = {
	#include "actors/mario/wing_2.rgba16.inc.c"
};

Gfx mario_wing1_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 mario_wing1_rgba16[] = {
	#include "actors/mario/wing1.rgba16.inc.c"
};

Gfx mario_metal_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 mario_metal_rgba16[] = {
	#include "actors/mario/metal.rgba16.inc.c"
};

Gfx mario_neo_wing_metal2_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 mario_neo_wing_metal2_rgba16[] = {
	#include "actors/mario/neo_wing_metal2.rgba16.inc.c"
};

Gfx mario_neo_wing_metal1_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 mario_neo_wing_metal1_rgba16[] = {
	#include "actors/mario/neo_wing_metal1.rgba16.inc.c"
};

Gfx mario_metal_pipis_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 mario_metal_pipis_rgba16[] = {
	#include "actors/mario/metal_pipis.rgba16.inc.c"
};

Gfx mario_mario_metal_wing_tip_unused_rgba16_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 mario_mario_metal_wing_tip_unused_rgba16_rgba16[] = {
	#include "actors/mario/mario_metal_wing_tip_unused_rgba16.rgba16.inc.c"
};

Gfx mario_mario_metal_wing_unused_rgba16_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 mario_mario_metal_wing_unused_rgba16_rgba16[] = {
	#include "actors/mario/mario_metal_wing_unused_rgba16.rgba16.inc.c"
};

Gfx mario_gold_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 mario_gold_rgba16[] = {
	#include "actors/mario/gold.rgba16.inc.c"
};

Gfx mario_neo_wing_gold2_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 mario_neo_wing_gold2_rgba16[] = {
	#include "actors/mario/neo_wing_gold2.rgba16.inc.c"
};

Gfx mario_neo_wing_gold1_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 mario_neo_wing_gold1_rgba16[] = {
	#include "actors/mario/neo_wing_gold1.rgba16.inc.c"
};

Vtx mario_000_offset_mesh_layer_1_vtx_0[5] = {
	{{{-8, 32, -83},0, {10, 679},{0xD5, 0x47, 0xA0, 0xFF}}},
	{{{-73, 35, -57},0, {47, 776},{0x96, 0x33, 0xD0, 0xFF}}},
	{{{-73, 41, 0},0, {134, 774},{0x8B, 0x31, 0x0, 0xFF}}},
	{{{-8, 32, 83},0, {261, 679},{0xD5, 0x47, 0x60, 0xFF}}},
	{{{-73, 35, 57},0, {221, 776},{0x96, 0x33, 0x30, 0xFF}}},
};

Gfx mario_000_offset_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_000_offset_mesh_layer_1_vtx_0 + 0, 5, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 2, 4, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_001_skinned_mesh_layer_1_vtx_0[12] = {
	{{{-8, 32, -83},0, {-43, 723},{0xD5, 0x47, 0xA0, 0xFF}}},
	{{{-73, 41, 0},0, {501, 1085},{0x8B, 0x31, 0x0, 0xFF}}},
	{{{-8, 32, 83},0, {1045, 723},{0xD5, 0x47, 0x60, 0xFF}}},
	{{{-8, 32, -83},0, {668, 281},{0xD5, 0x47, 0xA0, 0xFF}}},
	{{{-73, -29, -57},0, {515, 778},{0xA3, 0xC2, 0xC3, 0xFF}}},
	{{{-73, -32, 0},0, {428, 778},{0x99, 0xB5, 0x0, 0xFF}}},
	{{{-73, -29, 57},0, {341, 778},{0xA3, 0xC2, 0x3D, 0xFF}}},
	{{{-73, -29, -57},0, {570, 382},{0xA3, 0xC2, 0xC3, 0xFF}}},
	{{{-73, 35, -57},0, {668, 385},{0x96, 0x33, 0xD0, 0xFF}}},
	{{{-8, 32, 83},0, {770, 480},{0xD5, 0x47, 0x60, 0xFF}}},
	{{{-73, -29, 57},0, {673, 380},{0xA3, 0xC2, 0x3D, 0xFF}}},
	{{{-73, 35, 57},0, {770, 376},{0x96, 0x33, 0x30, 0xFF}}},
};

Gfx mario_000_offset_001_skinned_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_000_offset_001_skinned_mesh_layer_1_vtx_0 + 0, 12, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_001_mesh_layer_1_vtx_0[12] = {
	{{{-42, 54, 0},0, {501, 648},{0xD9, 0x79, 0x0, 0xFF}}},
	{{{-40, 21, -90},0, {-89, 640},{0xD2, 0x41, 0x9D, 0xFF}}},
	{{{-40, 21, 90},0, {1091, 640},{0xD2, 0x41, 0x63, 0xFF}}},
	{{{-40, 21, -90},0, {668, 257},{0xD2, 0x41, 0x9D, 0xFF}}},
	{{{-47, -12, -85},0, {617, 266},{0xD0, 0xF8, 0x8B, 0xFF}}},
	{{{-53, -45, -79},0, {567, 275},{0xDA, 0xAD, 0xA8, 0xFF}}},
	{{{-53, -45, -79},0, {548, 676},{0xDA, 0xAD, 0xA8, 0xFF}}},
	{{{-37, -64, 0},0, {428, 647},{0xEF, 0x82, 0x0, 0xFF}}},
	{{{-53, -45, 79},0, {307, 676},{0xDA, 0xAD, 0x58, 0xFF}}},
	{{{-47, -12, 85},0, {719, 495},{0xD0, 0xF8, 0x75, 0xFF}}},
	{{{-40, 21, 90},0, {770, 504},{0xD2, 0x41, 0x63, 0xFF}}},
	{{{-53, -45, 79},0, {669, 486},{0xDA, 0xAD, 0x58, 0xFF}}},
};

Gfx mario_000_offset_001_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_000_offset_001_mesh_layer_1_vtx_0 + 0, 12, 12),
	gsSP2Triangles(12, 13, 0, 0, 1, 12, 0, 0),
	gsSP2Triangles(1, 2, 12, 0, 12, 2, 14, 0),
	gsSP2Triangles(3, 15, 16, 0, 8, 3, 16, 0),
	gsSP2Triangles(7, 8, 16, 0, 16, 17, 7, 0),
	gsSP2Triangles(4, 18, 19, 0, 4, 19, 5, 0),
	gsSP2Triangles(6, 5, 19, 0, 6, 19, 20, 0),
	gsSP2Triangles(9, 21, 22, 0, 11, 21, 9, 0),
	gsSP2Triangles(10, 21, 11, 0, 21, 10, 23, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_001_mesh_layer_1_vtx_1[50] = {
	{{{71, 29, -101},0, {790, 717},{0x3F, 0x34, 0x9F, 0xFF}}},
	{{{38, 38, -49},0, {790, 626},{0x54, 0x5D, 0x15, 0xFF}}},
	{{{71, 12, -35},0, {741, 627},{0x69, 0x47, 0xF5, 0xFF}}},
	{{{71, 29, 101},0, {833, 717},{0x3F, 0x36, 0x60, 0xFF}}},
	{{{71, 12, 35},0, {833, 618},{0x69, 0x47, 0xB, 0xFF}}},
	{{{38, 38, 49},0, {790, 635},{0x54, 0x5D, 0xEB, 0xFF}}},
	{{{-33, -47, -87},0, {560, 646},{0xF8, 0xB9, 0x97, 0xFF}}},
	{{{72, -58, -91},0, {566, 485},{0x3F, 0xBB, 0xAA, 0xFF}}},
	{{{48, -72, 0},0, {428, 518},{0x31, 0x8B, 0x0, 0xFF}}},
	{{{-37, -64, 0},0, {428, 647},{0xEF, 0x82, 0x0, 0xFF}}},
	{{{-33, -47, 87},0, {295, 646},{0xF8, 0xB9, 0x69, 0xFF}}},
	{{{72, -58, 91},0, {290, 485},{0x3F, 0xBA, 0x56, 0xFF}}},
	{{{-37, -46, 86},0, {298, 652},{0xD7, 0xAE, 0x58, 0xFF}}},
	{{{-53, -45, 79},0, {307, 676},{0xDA, 0xAD, 0x58, 0xFF}}},
	{{{-37, -46, -86},0, {558, 652},{0xD7, 0xAE, 0xA8, 0xFF}}},
	{{{-53, -45, -79},0, {548, 676},{0xDA, 0xAD, 0xA8, 0xFF}}},
	{{{-47, -12, -85},0, {617, 266},{0xD0, 0xF8, 0x8B, 0xFF}}},
	{{{-40, 21, -90},0, {668, 257},{0xD2, 0x41, 0x9D, 0xFF}}},
	{{{-32, 20, -94},0, {668, 243},{0xF6, 0x2E, 0x8A, 0xFF}}},
	{{{-33, -47, -87},0, {566, 243},{0xF8, 0xB9, 0x97, 0xFF}}},
	{{{-37, -46, -86},0, {566, 250},{0xD7, 0xAE, 0xA8, 0xFF}}},
	{{{-53, -45, -79},0, {567, 275},{0xDA, 0xAD, 0xA8, 0xFF}}},
	{{{-47, -12, 85},0, {719, 495},{0xD0, 0xF8, 0x75, 0xFF}}},
	{{{-32, 20, 94},0, {770, 518},{0xF6, 0x2E, 0x76, 0xFF}}},
	{{{-40, 21, 90},0, {770, 504},{0xD2, 0x41, 0x63, 0xFF}}},
	{{{-33, -47, 87},0, {668, 518},{0xF8, 0xB9, 0x69, 0xFF}}},
	{{{-37, -46, 86},0, {668, 511},{0xD7, 0xAE, 0x58, 0xFF}}},
	{{{-53, -45, 79},0, {669, 486},{0xDA, 0xAD, 0x58, 0xFF}}},
	{{{-9, 66, 0},0, {501, 466},{0xFD, 0x7F, 0x0, 0xFF}}},
	{{{38, 38, -49},0, {181, 204},{0x54, 0x5D, 0x15, 0xFF}}},
	{{{71, 29, -101},0, {-159, 21},{0x3F, 0x34, 0x9F, 0xFF}}},
	{{{-32, 20, -94},0, {-115, 592},{0xF6, 0x2E, 0x8A, 0xFF}}},
	{{{-32, 20, -94},0, {-115, 592},{0xF6, 0x2E, 0x8A, 0xFF}}},
	{{{-40, 21, -90},0, {-89, 640},{0xD2, 0x41, 0x9D, 0xFF}}},
	{{{-9, 66, 0},0, {501, 466},{0xFD, 0x7F, 0x0, 0xFF}}},
	{{{-42, 54, 0},0, {501, 648},{0xD9, 0x79, 0x0, 0xFF}}},
	{{{-40, 21, 90},0, {1091, 640},{0xD2, 0x41, 0x63, 0xFF}}},
	{{{-32, 20, 94},0, {1117, 592},{0xF6, 0x2E, 0x76, 0xFF}}},
	{{{71, 29, 101},0, {1161, 21},{0x3F, 0x36, 0x60, 0xFF}}},
	{{{38, 38, 49},0, {821, 204},{0x54, 0x5D, 0xEB, 0xFF}}},
	{{{72, -58, -91},0, {741, 672},{0x3F, 0xBB, 0xAA, 0xFF}}},
	{{{71, 29, -101},0, {614, 642},{0x3F, 0x34, 0x9F, 0xFF}}},
	{{{71, 12, -35},0, {628, 745},{0x69, 0x47, 0xF5, 0xFF}}},
	{{{84, -7, -23},0, {656, 766},{0x7D, 0xB, 0xEB, 0xFF}}},
	{{{48, -72, 0},0, {741, 811},{0x31, 0x8B, 0x0, 0xFF}}},
	{{{88, -7, 0},0, {652, 801},{0x7F, 0x8, 0x0, 0xFF}}},
	{{{84, -7, 23},0, {647, 835},{0x7D, 0xB, 0x15, 0xFF}}},
	{{{72, -58, 91},0, {709, 946},{0x3F, 0xBA, 0x56, 0xFF}}},
	{{{71, 12, 35},0, {615, 849},{0x69, 0x47, 0xB, 0xFF}}},
	{{{71, 29, 101},0, {578, 946},{0x3F, 0x36, 0x60, 0xFF}}},
};

Gfx mario_000_offset_001_mesh_layer_1_tri_1[] = {
	gsSPVertex(mario_000_offset_001_mesh_layer_1_vtx_1 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(6, 7, 8, 0, 8, 9, 6, 0),
	gsSP2Triangles(8, 10, 9, 0, 10, 8, 11, 0),
	gsSP2Triangles(9, 10, 12, 0, 13, 9, 12, 0),
	gsSP2Triangles(9, 14, 6, 0, 15, 14, 9, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
	gsSP2Triangles(19, 20, 16, 0, 16, 20, 21, 0),
	gsSP2Triangles(22, 23, 24, 0, 22, 25, 23, 0),
	gsSP2Triangles(25, 22, 26, 0, 22, 27, 26, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 30, 31, 0),
	gsSPVertex(mario_000_offset_001_mesh_layer_1_vtx_1 + 32, 18, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 3, 2, 0),
	gsSP2Triangles(4, 2, 3, 0, 5, 2, 4, 0),
	gsSP2Triangles(2, 5, 6, 0, 2, 6, 7, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
	gsSP2Triangles(11, 12, 8, 0, 12, 11, 13, 0),
	gsSP2Triangles(12, 13, 14, 0, 14, 15, 12, 0),
	gsSP2Triangles(15, 14, 16, 0, 15, 16, 17, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_001_mesh_layer_1_vtx_2[12] = {
	{{{84, -7, -23},0, {656, 766},{0x7D, 0xB, 0xEB, 0xFF}}},
	{{{71, 12, -35},0, {628, 745},{0x69, 0x47, 0xF5, 0xFF}}},
	{{{88, -7, 0},0, {652, 801},{0x7F, 0x8, 0x0, 0xFF}}},
	{{{41, 45, 0},0, {566, 790},{0x46, 0x6A, 0x0, 0xFF}}},
	{{{71, 12, 35},0, {615, 849},{0x69, 0x47, 0xB, 0xFF}}},
	{{{84, -7, 23},0, {647, 835},{0x7D, 0xB, 0x15, 0xFF}}},
	{{{71, 12, -35},0, {275, 22},{0x69, 0x47, 0xF5, 0xFF}}},
	{{{38, 38, -49},0, {181, 204},{0x54, 0x5D, 0x15, 0xFF}}},
	{{{41, 45, 0},0, {501, 186},{0x46, 0x6A, 0x0, 0xFF}}},
	{{{-9, 66, 0},0, {501, 466},{0xFD, 0x7F, 0x0, 0xFF}}},
	{{{38, 38, 49},0, {821, 204},{0x54, 0x5D, 0xEB, 0xFF}}},
	{{{71, 12, 35},0, {727, 22},{0x69, 0x47, 0xB, 0xFF}}},
};

Gfx mario_000_offset_001_mesh_layer_1_tri_2[] = {
	gsSPVertex(mario_000_offset_001_mesh_layer_1_vtx_2 + 0, 12, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 3, 2, 0),
	gsSP2Triangles(4, 2, 3, 0, 5, 2, 4, 0),
	gsSP2Triangles(6, 7, 8, 0, 8, 7, 9, 0),
	gsSP2Triangles(8, 9, 10, 0, 11, 8, 10, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_displaylist_mesh_layer_4_vtx_0[100] = {
	{{{62, 284, 0},0, {275, 942},{0xED, 0x7E, 0x0, 0xFF}}},
	{{{84, 68, -56},0, {326, 942},{0xED, 0x5F, 0xAE, 0xFF}}},
	{{{62, 74, 0},0, {326, 891},{0x8D, 0x36, 0x0, 0xFF}}},
	{{{62, 74, 0},0, {326, 942},{0x8D, 0x36, 0x0, 0xFF}}},
	{{{84, 68, 56},0, {326, 891},{0xED, 0x5F, 0x52, 0xFF}}},
	{{{78, 90, 103},0, {275, 942},{0xE7, 0x5B, 0x55, 0xFF}}},
	{{{-43, 55, 56},0, {326, 891},{0xA4, 0x3C, 0x41, 0xFF}}},
	{{{3, 28, 76},0, {326, 942},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{-18, -27, 0},0, {275, 942},{0xBC, 0x9C, 0x27, 0xFF}}},
	{{{3, 28, 76},0, {326, 891},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{-43, 55, 56},0, {326, 942},{0xA4, 0x3C, 0x41, 0xFF}}},
	{{{-44, 55, 0},0, {326, 942},{0x91, 0x39, 0x1A, 0xFF}}},
	{{{68, 44, 114},0, {326, 942},{0xF5, 0xC, 0x7E, 0xFF}}},
	{{{-43, 55, -56},0, {275, 942},{0x90, 0x30, 0xDC, 0xFF}}},
	{{{-18, -27, 0},0, {326, 891},{0xBC, 0x9C, 0x27, 0xFF}}},
	{{{3, 28, -76},0, {326, 891},{0xB0, 0xF9, 0x9D, 0xFF}}},
	{{{-18, -27, 0},0, {326, 942},{0xBC, 0x9C, 0x27, 0xFF}}},
	{{{3, 28, -76},0, {275, 942},{0xB0, 0xF9, 0x9D, 0xFF}}},
	{{{-43, 55, -56},0, {326, 891},{0x90, 0x30, 0xDC, 0xFF}}},
	{{{78, 90, -103},0, {326, 942},{0xE5, 0x5B, 0xAB, 0xFF}}},
	{{{78, 90, -103},0, {326, 891},{0xE5, 0x5B, 0xAB, 0xFF}}},
	{{{68, 44, -113},0, {326, 942},{0xF2, 0x10, 0x83, 0xFF}}},
	{{{3, 28, -76},0, {275, 942},{0xB5, 0xFE, 0x99, 0xFF}}},
	{{{68, 44, -113},0, {326, 942},{0xF4, 0xE2, 0x85, 0xFF}}},
	{{{78, 90, -103},0, {326, 891},{0x10, 0x8D, 0xCC, 0xFF}}},
	{{{-43, 55, -56},0, {275, 942},{0x8B, 0xEC, 0xD2, 0xFF}}},
	{{{-18, -27, 0},0, {326, 942},{0x92, 0x1E, 0x38, 0xFF}}},
	{{{3, 28, -76},0, {326, 891},{0xB5, 0xFE, 0x99, 0xFF}}},
	{{{78, 90, -103},0, {326, 942},{0x10, 0x8D, 0xCC, 0xFF}}},
	{{{-43, 55, -56},0, {326, 891},{0x8B, 0xEC, 0xD2, 0xFF}}},
	{{{-44, 55, 0},0, {326, 942},{0x94, 0xC3, 0xE6, 0xFF}}},
	{{{-18, -27, 0},0, {326, 891},{0x92, 0x1E, 0x38, 0xFF}}},
	{{{62, 284, 0},0, {275, 942},{0xF2, 0x82, 0x0, 0xFF}}},
	{{{84, 68, 56},0, {326, 891},{0xED, 0xA1, 0x52, 0xFF}}},
	{{{62, 74, 0},0, {326, 942},{0x8D, 0xCA, 0x0, 0xFF}}},
	{{{-18, -27, 0},0, {275, 942},{0x92, 0x1E, 0x38, 0xFF}}},
	{{{-44, 55, 0},0, {326, 942},{0x94, 0xC3, 0xE6, 0xFF}}},
	{{{-43, 55, 56},0, {326, 891},{0x91, 0xCE, 0x26, 0xFF}}},
	{{{-43, 55, 56},0, {326, 942},{0x91, 0xCE, 0x26, 0xFF}}},
	{{{3, 28, 76},0, {326, 891},{0xD5, 0xFC, 0x77, 0xFF}}},
	{{{78, 90, 103},0, {275, 942},{0xEB, 0xAD, 0x5E, 0xFF}}},
	{{{68, 44, 114},0, {326, 942},{0x3, 0xE6, 0x7C, 0xFF}}},
	{{{3, 28, 76},0, {326, 942},{0xD5, 0xFC, 0x77, 0xFF}}},
	{{{62, 74, 0},0, {326, 891},{0x8D, 0xCA, 0x0, 0xFF}}},
	{{{84, 68, -56},0, {326, 942},{0xED, 0xA1, 0xAE, 0xFF}}},
	{{{125, 78, 0},0, {283, 452},{0x7A, 0x25, 0x0, 0xFF}}},
	{{{84, 68, -56},0, {264, 814},{0xED, 0x5F, 0xAE, 0xFF}}},
	{{{62, 284, 0},0, {283, 814},{0xED, 0x7E, 0x0, 0xFF}}},
	{{{84, 68, 56},0, {302, 814},{0xED, 0x5F, 0x52, 0xFF}}},
	{{{206, 72, 89},0, {276, 452},{0xD1, 0x57, 0x50, 0xFF}}},
	{{{111, 73, 89},0, {275, 666},{0x18, 0x62, 0x4E, 0xFF}}},
	{{{109, 3, 102},0, {322, 670},{0xF5, 0x5, 0x7E, 0xFF}}},
	{{{68, 44, 114},0, {294, 765},{0xF5, 0xC, 0x7E, 0xFF}}},
	{{{78, 90, 103},0, {273, 741},{0xE7, 0x5B, 0x55, 0xFF}}},
	{{{206, 80, 0},0, {512, 464},{0xC7, 0x72, 0x0, 0xFF}}},
	{{{111, 73, 89},0, {344, 668},{0x18, 0x62, 0x4E, 0xFF}}},
	{{{206, 72, 89},0, {343, 460},{0xD1, 0x57, 0x50, 0xFF}}},
	{{{111, 85, 0},0, {512, 668},{0xD, 0x7E, 0xE, 0xFF}}},
	{{{111, 73, -89},0, {680, 668},{0x15, 0x63, 0xB4, 0xFF}}},
	{{{206, 72, -89},0, {681, 460},{0xEA, 0x4E, 0x9E, 0xFF}}},
	{{{78, 90, 0},0, {512, 739},{0xE8, 0x7D, 0x3, 0xFF}}},
	{{{78, 90, 103},0, {318, 739},{0xE7, 0x5B, 0x55, 0xFF}}},
	{{{-43, 55, 56},0, {408, 955},{0xA4, 0x3C, 0x41, 0xFF}}},
	{{{-44, 55, 0},0, {512, 956},{0x91, 0x39, 0x1A, 0xFF}}},
	{{{-43, 55, -56},0, {616, 955},{0x90, 0x30, 0xDC, 0xFF}}},
	{{{-44, 55, 0},0, {512, 956},{0x91, 0x39, 0x1A, 0xFF}}},
	{{{78, 90, 0},0, {512, 739},{0xE8, 0x7D, 0x3, 0xFF}}},
	{{{78, 90, -103},0, {706, 739},{0xE5, 0x5B, 0xAB, 0xFF}}},
	{{{111, 73, -89},0, {680, 668},{0x15, 0x63, 0xB4, 0xFF}}},
	{{{206, 72, -89},0, {276, 452},{0xEA, 0x4E, 0x9E, 0xFF}}},
	{{{109, 3, -102},0, {322, 670},{0x1, 0xF6, 0x81, 0xFF}}},
	{{{111, 73, -89},0, {275, 666},{0x15, 0x63, 0xB4, 0xFF}}},
	{{{68, 44, -113},0, {294, 765},{0xF2, 0x10, 0x83, 0xFF}}},
	{{{78, 90, -103},0, {273, 741},{0xE5, 0x5B, 0xAB, 0xFF}}},
	{{{206, 72, -89},0, {276, 452},{0xFB, 0x8E, 0xC9, 0xFF}}},
	{{{111, 73, -89},0, {275, 666},{0x1E, 0xB2, 0xA0, 0xFF}}},
	{{{109, 3, -102},0, {322, 670},{0x1A, 0xE9, 0x86, 0xFF}}},
	{{{68, 44, -113},0, {294, 765},{0xF4, 0xE2, 0x85, 0xFF}}},
	{{{78, 90, -103},0, {273, 741},{0x10, 0x8D, 0xCC, 0xFF}}},
	{{{111, 73, -89},0, {680, 668},{0x1E, 0xB2, 0xA0, 0xFF}}},
	{{{206, 72, -89},0, {681, 460},{0xFB, 0x8E, 0xC9, 0xFF}}},
	{{{206, 80, 0},0, {512, 464},{0x3, 0x82, 0xF5, 0xFF}}},
	{{{111, 85, 0},0, {512, 668},{0xFF, 0x81, 0x0, 0xFF}}},
	{{{111, 73, 89},0, {344, 668},{0x16, 0xA7, 0x57, 0xFF}}},
	{{{206, 72, 89},0, {343, 460},{0x1, 0x87, 0x28, 0xFF}}},
	{{{78, 90, 0},0, {512, 739},{0x1, 0x83, 0xEB, 0xFF}}},
	{{{78, 90, -103},0, {706, 739},{0x10, 0x8D, 0xCC, 0xFF}}},
	{{{-43, 55, -56},0, {616, 955},{0x8B, 0xEC, 0xD2, 0xFF}}},
	{{{-44, 55, 0},0, {512, 956},{0x94, 0xC3, 0xE6, 0xFF}}},
	{{{-43, 55, 56},0, {408, 955},{0x91, 0xCE, 0x26, 0xFF}}},
	{{{78, 90, 103},0, {318, 739},{0xEB, 0xAD, 0x5E, 0xFF}}},
	{{{125, 78, 0},0, {283, 452},{0x7A, 0xDB, 0x0, 0xFF}}},
	{{{84, 68, 56},0, {302, 814},{0xED, 0xA1, 0x52, 0xFF}}},
	{{{62, 284, 0},0, {283, 814},{0xF2, 0x82, 0x0, 0xFF}}},
	{{{84, 68, -56},0, {264, 814},{0xED, 0xA1, 0xAE, 0xFF}}},
	{{{206, 72, 89},0, {276, 452},{0x1, 0x87, 0x28, 0xFF}}},
	{{{109, 3, 102},0, {322, 670},{0x1B, 0xE9, 0x7A, 0xFF}}},
	{{{111, 73, 89},0, {275, 666},{0x16, 0xA7, 0x57, 0xFF}}},
	{{{68, 44, 114},0, {294, 765},{0x3, 0xE6, 0x7C, 0xFF}}},
	{{{78, 90, 103},0, {273, 741},{0xEB, 0xAD, 0x5E, 0xFF}}},
};

Gfx mario_000_displaylist_mesh_layer_4_tri_0[] = {
	gsSPVertex(mario_000_displaylist_mesh_layer_4_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 4, 0),
	gsSP2Triangles(5, 6, 7, 0, 8, 9, 10, 0),
	gsSP2Triangles(8, 6, 11, 0, 5, 9, 12, 0),
	gsSP2Triangles(13, 14, 11, 0, 13, 15, 16, 0),
	gsSP2Triangles(17, 18, 19, 0, 17, 20, 21, 0),
	gsSP2Triangles(22, 23, 24, 0, 25, 26, 27, 0),
	gsSP2Triangles(22, 28, 29, 0, 25, 30, 31, 0),
	gsSPVertex(mario_000_displaylist_mesh_layer_4_vtx_0 + 32, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(3, 6, 7, 0, 8, 9, 7, 0),
	gsSP2Triangles(8, 10, 5, 0, 0, 11, 12, 0),
	gsSP2Triangles(13, 14, 15, 0, 13, 15, 16, 0),
	gsSP2Triangles(17, 18, 19, 0, 18, 20, 19, 0),
	gsSP2Triangles(18, 21, 20, 0, 22, 23, 24, 0),
	gsSP2Triangles(22, 25, 23, 0, 26, 25, 22, 0),
	gsSP2Triangles(26, 22, 27, 0, 28, 25, 26, 0),
	gsSP2Triangles(28, 23, 25, 0, 28, 29, 23, 0),
	gsSP2Triangles(28, 30, 29, 0, 28, 31, 30, 0),
	gsSPVertex(mario_000_displaylist_mesh_layer_4_vtx_0 + 64, 31, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(2, 4, 3, 0, 5, 6, 7, 0),
	gsSP2Triangles(8, 7, 6, 0, 8, 9, 7, 0),
	gsSP2Triangles(10, 11, 12, 0, 13, 12, 11, 0),
	gsSP2Triangles(13, 11, 14, 0, 15, 16, 17, 0),
	gsSP2Triangles(15, 17, 18, 0, 17, 19, 18, 0),
	gsSP2Triangles(17, 20, 19, 0, 21, 18, 19, 0),
	gsSP2Triangles(21, 15, 18, 0, 21, 22, 15, 0),
	gsSP2Triangles(23, 22, 21, 0, 23, 21, 24, 0),
	gsSP2Triangles(21, 25, 24, 0, 21, 26, 25, 0),
	gsSP2Triangles(21, 19, 26, 0, 27, 28, 29, 0),
	gsSP1Triangle(27, 29, 30, 0),
	gsSPVertex(mario_000_displaylist_mesh_layer_4_vtx_0 + 95, 5, 0),
	gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
	gsSP1Triangle(2, 3, 4, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_displaylist_mesh_layer_1_vtx_0[59] = {
	{{{-6, -27, 65},0, {112, 496},{0xD8, 0xB6, 0x5F, 0xFF}}},
	{{{3, 28, 76},0, {112, 368},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{-18, -27, 0},0, {240, 368},{0xBC, 0x9C, 0x27, 0xFF}}},
	{{{83, -104, 145},0, {240, 496},{0x57, 0x25, 0x55, 0xFF}}},
	{{{-6, -27, 0},0, {112, 496},{0xD1, 0xA6, 0xB4, 0xFF}}},
	{{{3, 28, -76},0, {112, 368},{0xB0, 0xF9, 0x9D, 0xFF}}},
	{{{206, 80, 0},0, {624, 112},{0xC7, 0x72, 0x0, 0xFF}}},
	{{{206, 72, 89},0, {624, -16},{0xD1, 0x57, 0x50, 0xFF}}},
	{{{242, 95, 86},0, {624, -16},{0x2A, 0x6F, 0x2D, 0xFF}}},
	{{{242, 121, 0},0, {624, 112},{0xFF, 0x7A, 0x23, 0xFF}}},
	{{{242, 95, -86},0, {624, -16},{0x30, 0x64, 0xC2, 0xFF}}},
	{{{206, 72, -89},0, {624, -16},{0xEA, 0x4E, 0x9E, 0xFF}}},
	{{{206, 72, 89},0, {624, 1008},{0xD1, 0x57, 0x50, 0xFF}}},
	{{{255, 10, 136},0, {624, 880},{0x29, 0x1E, 0x74, 0xFF}}},
	{{{242, 95, 86},0, {624, 1008},{0x2A, 0x6F, 0x2D, 0xFF}}},
	{{{188, -10, 104},0, {624, 880},{0xED, 0x31, 0x74, 0xFF}}},
	{{{109, 3, 102},0, {560, 880},{0xF5, 0x5, 0x7E, 0xFF}}},
	{{{216, -77, 182},0, {560, 752},{0x4D, 0x2, 0x65, 0xFF}}},
	{{{88, -72, 77},0, {496, 752},{0x1, 0xF5, 0x7F, 0xFF}}},
	{{{68, 44, 114},0, {496, 880},{0xF5, 0xC, 0x7E, 0xFF}}},
	{{{3, 28, 76},0, {368, 880},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{-6, -27, 65},0, {368, 752},{0xD8, 0xB6, 0x5F, 0xFF}}},
	{{{83, -104, 145},0, {368, 624},{0x57, 0x25, 0x55, 0xFF}}},
	{{{83, -168, 0},0, {496, 624},{0x52, 0xA6, 0xDC, 0xFF}}},
	{{{-6, -27, 0},0, {368, 752},{0xD1, 0xA6, 0xB4, 0xFF}}},
	{{{60, -72, -77},0, {496, 752},{0xC9, 0xBF, 0xA1, 0xFF}}},
	{{{3, 28, -76},0, {368, 880},{0xB0, 0xF9, 0x9D, 0xFF}}},
	{{{68, 44, -113},0, {496, 880},{0xF2, 0x10, 0x83, 0xFF}}},
	{{{109, 3, -102},0, {560, 880},{0x1, 0xF6, 0x81, 0xFF}}},
	{{{88, -77, -82},0, {560, 752},{0xFC, 0xBE, 0x93, 0xFF}}},
	{{{188, -10, -104},0, {624, 880},{0x3, 0x0, 0x81, 0xFF}}},
	{{{206, 72, -89},0, {624, 1008},{0xEA, 0x4E, 0x9E, 0xFF}}},
	{{{258, 10, -94},0, {624, 880},{0x53, 0xF, 0xA1, 0xFF}}},
	{{{188, -10, -104},0, {624, 880},{0x3, 0x0, 0x81, 0xFF}}},
	{{{206, 72, -89},0, {624, 1008},{0xEA, 0x4E, 0x9E, 0xFF}}},
	{{{242, 95, -86},0, {624, 1008},{0x30, 0x64, 0xC2, 0xFF}}},
	{{{258, -49, -84},0, {624, 752},{0x5E, 0xCB, 0xBD, 0xFF}}},
	{{{200, -99, -92},0, {624, 752},{0x2A, 0xB4, 0xA4, 0xFF}}},
	{{{199, -129, 0},0, {624, 624},{0x40, 0x92, 0x7, 0xFF}}},
	{{{265, -55, 0},0, {624, 624},{0x6E, 0xC4, 0x18, 0xFF}}},
	{{{212, -70, 128},0, {624, 752},{0x3F, 0x92, 0xFE, 0xFF}}},
	{{{274, -49, 200},0, {624, 752},{0x2F, 0x1A, 0x73, 0xFF}}},
	{{{255, 10, 136},0, {624, 880},{0x29, 0x1E, 0x74, 0xFF}}},
	{{{188, -10, 104},0, {624, 880},{0xED, 0x31, 0x74, 0xFF}}},
	{{{216, -77, 182},0, {560, 752},{0x4D, 0x2, 0x65, 0xFF}}},
	{{{88, -109, 0},0, {560, 624},{0x5E, 0xB1, 0x22, 0xFF}}},
	{{{88, -72, 77},0, {496, 752},{0x1, 0xF5, 0x7F, 0xFF}}},
	{{{83, -168, 0},0, {496, 624},{0x52, 0xA6, 0xDC, 0xFF}}},
	{{{88, -77, -82},0, {560, 752},{0xFC, 0xBE, 0x93, 0xFF}}},
	{{{60, -72, -77},0, {496, 752},{0xC9, 0xBF, 0xA1, 0xFF}}},
	{{{265, -55, 0},0, {752, 496},{0x6E, 0xC4, 0x18, 0xFF}}},
	{{{255, 10, 136},0, {880, 368},{0x29, 0x1E, 0x74, 0xFF}}},
	{{{274, -49, 200},0, {880, 496},{0x2F, 0x1A, 0x73, 0xFF}}},
	{{{285, 73, 0},0, {752, 368},{0x6D, 0x42, 0xFE, 0xFF}}},
	{{{258, 10, -94},0, {880, 368},{0x53, 0xF, 0xA1, 0xFF}}},
	{{{258, -49, -84},0, {880, 496},{0x5E, 0xCB, 0xBD, 0xFF}}},
	{{{242, 95, -86},0, {880, 240},{0x30, 0x64, 0xC2, 0xFF}}},
	{{{242, 121, 0},0, {752, 240},{0xFF, 0x7A, 0x23, 0xFF}}},
	{{{242, 95, 86},0, {880, 240},{0x2A, 0x6F, 0x2D, 0xFF}}},
};

Gfx mario_000_displaylist_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_000_displaylist_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 3, 2, 0, 4, 2, 5, 0),
	gsSP2Triangles(6, 7, 8, 0, 6, 8, 9, 0),
	gsSP2Triangles(10, 6, 9, 0, 10, 11, 6, 0),
	gsSP2Triangles(12, 13, 14, 0, 12, 15, 13, 0),
	gsSP2Triangles(12, 16, 15, 0, 15, 16, 17, 0),
	gsSP2Triangles(16, 18, 17, 0, 16, 19, 18, 0),
	gsSP2Triangles(20, 18, 19, 0, 20, 21, 18, 0),
	gsSP2Triangles(18, 21, 22, 0, 18, 22, 23, 0),
	gsSP2Triangles(24, 23, 22, 0, 24, 25, 23, 0),
	gsSP2Triangles(26, 25, 24, 0, 26, 27, 25, 0),
	gsSP2Triangles(28, 25, 27, 0, 28, 29, 25, 0),
	gsSP2Triangles(30, 29, 28, 0, 31, 30, 28, 0),
	gsSPVertex(mario_000_displaylist_mesh_layer_1_vtx_0 + 32, 27, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 1, 0, 0, 4, 5, 1, 0),
	gsSP2Triangles(6, 5, 4, 0, 6, 4, 7, 0),
	gsSP2Triangles(8, 6, 7, 0, 8, 7, 9, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
	gsSP2Triangles(11, 12, 8, 0, 8, 12, 13, 0),
	gsSP2Triangles(14, 13, 12, 0, 14, 15, 13, 0),
	gsSP2Triangles(15, 16, 13, 0, 15, 17, 16, 0),
	gsSP2Triangles(13, 16, 5, 0, 1, 5, 16, 0),
	gsSP2Triangles(13, 5, 6, 0, 8, 13, 6, 0),
	gsSP2Triangles(18, 19, 20, 0, 18, 21, 19, 0),
	gsSP2Triangles(18, 22, 21, 0, 18, 23, 22, 0),
	gsSP2Triangles(21, 22, 24, 0, 21, 24, 25, 0),
	gsSP2Triangles(21, 25, 26, 0, 21, 26, 19, 0),
	gsSPEndDisplayList(),
};

Vtx mario_002_switch_option_head__no_cap__mesh_layer_4_vtx_0[100] = {
	{{{62, 295, 0},0, {275, 942},{0xED, 0x7E, 0x0, 0xFF}}},
	{{{84, 79, -56},0, {326, 942},{0xED, 0x5F, 0xAE, 0xFF}}},
	{{{62, 85, 0},0, {326, 891},{0x8D, 0x36, 0x0, 0xFF}}},
	{{{62, 85, 0},0, {326, 942},{0x8D, 0x36, 0x0, 0xFF}}},
	{{{84, 79, 56},0, {326, 891},{0xED, 0x5F, 0x52, 0xFF}}},
	{{{78, 101, 103},0, {275, 942},{0xE7, 0x5B, 0x55, 0xFF}}},
	{{{-43, 66, 56},0, {326, 891},{0xA4, 0x3C, 0x41, 0xFF}}},
	{{{3, 40, 76},0, {326, 942},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{-18, -16, 0},0, {275, 942},{0xBC, 0x9C, 0x27, 0xFF}}},
	{{{3, 40, 76},0, {326, 891},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{-43, 66, 56},0, {326, 942},{0xA4, 0x3C, 0x41, 0xFF}}},
	{{{-44, 66, 0},0, {326, 942},{0x91, 0x39, 0x1A, 0xFF}}},
	{{{68, 56, 114},0, {326, 942},{0xF5, 0xC, 0x7E, 0xFF}}},
	{{{-43, 66, -56},0, {275, 942},{0x90, 0x30, 0xDC, 0xFF}}},
	{{{-18, -16, 0},0, {326, 891},{0xBC, 0x9C, 0x27, 0xFF}}},
	{{{3, 40, -76},0, {326, 891},{0xB0, 0xF9, 0x9D, 0xFF}}},
	{{{-18, -16, 0},0, {326, 942},{0xBC, 0x9C, 0x27, 0xFF}}},
	{{{3, 40, -76},0, {275, 942},{0xB0, 0xF9, 0x9D, 0xFF}}},
	{{{-43, 66, -56},0, {326, 891},{0x90, 0x30, 0xDC, 0xFF}}},
	{{{78, 101, -103},0, {326, 942},{0xE5, 0x5B, 0xAB, 0xFF}}},
	{{{78, 101, -103},0, {326, 891},{0xE5, 0x5B, 0xAB, 0xFF}}},
	{{{68, 56, -113},0, {326, 942},{0xF2, 0x10, 0x83, 0xFF}}},
	{{{3, 40, -76},0, {275, 942},{0xB5, 0xFE, 0x99, 0xFF}}},
	{{{68, 56, -113},0, {326, 942},{0xF4, 0xE2, 0x85, 0xFF}}},
	{{{78, 101, -103},0, {326, 891},{0x10, 0x8D, 0xCC, 0xFF}}},
	{{{-43, 66, -56},0, {275, 942},{0x8B, 0xEC, 0xD2, 0xFF}}},
	{{{-18, -16, 0},0, {326, 942},{0x92, 0x1E, 0x38, 0xFF}}},
	{{{3, 40, -76},0, {326, 891},{0xB5, 0xFE, 0x99, 0xFF}}},
	{{{78, 101, -103},0, {326, 942},{0x10, 0x8D, 0xCC, 0xFF}}},
	{{{-43, 66, -56},0, {326, 891},{0x8B, 0xEC, 0xD2, 0xFF}}},
	{{{-44, 66, 0},0, {326, 942},{0x94, 0xC3, 0xE6, 0xFF}}},
	{{{-18, -16, 0},0, {326, 891},{0x92, 0x1E, 0x38, 0xFF}}},
	{{{62, 295, 0},0, {275, 942},{0xF2, 0x82, 0x0, 0xFF}}},
	{{{84, 79, 56},0, {326, 891},{0xED, 0xA1, 0x52, 0xFF}}},
	{{{62, 85, 0},0, {326, 942},{0x8D, 0xCA, 0x0, 0xFF}}},
	{{{-18, -16, 0},0, {275, 942},{0x92, 0x1E, 0x38, 0xFF}}},
	{{{-44, 66, 0},0, {326, 942},{0x94, 0xC3, 0xE6, 0xFF}}},
	{{{-43, 66, 56},0, {326, 891},{0x91, 0xCE, 0x26, 0xFF}}},
	{{{-43, 66, 56},0, {326, 942},{0x91, 0xCE, 0x26, 0xFF}}},
	{{{3, 40, 76},0, {326, 891},{0xD5, 0xFC, 0x77, 0xFF}}},
	{{{78, 101, 103},0, {275, 942},{0xEB, 0xAD, 0x5E, 0xFF}}},
	{{{68, 56, 114},0, {326, 942},{0x3, 0xE6, 0x7C, 0xFF}}},
	{{{3, 40, 76},0, {326, 942},{0xD5, 0xFC, 0x77, 0xFF}}},
	{{{62, 85, 0},0, {326, 891},{0x8D, 0xCA, 0x0, 0xFF}}},
	{{{84, 79, -56},0, {326, 942},{0xED, 0xA1, 0xAE, 0xFF}}},
	{{{125, 89, 0},0, {283, 452},{0x7A, 0x25, 0x0, 0xFF}}},
	{{{84, 79, -56},0, {264, 814},{0xED, 0x5F, 0xAE, 0xFF}}},
	{{{62, 295, 0},0, {283, 814},{0xED, 0x7E, 0x0, 0xFF}}},
	{{{84, 79, 56},0, {302, 814},{0xED, 0x5F, 0x52, 0xFF}}},
	{{{206, 83, 89},0, {276, 452},{0xD1, 0x57, 0x50, 0xFF}}},
	{{{111, 84, 89},0, {275, 666},{0x18, 0x62, 0x4E, 0xFF}}},
	{{{109, 14, 102},0, {322, 670},{0xF5, 0x5, 0x7E, 0xFF}}},
	{{{68, 56, 114},0, {294, 765},{0xF5, 0xC, 0x7E, 0xFF}}},
	{{{78, 101, 103},0, {273, 741},{0xE7, 0x5B, 0x55, 0xFF}}},
	{{{206, 91, 0},0, {512, 464},{0xC7, 0x72, 0x0, 0xFF}}},
	{{{111, 84, 89},0, {344, 668},{0x18, 0x62, 0x4E, 0xFF}}},
	{{{206, 83, 89},0, {343, 460},{0xD1, 0x57, 0x50, 0xFF}}},
	{{{111, 96, 0},0, {512, 668},{0xD, 0x7E, 0xE, 0xFF}}},
	{{{111, 84, -89},0, {680, 668},{0x15, 0x63, 0xB4, 0xFF}}},
	{{{206, 83, -89},0, {681, 460},{0xEA, 0x4E, 0x9E, 0xFF}}},
	{{{78, 101, 0},0, {512, 739},{0xE8, 0x7D, 0x3, 0xFF}}},
	{{{78, 101, 103},0, {318, 739},{0xE7, 0x5B, 0x55, 0xFF}}},
	{{{-43, 66, 56},0, {408, 955},{0xA4, 0x3C, 0x41, 0xFF}}},
	{{{-44, 66, 0},0, {512, 956},{0x91, 0x39, 0x1A, 0xFF}}},
	{{{-43, 66, -56},0, {616, 955},{0x90, 0x30, 0xDC, 0xFF}}},
	{{{-44, 66, 0},0, {512, 956},{0x91, 0x39, 0x1A, 0xFF}}},
	{{{78, 101, 0},0, {512, 739},{0xE8, 0x7D, 0x3, 0xFF}}},
	{{{78, 101, -103},0, {706, 739},{0xE5, 0x5B, 0xAB, 0xFF}}},
	{{{111, 84, -89},0, {680, 668},{0x15, 0x63, 0xB4, 0xFF}}},
	{{{206, 83, -89},0, {276, 452},{0xEA, 0x4E, 0x9E, 0xFF}}},
	{{{109, 14, -102},0, {322, 670},{0x1, 0xF6, 0x81, 0xFF}}},
	{{{111, 84, -89},0, {275, 666},{0x15, 0x63, 0xB4, 0xFF}}},
	{{{68, 56, -113},0, {294, 765},{0xF2, 0x10, 0x83, 0xFF}}},
	{{{78, 101, -103},0, {273, 741},{0xE5, 0x5B, 0xAB, 0xFF}}},
	{{{206, 83, -89},0, {276, 452},{0xFB, 0x8E, 0xC9, 0xFF}}},
	{{{111, 84, -89},0, {275, 666},{0x1E, 0xB2, 0xA0, 0xFF}}},
	{{{109, 14, -102},0, {322, 670},{0x1A, 0xE9, 0x86, 0xFF}}},
	{{{68, 56, -113},0, {294, 765},{0xF4, 0xE2, 0x85, 0xFF}}},
	{{{78, 101, -103},0, {273, 741},{0x10, 0x8D, 0xCC, 0xFF}}},
	{{{111, 84, -89},0, {680, 668},{0x1E, 0xB2, 0xA0, 0xFF}}},
	{{{206, 83, -89},0, {681, 460},{0xFB, 0x8E, 0xC9, 0xFF}}},
	{{{206, 91, 0},0, {512, 464},{0x3, 0x82, 0xF5, 0xFF}}},
	{{{111, 96, 0},0, {512, 668},{0xFF, 0x81, 0x0, 0xFF}}},
	{{{111, 84, 89},0, {344, 668},{0x16, 0xA7, 0x57, 0xFF}}},
	{{{206, 83, 89},0, {343, 460},{0x1, 0x87, 0x28, 0xFF}}},
	{{{78, 101, 0},0, {512, 739},{0x1, 0x83, 0xEB, 0xFF}}},
	{{{78, 101, -103},0, {706, 739},{0x10, 0x8D, 0xCC, 0xFF}}},
	{{{-43, 66, -56},0, {616, 955},{0x8B, 0xEC, 0xD2, 0xFF}}},
	{{{-44, 66, 0},0, {512, 956},{0x94, 0xC3, 0xE6, 0xFF}}},
	{{{-43, 66, 56},0, {408, 955},{0x91, 0xCE, 0x26, 0xFF}}},
	{{{78, 101, 103},0, {318, 739},{0xEB, 0xAD, 0x5E, 0xFF}}},
	{{{125, 89, 0},0, {283, 452},{0x7A, 0xDB, 0x0, 0xFF}}},
	{{{84, 79, 56},0, {302, 814},{0xED, 0xA1, 0x52, 0xFF}}},
	{{{62, 295, 0},0, {283, 814},{0xF2, 0x82, 0x0, 0xFF}}},
	{{{84, 79, -56},0, {264, 814},{0xED, 0xA1, 0xAE, 0xFF}}},
	{{{206, 83, 89},0, {276, 452},{0x1, 0x87, 0x28, 0xFF}}},
	{{{109, 14, 102},0, {322, 670},{0x1B, 0xE9, 0x7A, 0xFF}}},
	{{{111, 84, 89},0, {275, 666},{0x16, 0xA7, 0x57, 0xFF}}},
	{{{68, 56, 114},0, {294, 765},{0x3, 0xE6, 0x7C, 0xFF}}},
	{{{78, 101, 103},0, {273, 741},{0xEB, 0xAD, 0x5E, 0xFF}}},
};

Gfx mario_002_switch_option_head__no_cap__mesh_layer_4_tri_0[] = {
	gsSPVertex(mario_002_switch_option_head__no_cap__mesh_layer_4_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 4, 0),
	gsSP2Triangles(5, 6, 7, 0, 8, 9, 10, 0),
	gsSP2Triangles(8, 6, 11, 0, 5, 9, 12, 0),
	gsSP2Triangles(13, 14, 11, 0, 13, 15, 16, 0),
	gsSP2Triangles(17, 18, 19, 0, 17, 20, 21, 0),
	gsSP2Triangles(22, 23, 24, 0, 25, 26, 27, 0),
	gsSP2Triangles(22, 28, 29, 0, 25, 30, 31, 0),
	gsSPVertex(mario_002_switch_option_head__no_cap__mesh_layer_4_vtx_0 + 32, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(3, 6, 7, 0, 8, 9, 7, 0),
	gsSP2Triangles(8, 10, 5, 0, 0, 11, 12, 0),
	gsSP2Triangles(13, 14, 15, 0, 13, 15, 16, 0),
	gsSP2Triangles(17, 18, 19, 0, 18, 20, 19, 0),
	gsSP2Triangles(18, 21, 20, 0, 22, 23, 24, 0),
	gsSP2Triangles(22, 25, 23, 0, 26, 25, 22, 0),
	gsSP2Triangles(26, 22, 27, 0, 28, 25, 26, 0),
	gsSP2Triangles(28, 23, 25, 0, 28, 29, 23, 0),
	gsSP2Triangles(28, 30, 29, 0, 28, 31, 30, 0),
	gsSPVertex(mario_002_switch_option_head__no_cap__mesh_layer_4_vtx_0 + 64, 31, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(2, 4, 3, 0, 5, 6, 7, 0),
	gsSP2Triangles(8, 7, 6, 0, 8, 9, 7, 0),
	gsSP2Triangles(10, 11, 12, 0, 13, 12, 11, 0),
	gsSP2Triangles(13, 11, 14, 0, 15, 16, 17, 0),
	gsSP2Triangles(15, 17, 18, 0, 17, 19, 18, 0),
	gsSP2Triangles(17, 20, 19, 0, 21, 18, 19, 0),
	gsSP2Triangles(21, 15, 18, 0, 21, 22, 15, 0),
	gsSP2Triangles(23, 22, 21, 0, 23, 21, 24, 0),
	gsSP2Triangles(21, 25, 24, 0, 21, 26, 25, 0),
	gsSP2Triangles(21, 19, 26, 0, 27, 28, 29, 0),
	gsSP1Triangle(27, 29, 30, 0),
	gsSPVertex(mario_002_switch_option_head__no_cap__mesh_layer_4_vtx_0 + 95, 5, 0),
	gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
	gsSP1Triangle(2, 3, 4, 0),
	gsSPEndDisplayList(),
};

Vtx mario_002_switch_option_head__no_cap__mesh_layer_1_vtx_0[59] = {
	{{{-6, -16, 65},0, {112, 496},{0xD8, 0xB6, 0x5F, 0xFF}}},
	{{{3, 40, 76},0, {112, 368},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{-18, -16, 0},0, {240, 368},{0xBC, 0x9C, 0x27, 0xFF}}},
	{{{83, -93, 145},0, {240, 496},{0x57, 0x25, 0x55, 0xFF}}},
	{{{-6, -16, 0},0, {112, 496},{0xD1, 0xA6, 0xB4, 0xFF}}},
	{{{3, 40, -76},0, {112, 368},{0xB0, 0xF9, 0x9D, 0xFF}}},
	{{{206, 91, 0},0, {624, 112},{0xC7, 0x72, 0x0, 0xFF}}},
	{{{206, 83, 89},0, {624, -16},{0xD1, 0x57, 0x50, 0xFF}}},
	{{{242, 107, 86},0, {624, -16},{0x2A, 0x6F, 0x2D, 0xFF}}},
	{{{242, 132, 0},0, {624, 112},{0xFF, 0x7A, 0x23, 0xFF}}},
	{{{242, 107, -86},0, {624, -16},{0x30, 0x64, 0xC2, 0xFF}}},
	{{{206, 83, -89},0, {624, -16},{0xEA, 0x4E, 0x9E, 0xFF}}},
	{{{206, 83, 89},0, {624, 1008},{0xD1, 0x57, 0x50, 0xFF}}},
	{{{255, 21, 136},0, {624, 880},{0x29, 0x1E, 0x74, 0xFF}}},
	{{{242, 107, 86},0, {624, 1008},{0x2A, 0x6F, 0x2D, 0xFF}}},
	{{{188, 2, 104},0, {624, 880},{0xED, 0x31, 0x74, 0xFF}}},
	{{{109, 14, 102},0, {560, 880},{0xF5, 0x5, 0x7E, 0xFF}}},
	{{{216, -66, 182},0, {560, 752},{0x4D, 0x2, 0x65, 0xFF}}},
	{{{88, -60, 77},0, {496, 752},{0x1, 0xF5, 0x7F, 0xFF}}},
	{{{68, 56, 114},0, {496, 880},{0xF5, 0xC, 0x7E, 0xFF}}},
	{{{3, 40, 76},0, {368, 880},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{-6, -16, 65},0, {368, 752},{0xD8, 0xB6, 0x5F, 0xFF}}},
	{{{83, -93, 145},0, {368, 624},{0x57, 0x25, 0x55, 0xFF}}},
	{{{83, -157, 0},0, {496, 624},{0x52, 0xA6, 0xDC, 0xFF}}},
	{{{-6, -16, 0},0, {368, 752},{0xD1, 0xA6, 0xB4, 0xFF}}},
	{{{60, -60, -77},0, {496, 752},{0xC9, 0xBF, 0xA1, 0xFF}}},
	{{{3, 40, -76},0, {368, 880},{0xB0, 0xF9, 0x9D, 0xFF}}},
	{{{68, 56, -113},0, {496, 880},{0xF2, 0x10, 0x83, 0xFF}}},
	{{{109, 14, -102},0, {560, 880},{0x1, 0xF6, 0x81, 0xFF}}},
	{{{88, -66, -82},0, {560, 752},{0xFC, 0xBE, 0x93, 0xFF}}},
	{{{188, 2, -104},0, {624, 880},{0x3, 0x0, 0x81, 0xFF}}},
	{{{206, 83, -89},0, {624, 1008},{0xEA, 0x4E, 0x9E, 0xFF}}},
	{{{258, 21, -94},0, {624, 880},{0x53, 0xF, 0xA1, 0xFF}}},
	{{{188, 2, -104},0, {624, 880},{0x3, 0x0, 0x81, 0xFF}}},
	{{{206, 83, -89},0, {624, 1008},{0xEA, 0x4E, 0x9E, 0xFF}}},
	{{{242, 107, -86},0, {624, 1008},{0x30, 0x64, 0xC2, 0xFF}}},
	{{{258, -38, -84},0, {624, 752},{0x5E, 0xCB, 0xBD, 0xFF}}},
	{{{201, -88, -92},0, {624, 752},{0x2A, 0xB4, 0xA4, 0xFF}}},
	{{{199, -118, 0},0, {624, 624},{0x40, 0x92, 0x7, 0xFF}}},
	{{{266, -44, 0},0, {624, 624},{0x6E, 0xC4, 0x18, 0xFF}}},
	{{{212, -59, 128},0, {624, 752},{0x3F, 0x92, 0xFE, 0xFF}}},
	{{{274, -38, 200},0, {624, 752},{0x2F, 0x1A, 0x73, 0xFF}}},
	{{{255, 21, 136},0, {624, 880},{0x29, 0x1E, 0x74, 0xFF}}},
	{{{188, 2, 104},0, {624, 880},{0xED, 0x31, 0x74, 0xFF}}},
	{{{216, -66, 182},0, {560, 752},{0x4D, 0x2, 0x65, 0xFF}}},
	{{{88, -97, 0},0, {560, 624},{0x5E, 0xB1, 0x22, 0xFF}}},
	{{{88, -60, 77},0, {496, 752},{0x1, 0xF5, 0x7F, 0xFF}}},
	{{{83, -157, 0},0, {496, 624},{0x52, 0xA6, 0xDC, 0xFF}}},
	{{{88, -66, -82},0, {560, 752},{0xFC, 0xBE, 0x93, 0xFF}}},
	{{{60, -60, -77},0, {496, 752},{0xC9, 0xBF, 0xA1, 0xFF}}},
	{{{266, -44, 0},0, {752, 496},{0x6E, 0xC4, 0x18, 0xFF}}},
	{{{255, 21, 136},0, {880, 368},{0x29, 0x1E, 0x74, 0xFF}}},
	{{{274, -38, 200},0, {880, 496},{0x2F, 0x1A, 0x73, 0xFF}}},
	{{{285, 84, 0},0, {752, 368},{0x6D, 0x42, 0xFE, 0xFF}}},
	{{{258, 21, -94},0, {880, 368},{0x53, 0xF, 0xA1, 0xFF}}},
	{{{258, -38, -84},0, {880, 496},{0x5E, 0xCB, 0xBD, 0xFF}}},
	{{{242, 107, -86},0, {880, 240},{0x30, 0x64, 0xC2, 0xFF}}},
	{{{242, 132, 0},0, {752, 240},{0xFF, 0x7A, 0x23, 0xFF}}},
	{{{242, 107, 86},0, {880, 240},{0x2A, 0x6F, 0x2D, 0xFF}}},
};

Gfx mario_002_switch_option_head__no_cap__mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_002_switch_option_head__no_cap__mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 3, 2, 0, 4, 2, 5, 0),
	gsSP2Triangles(6, 7, 8, 0, 6, 8, 9, 0),
	gsSP2Triangles(10, 6, 9, 0, 10, 11, 6, 0),
	gsSP2Triangles(12, 13, 14, 0, 12, 15, 13, 0),
	gsSP2Triangles(12, 16, 15, 0, 15, 16, 17, 0),
	gsSP2Triangles(16, 18, 17, 0, 16, 19, 18, 0),
	gsSP2Triangles(20, 18, 19, 0, 20, 21, 18, 0),
	gsSP2Triangles(18, 21, 22, 0, 18, 22, 23, 0),
	gsSP2Triangles(24, 23, 22, 0, 24, 25, 23, 0),
	gsSP2Triangles(26, 25, 24, 0, 26, 27, 25, 0),
	gsSP2Triangles(28, 25, 27, 0, 28, 29, 25, 0),
	gsSP2Triangles(30, 29, 28, 0, 31, 30, 28, 0),
	gsSPVertex(mario_002_switch_option_head__no_cap__mesh_layer_1_vtx_0 + 32, 27, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 1, 0, 0, 4, 5, 1, 0),
	gsSP2Triangles(6, 5, 4, 0, 6, 4, 7, 0),
	gsSP2Triangles(8, 6, 7, 0, 8, 7, 9, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
	gsSP2Triangles(11, 12, 8, 0, 8, 12, 13, 0),
	gsSP2Triangles(14, 13, 12, 0, 14, 15, 13, 0),
	gsSP2Triangles(15, 16, 13, 0, 15, 17, 16, 0),
	gsSP2Triangles(13, 16, 5, 0, 1, 5, 16, 0),
	gsSP2Triangles(13, 5, 6, 0, 8, 13, 6, 0),
	gsSP2Triangles(18, 19, 20, 0, 18, 21, 19, 0),
	gsSP2Triangles(18, 22, 21, 0, 18, 23, 22, 0),
	gsSP2Triangles(21, 22, 24, 0, 21, 24, 25, 0),
	gsSP2Triangles(21, 25, 26, 0, 21, 26, 19, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_displaylist_001_mesh_layer_4_vtx_0[4] = {
	{{{172, -31, 2},0, {0, 2046},{0x5, 0x1E, 0x7B, 0xFF}}},
	{{{347, 32, -21},0, {1022, 2046},{0x6, 0x1E, 0x7B, 0xFF}}},
	{{{211, 374, -98},0, {1022, -18},{0x5, 0x1E, 0x7B, 0xFF}}},
	{{{38, 311, -75},0, {0, -18},{0x4, 0x1E, 0x7B, 0xFF}}},
};

Gfx mario_000_displaylist_001_mesh_layer_4_tri_0[] = {
	gsSPVertex(mario_000_displaylist_001_mesh_layer_4_vtx_0 + 0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_displaylist_001_mesh_layer_4_vtx_1[4] = {
	{{{-136, 247, -53},0, {0, -18},{0x4, 0x1E, 0x7B, 0xFF}}},
	{{{172, -31, 2},0, {1022, 2046},{0x5, 0x1E, 0x7B, 0xFF}}},
	{{{38, 311, -75},0, {1022, -18},{0x4, 0x1E, 0x7B, 0xFF}}},
	{{{-1, -95, 25},0, {0, 2046},{0x4, 0x1E, 0x7B, 0xFF}}},
};

Gfx mario_000_displaylist_001_mesh_layer_4_tri_1[] = {
	gsSPVertex(mario_000_displaylist_001_mesh_layer_4_vtx_1 + 0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_displaylist_002_mesh_layer_4_vtx_0[4] = {
	{{{173, -31, -1},0, {0, 2046},{0xFB, 0xE2, 0x7B, 0xFF}}},
	{{{348, 32, 23},0, {1022, 2046},{0xFA, 0xE2, 0x7B, 0xFF}}},
	{{{212, 374, 99},0, {1022, -18},{0xFB, 0xE2, 0x7B, 0xFF}}},
	{{{39, 311, 77},0, {0, -18},{0xFC, 0xE2, 0x7B, 0xFF}}},
};

Gfx mario_000_displaylist_002_mesh_layer_4_tri_0[] = {
	gsSPVertex(mario_000_displaylist_002_mesh_layer_4_vtx_0 + 0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_displaylist_002_mesh_layer_4_vtx_1[4] = {
	{{{-135, 247, 54},0, {0, -18},{0xFC, 0xE2, 0x7B, 0xFF}}},
	{{{0, -95, -23},0, {0, 2046},{0xFC, 0xE2, 0x7B, 0xFF}}},
	{{{173, -31, -1},0, {1022, 2046},{0xFB, 0xE2, 0x7B, 0xFF}}},
	{{{39, 311, 77},0, {1022, -18},{0xFC, 0xE2, 0x7B, 0xFF}}},
};

Gfx mario_000_displaylist_002_mesh_layer_4_tri_1[] = {
	gsSPVertex(mario_000_displaylist_002_mesh_layer_4_vtx_1 + 0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_003_skinned_mesh_layer_1_vtx_0[12] = {
	{{{71, 29, 101},0, {128, 93},{0x3F, 0x36, 0x60, 0xFF}}},
	{{{-32, 20, 94},0, {239, 197},{0xF6, 0x2E, 0x76, 0xFF}}},
	{{{-32, 20, 94},0, {628, 151},{0xF6, 0x2E, 0x76, 0xFF}}},
	{{{71, 29, 101},0, {764, 1008},{0x3F, 0x36, 0x60, 0xFF}}},
	{{{72, -58, 91},0, {25, 195},{0x3F, 0xBA, 0x56, 0xFF}}},
	{{{-32, 20, 94},0, {770, 518},{0xF6, 0x2E, 0x76, 0xFF}}},
	{{{-33, -47, 87},0, {668, 518},{0xF8, 0xB9, 0x69, 0xFF}}},
	{{{72, -58, 91},0, {87, 62},{0x3F, 0xBA, 0x56, 0xFF}}},
	{{{-33, -47, 87},0, {7, 195},{0xF8, 0xB9, 0x69, 0xFF}}},
	{{{71, 29, 101},0, {556, 485},{0x3F, 0x36, 0x60, 0xFF}}},
	{{{71, 29, 101},0, {578, 946},{0x3F, 0x36, 0x60, 0xFF}}},
	{{{72, -58, 91},0, {709, 946},{0x3F, 0xBA, 0x56, 0xFF}}},
};

Gfx mario_000_offset_003_skinned_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_000_offset_003_skinned_mesh_layer_1_vtx_0 + 0, 12, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_003_mesh_layer_1_vtx_0[12] = {
	{{{5, -29, -68},0, {239, 60},{0xD6, 0xA7, 0xAF, 0xFF}}},
	{{{1, 36, -68},0, {628, 3},{0xC7, 0x50, 0xB0, 0xFF}}},
	{{{5, -29, -68},0, {566, 79},{0xD6, 0xA7, 0xAF, 0xFF}}},
	{{{1, 36, -68},0, {672, 610},{0xC7, 0x50, 0xB0, 0xFF}}},
	{{{1, 36, -68},0, {-16, 62},{0xC7, 0x50, 0xB0, 0xFF}}},
	{{{4, 46, 32},0, {691, 1008},{0xB5, 0x49, 0x48, 0xFF}}},
	{{{5, -29, -68},0, {881, 988},{0xD6, 0xA7, 0xAF, 0xFF}}},
	{{{10, -37, 31},0, {741, 933},{0xB8, 0xB2, 0x47, 0xFF}}},
	{{{4, 46, 32},0, {-16, 270},{0xB5, 0x49, 0x48, 0xFF}}},
	{{{1, 36, -68},0, {128, 217},{0xC7, 0x50, 0xB0, 0xFF}}},
	{{{10, -37, 31},0, {556, 430},{0xB8, 0xB2, 0x47, 0xFF}}},
	{{{4, 46, 32},0, {430, 435},{0xB5, 0x49, 0x48, 0xFF}}},
};

Gfx mario_000_offset_003_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_000_offset_003_mesh_layer_1_vtx_0 + 0, 12, 12),
	gsSP2Triangles(0, 1, 12, 0, 2, 13, 14, 0),
	gsSP2Triangles(5, 6, 15, 0, 7, 16, 8, 0),
	gsSP2Triangles(10, 17, 11, 0, 3, 18, 19, 0),
	gsSP2Triangles(4, 20, 21, 0, 9, 22, 23, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_003_mesh_layer_1_vtx_1[19] = {
	{{{10, -37, 31},0, {741, 933},{0xB8, 0xB2, 0x47, 0xFF}}},
	{{{5, -29, -68},0, {881, 988},{0xD6, 0xA7, 0xAF, 0xFF}}},
	{{{54, -23, -50},0, {881, 907},{0x2A, 0xAD, 0xA9, 0xFF}}},
	{{{58, -28, 27},0, {771, 865},{0x17, 0xA5, 0x55, 0xFF}}},
	{{{1, 36, -68},0, {869, 70},{0xC7, 0x50, 0xB0, 0xFF}}},
	{{{54, -23, -50},0, {962, 149},{0x2A, 0xAD, 0xA9, 0xFF}}},
	{{{5, -29, -68},0, {967, 70},{0xD6, 0xA7, 0xAF, 0xFF}}},
	{{{67, 29, -45},0, {884, 173},{0x27, 0x54, 0xA9, 0xFF}}},
	{{{70, 4, -44},0, {922, 176},{0x2A, 0x1, 0x88, 0xFF}}},
	{{{4, 46, 32},0, {-16, 270},{0xB5, 0x49, 0x48, 0xFF}}},
	{{{67, 29, -45},0, {128, 322},{0x27, 0x54, 0xA9, 0xFF}}},
	{{{1, 36, -68},0, {128, 217},{0xC7, 0x50, 0xB0, 0xFF}}},
	{{{67, 35, 27},0, {24, 359},{0x17, 0x5C, 0x55, 0xFF}}},
	{{{58, -28, 27},0, {545, 357},{0x17, 0xA5, 0x55, 0xFF}}},
	{{{4, 46, 32},0, {430, 435},{0xB5, 0x49, 0x48, 0xFF}}},
	{{{10, -37, 31},0, {556, 430},{0xB8, 0xB2, 0x47, 0xFF}}},
	{{{67, 35, 27},0, {449, 340},{0xB, 0x0, 0x7F, 0xFF}}},
	{{{72, 5, 26},0, {495, 335},{0xA, 0x0, 0x7F, 0xFF}}},
	{{{67, 35, 27},0, {449, 340},{0x17, 0x5C, 0x55, 0xFF}}},
};

Gfx mario_000_offset_003_mesh_layer_1_tri_1[] = {
	gsSPVertex(mario_000_offset_003_mesh_layer_1_vtx_1 + 0, 19, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 7, 5, 0),
	gsSP2Triangles(7, 8, 5, 0, 9, 10, 11, 0),
	gsSP2Triangles(9, 12, 10, 0, 13, 14, 15, 0),
	gsSP2Triangles(14, 13, 16, 0, 13, 17, 16, 0),
	gsSP1Triangle(14, 16, 18, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_004_skinned_mesh_layer_1_vtx_0[11] = {
	{{{70, 4, -44},0, {922, 176},{0x2A, 0x1, 0x88, 0xFF}}},
	{{{54, -23, -50},0, {962, 149},{0x2A, 0xAD, 0xA9, 0xFF}}},
	{{{58, -28, 27},0, {771, 865},{0x17, 0xA5, 0x55, 0xFF}}},
	{{{54, -23, -50},0, {881, 907},{0x2A, 0xAD, 0xA9, 0xFF}}},
	{{{67, 35, 27},0, {24, 359},{0x17, 0x5C, 0x55, 0xFF}}},
	{{{67, 35, 27},0, {449, 340},{0xB, 0x0, 0x7F, 0xFF}}},
	{{{72, 5, 26},0, {495, 335},{0xA, 0x0, 0x7F, 0xFF}}},
	{{{67, 35, 27},0, {449, 340},{0x17, 0x5C, 0x55, 0xFF}}},
	{{{67, 29, -45},0, {884, 173},{0x27, 0x54, 0xA9, 0xFF}}},
	{{{67, 29, -45},0, {128, 322},{0x27, 0x54, 0xA9, 0xFF}}},
	{{{58, -28, 27},0, {545, 357},{0x17, 0xA5, 0x55, 0xFF}}},
};

Gfx mario_000_offset_004_skinned_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_000_offset_004_skinned_mesh_layer_1_vtx_0 + 0, 11, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_004_mesh_layer_1_vtx_0[8] = {
	{{{17, -18, -37},0, {958, 206},{0x29, 0xAD, 0xA9, 0xFF}}},
	{{{-1, 28, -43},0, {885, 181},{0x27, 0x54, 0xA9, 0xFF}}},
	{{{17, -18, -37},0, {881, 849},{0x29, 0xAD, 0xA9, 0xFF}}},
	{{{19, -22, 25},0, {793, 817},{0x17, 0xA6, 0x57, 0xFF}}},
	{{{-1, 34, 26},0, {451, 332},{0x16, 0x5B, 0x55, 0xFF}}},
	{{{19, -22, 25},0, {537, 305},{0x17, 0xA6, 0x57, 0xFF}}},
	{{{-1, 28, -43},0, {128, 331},{0x27, 0x54, 0xA9, 0xFF}}},
	{{{-1, 34, 26},0, {28, 366},{0x16, 0x5B, 0x55, 0xFF}}},
};

Gfx mario_000_offset_004_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_000_offset_004_mesh_layer_1_vtx_0 + 0, 8, 11),
	gsSP2Triangles(0, 11, 1, 0, 12, 11, 0, 0),
	gsSP2Triangles(8, 12, 0, 0, 2, 3, 13, 0),
	gsSP2Triangles(2, 13, 14, 0, 5, 15, 7, 0),
	gsSP2Triangles(5, 6, 15, 0, 16, 15, 6, 0),
	gsSP2Triangles(10, 16, 6, 0, 4, 17, 9, 0),
	gsSP1Triangle(4, 18, 17, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_004_mesh_layer_1_vtx_1[20] = {
	{{{88, 19, -12},0, {906, 323},{0x58, 0x47, 0xC6, 0xFF}}},
	{{{17, -18, -37},0, {958, 206},{0x29, 0xAD, 0xA9, 0xFF}}},
	{{{-1, 28, -43},0, {885, 181},{0x27, 0x54, 0xA9, 0xFF}}},
	{{{90, -9, -11},0, {949, 324},{0x5D, 0xBF, 0xC7, 0xFF}}},
	{{{19, -22, 25},0, {793, 817},{0x17, 0xA6, 0x57, 0xFF}}},
	{{{17, -18, -37},0, {881, 849},{0x29, 0xAD, 0xA9, 0xFF}}},
	{{{90, -9, -11},0, {881, 731},{0x5D, 0xBF, 0xC7, 0xFF}}},
	{{{89, -9, 19},0, {836, 717},{0x54, 0xC2, 0x49, 0xFF}}},
	{{{-1, 34, 26},0, {28, 366},{0x16, 0x5B, 0x55, 0xFF}}},
	{{{88, 19, -12},0, {128, 476},{0x58, 0x47, 0xC6, 0xFF}}},
	{{{-1, 28, -43},0, {128, 331},{0x27, 0x54, 0xA9, 0xFF}}},
	{{{86, 19, 19},0, {83, 489},{0x4D, 0x46, 0x49, 0xFF}}},
	{{{86, 19, 19},0, {477, 200},{0x4D, 0x46, 0x49, 0xFF}}},
	{{{-1, 34, 26},0, {451, 332},{0x16, 0x5B, 0x55, 0xFF}}},
	{{{19, -22, 25},0, {537, 305},{0x17, 0xA6, 0x57, 0xFF}}},
	{{{89, -9, 19},0, {521, 198},{0x54, 0xC2, 0x49, 0xFF}}},
	{{{90, -9, -11},0, {833, 717},{0x5D, 0xBF, 0xC7, 0xFF}}},
	{{{86, 19, 19},0, {877, 671},{0x4D, 0x46, 0x49, 0xFF}}},
	{{{89, -9, 19},0, {833, 671},{0x54, 0xC2, 0x49, 0xFF}}},
	{{{88, 19, -12},0, {877, 717},{0x58, 0x47, 0xC6, 0xFF}}},
};

Gfx mario_000_offset_004_mesh_layer_1_tri_1[] = {
	gsSPVertex(mario_000_offset_004_mesh_layer_1_vtx_1 + 0, 20, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 0, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 11, 9, 0),
	gsSP2Triangles(12, 13, 14, 0, 15, 12, 14, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 19, 17, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_displaylist_003_mesh_layer_1_vtx_0[32] = {
	{{{1, 27, 21},0, {624, 240},{0xAD, 0x41, 0x47, 0xFF}}},
	{{{4, 27, -14},0, {368, 240},{0xA9, 0x43, 0xC0, 0xFF}}},
	{{{4, -18, -14},0, {368, -16},{0xA9, 0xBD, 0xC0, 0xFF}}},
	{{{1, -18, 21},0, {624, -16},{0xAD, 0xBF, 0x47, 0xFF}}},
	{{{25, 32, 21},0, {496, 1008},{0x5, 0x5D, 0x57, 0xFF}}},
	{{{1, 27, 21},0, {368, 1008},{0xAD, 0x41, 0x47, 0xFF}}},
	{{{1, -18, 21},0, {368, 752},{0xAD, 0xBF, 0x47, 0xFF}}},
	{{{25, -23, 21},0, {496, 752},{0x5, 0xA3, 0x57, 0xFF}}},
	{{{49, -18, 17},0, {624, 752},{0x54, 0xBE, 0x45, 0xFF}}},
	{{{49, 27, 17},0, {624, 1008},{0x54, 0x42, 0x45, 0xFF}}},
	{{{25, 32, 21},0, {368, 368},{0x5, 0x5D, 0x57, 0xFF}}},
	{{{4, 27, -14},0, {112, 240},{0xA9, 0x43, 0xC0, 0xFF}}},
	{{{1, 27, 21},0, {368, 240},{0xAD, 0x41, 0x47, 0xFF}}},
	{{{27, 32, -22},0, {112, 368},{0xFA, 0x59, 0xA5, 0xFF}}},
	{{{49, 27, 17},0, {368, 496},{0x54, 0x42, 0x45, 0xFF}}},
	{{{50, 27, -18},0, {112, 496},{0x57, 0x41, 0xBE, 0xFF}}},
	{{{4, 27, -14},0, {624, 752},{0xA9, 0x43, 0xC0, 0xFF}}},
	{{{27, -23, -22},0, {496, 496},{0xFA, 0xA7, 0xA5, 0xFF}}},
	{{{4, -18, -14},0, {624, 496},{0xA9, 0xBD, 0xC0, 0xFF}}},
	{{{27, 32, -22},0, {496, 752},{0xFA, 0x59, 0xA5, 0xFF}}},
	{{{50, -18, -18},0, {368, 496},{0x57, 0xBF, 0xBE, 0xFF}}},
	{{{50, 27, -18},0, {368, 752},{0x57, 0x41, 0xBE, 0xFF}}},
	{{{4, -18, -14},0, {368, 496},{0xA9, 0xBD, 0xC0, 0xFF}}},
	{{{25, -23, 21},0, {624, 368},{0x5, 0xA3, 0x57, 0xFF}}},
	{{{1, -18, 21},0, {624, 496},{0xAD, 0xBF, 0x47, 0xFF}}},
	{{{27, -23, -22},0, {368, 368},{0xFA, 0xA7, 0xA5, 0xFF}}},
	{{{49, -18, 17},0, {624, 240},{0x54, 0xBE, 0x45, 0xFF}}},
	{{{50, -18, -18},0, {368, 240},{0x57, 0xBF, 0xBE, 0xFF}}},
	{{{49, -18, 17},0, {880, 496},{0x54, 0xBE, 0x45, 0xFF}}},
	{{{50, 27, -18},0, {624, 240},{0x57, 0x41, 0xBE, 0xFF}}},
	{{{49, 27, 17},0, {880, 240},{0x54, 0x42, 0x45, 0xFF}}},
	{{{50, -18, -18},0, {624, 496},{0x57, 0xBF, 0xBE, 0xFF}}},
};

Gfx mario_000_displaylist_003_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_000_displaylist_003_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(4, 7, 8, 0, 4, 8, 9, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 13, 11, 0),
	gsSP2Triangles(14, 13, 10, 0, 14, 15, 13, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 19, 17, 0),
	gsSP2Triangles(19, 20, 17, 0, 19, 21, 20, 0),
	gsSP2Triangles(22, 23, 24, 0, 22, 25, 23, 0),
	gsSP2Triangles(25, 26, 23, 0, 25, 27, 26, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 31, 29, 0),
	gsSPEndDisplayList(),
};

Vtx mario_002_switch_option_right_hand_open_mesh_layer_1_vtx_0[40] = {
	{{{27, 40, 15},0, {496, 1008},{0xEB, 0x58, 0x5A, 0xFF}}},
	{{{5, 28, 17},0, {368, 1008},{0xA5, 0x25, 0x51, 0xFF}}},
	{{{19, -16, 16},0, {368, 752},{0xDB, 0xAD, 0x59, 0xFF}}},
	{{{81, 52, 6},0, {368, 496},{0x3B, 0x5A, 0x43, 0xFF}}},
	{{{81, 52, -12},0, {112, 496},{0x35, 0x5D, 0xBB, 0xFF}}},
	{{{26, 40, -18},0, {112, 368},{0xE3, 0x5B, 0xAC, 0xFF}}},
	{{{27, 40, 15},0, {368, 368},{0xEB, 0x58, 0x5A, 0xFF}}},
	{{{5, 29, -18},0, {112, 240},{0xA0, 0x29, 0xB7, 0xFF}}},
	{{{5, 28, 17},0, {368, 240},{0xA5, 0x25, 0x51, 0xFF}}},
	{{{95, 8, 4},0, {624, 752},{0x65, 0xD3, 0x3F, 0xFF}}},
	{{{81, 52, 6},0, {624, 1008},{0x3B, 0x5A, 0x43, 0xFF}}},
	{{{43, -13, 13},0, {496, 752},{0x35, 0xD0, 0x69, 0xFF}}},
	{{{95, 8, 4},0, {880, 496},{0x65, 0xD3, 0x3F, 0xFF}}},
	{{{81, 52, -12},0, {624, 240},{0x35, 0x5D, 0xBB, 0xFF}}},
	{{{81, 52, 6},0, {880, 240},{0x3B, 0x5A, 0x43, 0xFF}}},
	{{{94, 9, -13},0, {624, 496},{0x5F, 0xD6, 0xB6, 0xFF}}},
	{{{26, 40, -18},0, {496, 752},{0xE3, 0x5B, 0xAC, 0xFF}}},
	{{{81, 52, -12},0, {368, 752},{0x35, 0x5D, 0xBB, 0xFF}}},
	{{{94, 9, -13},0, {368, 496},{0x5F, 0xD6, 0xB6, 0xFF}}},
	{{{42, -12, -19},0, {496, 496},{0x2B, 0xD3, 0x91, 0xFF}}},
	{{{42, -12, -19},0, {368, 368},{0x2B, 0xD3, 0x91, 0xFF}}},
	{{{94, 9, -13},0, {368, 240},{0x5F, 0xD6, 0xB6, 0xFF}}},
	{{{95, 8, 4},0, {624, 240},{0x65, 0xD3, 0x3F, 0xFF}}},
	{{{43, -13, 13},0, {624, 368},{0x35, 0xD0, 0x69, 0xFF}}},
	{{{19, -16, 16},0, {369, 752},{0xDB, 0xAD, 0x59, 0xFF}}},
	{{{43, -13, 13},0, {496, 819},{0x35, 0xD0, 0x69, 0xFF}}},
	{{{47, -26, 4},0, {496, 752},{0x53, 0xA6, 0x22, 0xFF}}},
	{{{42, -12, -19},0, {532, 569},{0x2B, 0xD3, 0x91, 0xFF}}},
	{{{47, -26, 4},0, {624, 368},{0x53, 0xA6, 0x22, 0xFF}}},
	{{{46, -26, -11},0, {496, 496},{0x4F, 0xA7, 0xD3, 0xFF}}},
	{{{18, -14, -19},0, {624, 496},{0xBA, 0xBC, 0xAE, 0xFF}}},
	{{{5, 29, -18},0, {624, 752},{0xA0, 0x29, 0xB7, 0xFF}}},
	{{{5, 28, 17},0, {624, 240},{0xA5, 0x25, 0x51, 0xFF}}},
	{{{5, 29, -18},0, {368, 240},{0xA0, 0x29, 0xB7, 0xFF}}},
	{{{18, -14, -19},0, {368, -16},{0xBA, 0xBC, 0xAE, 0xFF}}},
	{{{19, -16, 16},0, {624, -16},{0xDB, 0xAD, 0x59, 0xFF}}},
	{{{18, -14, -19},0, {368, 496},{0xBA, 0xBC, 0xAE, 0xFF}}},
	{{{47, -26, 4},0, {624, 368},{0x53, 0xA6, 0x22, 0xFF}}},
	{{{19, -16, 16},0, {624, 496},{0xDB, 0xAD, 0x59, 0xFF}}},
	{{{46, -26, -11},0, {368, 368},{0x4F, 0xA7, 0xD3, 0xFF}}},
};

Gfx mario_002_switch_option_right_hand_open_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_002_switch_option_right_hand_open_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(3, 5, 6, 0, 6, 5, 7, 0),
	gsSP2Triangles(6, 7, 8, 0, 0, 9, 10, 0),
	gsSP2Triangles(0, 11, 9, 0, 12, 13, 14, 0),
	gsSP2Triangles(12, 15, 13, 0, 16, 17, 18, 0),
	gsSP2Triangles(16, 18, 19, 0, 20, 21, 22, 0),
	gsSP2Triangles(20, 22, 23, 0, 0, 24, 25, 0),
	gsSP2Triangles(25, 24, 26, 0, 27, 25, 28, 0),
	gsSP2Triangles(27, 28, 29, 0, 30, 27, 29, 0),
	gsSP2Triangles(31, 27, 30, 0, 31, 16, 27, 0),
	gsSPVertex(mario_002_switch_option_right_hand_open_mesh_layer_1_vtx_0 + 32, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 7, 5, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_006_skinned_mesh_layer_1_vtx_0[12] = {
	{{{72, -58, -91},0, {167, 489},{0x3F, 0xBB, 0xAA, 0xFF}}},
	{{{71, 29, -101},0, {896, 324},{0x3F, 0x34, 0x9F, 0xFF}}},
	{{{71, 29, -101},0, {614, 642},{0x3F, 0x34, 0x9F, 0xFF}}},
	{{{72, -58, -91},0, {741, 672},{0x3F, 0xBB, 0xAA, 0xFF}}},
	{{{71, 29, -101},0, {430, 163},{0x3F, 0x34, 0x9F, 0xFF}}},
	{{{-32, 20, -94},0, {542, 59},{0xF6, 0x2E, 0x8A, 0xFF}}},
	{{{-32, 20, -94},0, {731, 3},{0xF6, 0x2E, 0x8A, 0xFF}}},
	{{{71, 29, -101},0, {312, 196},{0x3F, 0x34, 0x9F, 0xFF}}},
	{{{-32, 20, -94},0, {668, 243},{0xF6, 0x2E, 0x8A, 0xFF}}},
	{{{-33, -47, -87},0, {566, 243},{0xF8, 0xB9, 0x97, 0xFF}}},
	{{{72, -58, -91},0, {290, 60},{0x3F, 0xBB, 0xAA, 0xFF}}},
	{{{-33, -47, -87},0, {365, 196},{0xF8, 0xB9, 0x97, 0xFF}}},
};

Gfx mario_000_offset_006_skinned_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_000_offset_006_skinned_mesh_layer_1_vtx_0 + 0, 12, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_006_mesh_layer_1_vtx_0[12] = {
	{{{4, 46, -31},0, {739, 610},{0xB5, 0x49, 0xB8, 0xFF}}},
	{{{5, -29, 69},0, {542, 198},{0xD7, 0xA7, 0x51, 0xFF}}},
	{{{5, -29, 69},0, {668, 76},{0xD7, 0xA7, 0x51, 0xFF}}},
	{{{1, 36, 69},0, {731, 152},{0xC7, 0x51, 0x50, 0xFF}}},
	{{{1, 36, 69},0, {570, 151},{0xC7, 0x51, 0x50, 0xFF}}},
	{{{1, 36, 69},0, {391, 60},{0xC7, 0x51, 0x50, 0xFF}}},
	{{{1, 36, 69},0, {271, 469},{0xC7, 0x51, 0x50, 0xFF}}},
	{{{4, 46, -31},0, {128, 416},{0xB5, 0x49, 0xB8, 0xFF}}},
	{{{4, 46, -31},0, {770, 372},{0xB5, 0x49, 0xB8, 0xFF}}},
	{{{10, -37, -30},0, {896, 377},{0xB9, 0xB2, 0xB9, 0xFF}}},
	{{{10, -37, -30},0, {290, 269},{0xB9, 0xB2, 0xB9, 0xFF}}},
	{{{5, -29, 69},0, {430, 213},{0xD7, 0xA7, 0x51, 0xFF}}},
};

Gfx mario_000_offset_006_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_000_offset_006_mesh_layer_1_vtx_0 + 0, 12, 12),
	gsSP2Triangles(2, 3, 12, 0, 4, 13, 5, 0),
	gsSP2Triangles(6, 14, 15, 0, 8, 16, 9, 0),
	gsSP2Triangles(10, 11, 17, 0, 0, 18, 19, 0),
	gsSP2Triangles(1, 20, 21, 0, 7, 22, 23, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_006_mesh_layer_1_vtx_1[19] = {
	{{{58, -28, -26},0, {885, 450},{0x17, 0xA5, 0xAB, 0xFF}}},
	{{{10, -37, -30},0, {896, 377},{0xB9, 0xB2, 0xB9, 0xFF}}},
	{{{4, 46, -31},0, {770, 372},{0xB5, 0x49, 0xB8, 0xFF}}},
	{{{67, 35, -26},0, {790, 468},{0xB, 0x0, 0x81, 0xFF}}},
	{{{67, 35, -26},0, {789, 468},{0x17, 0x5C, 0xAB, 0xFF}}},
	{{{72, 5, -25},0, {836, 473},{0xA, 0x0, 0x81, 0xFF}}},
	{{{4, 46, -31},0, {128, 416},{0xB5, 0x49, 0xB8, 0xFF}}},
	{{{1, 36, 69},0, {271, 469},{0xC7, 0x51, 0x50, 0xFF}}},
	{{{67, 29, 46},0, {271, 363},{0x27, 0x54, 0x57, 0xFF}}},
	{{{67, 35, -26},0, {168, 327},{0x17, 0x5C, 0xAB, 0xFF}}},
	{{{1, 36, 69},0, {869, 70},{0xC7, 0x51, 0x50, 0xFF}}},
	{{{5, -29, 69},0, {770, 70},{0xD7, 0xA7, 0x51, 0xFF}}},
	{{{54, -23, 51},0, {776, 149},{0x2A, 0xAD, 0x57, 0xFF}}},
	{{{67, 29, 46},0, {854, 173},{0x27, 0x54, 0x57, 0xFF}}},
	{{{70, 4, 45},0, {816, 176},{0x2A, 0x1, 0x78, 0xFF}}},
	{{{10, -37, -30},0, {290, 269},{0xB9, 0xB2, 0xB9, 0xFF}}},
	{{{54, -23, 51},0, {430, 294},{0x2A, 0xAD, 0x57, 0xFF}}},
	{{{5, -29, 69},0, {430, 213},{0xD7, 0xA7, 0x51, 0xFF}}},
	{{{58, -28, -26},0, {320, 337},{0x17, 0xA5, 0xAB, 0xFF}}},
};

Gfx mario_000_offset_006_mesh_layer_1_tri_1[] = {
	gsSPVertex(mario_000_offset_006_mesh_layer_1_vtx_1 + 0, 19, 0),
	gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
	gsSP2Triangles(2, 4, 3, 0, 0, 3, 5, 0),
	gsSP2Triangles(6, 7, 8, 0, 6, 8, 9, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 12, 13, 0),
	gsSP2Triangles(13, 12, 14, 0, 15, 16, 17, 0),
	gsSP1Triangle(15, 18, 16, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_007_skinned_mesh_layer_1_vtx_0[11] = {
	{{{58, -28, -26},0, {885, 450},{0x17, 0xA5, 0xAB, 0xFF}}},
	{{{72, 5, -25},0, {836, 473},{0xA, 0x0, 0x81, 0xFF}}},
	{{{58, -28, -26},0, {320, 337},{0x17, 0xA5, 0xAB, 0xFF}}},
	{{{70, 4, 45},0, {816, 176},{0x2A, 0x1, 0x78, 0xFF}}},
	{{{54, -23, 51},0, {776, 149},{0x2A, 0xAD, 0x57, 0xFF}}},
	{{{54, -23, 51},0, {430, 294},{0x2A, 0xAD, 0x57, 0xFF}}},
	{{{67, 35, -26},0, {168, 327},{0x17, 0x5C, 0xAB, 0xFF}}},
	{{{67, 35, -26},0, {790, 468},{0xB, 0x0, 0x81, 0xFF}}},
	{{{67, 35, -26},0, {789, 468},{0x17, 0x5C, 0xAB, 0xFF}}},
	{{{67, 29, 46},0, {854, 173},{0x27, 0x54, 0x57, 0xFF}}},
	{{{67, 29, 46},0, {271, 363},{0x27, 0x54, 0x57, 0xFF}}},
};

Gfx mario_000_offset_007_skinned_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_000_offset_007_skinned_mesh_layer_1_vtx_0 + 0, 11, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_007_mesh_layer_1_vtx_0[8] = {
	{{{19, -22, -24},0, {877, 502},{0x17, 0xA6, 0xA9, 0xFF}}},
	{{{-1, 34, -25},0, {791, 476},{0x16, 0x5B, 0xAB, 0xFF}}},
	{{{17, -18, 38},0, {780, 206},{0x29, 0xAD, 0x57, 0xFF}}},
	{{{-1, 28, 44},0, {852, 181},{0x27, 0x54, 0x57, 0xFF}}},
	{{{17, -18, 38},0, {430, 352},{0x29, 0xAD, 0x57, 0xFF}}},
	{{{19, -22, -24},0, {341, 385},{0x17, 0xA6, 0xA9, 0xFF}}},
	{{{-1, 28, 44},0, {271, 354},{0x27, 0x54, 0x57, 0xFF}}},
	{{{-1, 34, -25},0, {171, 319},{0x16, 0x5B, 0xAB, 0xFF}}},
};

Gfx mario_000_offset_007_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_000_offset_007_mesh_layer_1_vtx_0 + 0, 8, 11),
	gsSP2Triangles(0, 1, 11, 0, 11, 1, 12, 0),
	gsSP2Triangles(7, 12, 1, 0, 7, 8, 12, 0),
	gsSP2Triangles(3, 4, 13, 0, 14, 3, 13, 0),
	gsSP2Triangles(9, 3, 14, 0, 2, 15, 5, 0),
	gsSP2Triangles(2, 16, 15, 0, 6, 10, 17, 0),
	gsSP1Triangle(6, 17, 18, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_007_mesh_layer_1_vtx_1[20] = {
	{{{19, -22, -24},0, {341, 385},{0x17, 0xA6, 0xA9, 0xFF}}},
	{{{90, -9, 12},0, {430, 471},{0x5D, 0xBF, 0x39, 0xFF}}},
	{{{17, -18, 38},0, {430, 352},{0x29, 0xAD, 0x57, 0xFF}}},
	{{{89, -9, -18},0, {386, 485},{0x54, 0xC2, 0xB7, 0xFF}}},
	{{{17, -18, 38},0, {780, 206},{0x29, 0xAD, 0x57, 0xFF}}},
	{{{90, -9, 12},0, {788, 324},{0x5D, 0xBF, 0x39, 0xFF}}},
	{{{88, 19, 13},0, {832, 323},{0x58, 0x47, 0x3A, 0xFF}}},
	{{{-1, 28, 44},0, {852, 181},{0x27, 0x54, 0x57, 0xFF}}},
	{{{90, -9, 12},0, {833, 625},{0x5D, 0xBF, 0x39, 0xFF}}},
	{{{86, 19, -18},0, {877, 670},{0x4D, 0x46, 0xB7, 0xFF}}},
	{{{88, 19, 13},0, {877, 625},{0x58, 0x47, 0x3A, 0xFF}}},
	{{{89, -9, -18},0, {833, 671},{0x54, 0xC2, 0xB7, 0xFF}}},
	{{{89, -9, -18},0, {861, 610},{0x54, 0xC2, 0xB7, 0xFF}}},
	{{{19, -22, -24},0, {877, 502},{0x17, 0xA6, 0xA9, 0xFF}}},
	{{{86, 19, -18},0, {818, 607},{0x4D, 0x46, 0xB7, 0xFF}}},
	{{{-1, 34, -25},0, {791, 476},{0x16, 0x5B, 0xAB, 0xFF}}},
	{{{-1, 34, -25},0, {171, 319},{0x16, 0x5B, 0xAB, 0xFF}}},
	{{{88, 19, 13},0, {271, 209},{0x58, 0x47, 0x3A, 0xFF}}},
	{{{86, 19, -18},0, {227, 197},{0x4D, 0x46, 0xB7, 0xFF}}},
	{{{-1, 28, 44},0, {271, 354},{0x27, 0x54, 0x57, 0xFF}}},
};

Gfx mario_000_offset_007_mesh_layer_1_tri_1[] = {
	gsSPVertex(mario_000_offset_007_mesh_layer_1_vtx_1 + 0, 20, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 6, 7, 4, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 11, 9, 0),
	gsSP2Triangles(12, 13, 14, 0, 14, 13, 15, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 19, 17, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_displaylist_004_mesh_layer_1_vtx_0[32] = {
	{{{-1, 27, -20},0, {624, 240},{0xAD, 0x41, 0xB9, 0xFF}}},
	{{{2, -18, 15},0, {368, -16},{0xA9, 0xBD, 0x40, 0xFF}}},
	{{{2, 27, 15},0, {368, 240},{0xA9, 0x43, 0x40, 0xFF}}},
	{{{-1, -18, -20},0, {624, -16},{0xAD, 0xBF, 0xB9, 0xFF}}},
	{{{23, 32, -20},0, {496, 1008},{0x5, 0x5D, 0xA9, 0xFF}}},
	{{{-1, -18, -20},0, {368, 752},{0xAD, 0xBF, 0xB9, 0xFF}}},
	{{{-1, 27, -20},0, {368, 1008},{0xAD, 0x41, 0xB9, 0xFF}}},
	{{{23, -23, -20},0, {496, 752},{0x5, 0xA3, 0xA9, 0xFF}}},
	{{{46, -18, -16},0, {624, 752},{0x54, 0xBE, 0xBB, 0xFF}}},
	{{{46, 27, -16},0, {624, 1008},{0x54, 0x42, 0xBB, 0xFF}}},
	{{{23, 32, -20},0, {368, 368},{0x5, 0x5D, 0xA9, 0xFF}}},
	{{{-1, 27, -20},0, {368, 240},{0xAD, 0x41, 0xB9, 0xFF}}},
	{{{2, 27, 15},0, {112, 240},{0xA9, 0x43, 0x40, 0xFF}}},
	{{{25, 32, 23},0, {112, 368},{0xFA, 0x59, 0x5B, 0xFF}}},
	{{{46, 27, -16},0, {368, 496},{0x54, 0x42, 0xBB, 0xFF}}},
	{{{48, 27, 19},0, {112, 496},{0x57, 0x41, 0x42, 0xFF}}},
	{{{2, 27, 15},0, {624, 752},{0xA9, 0x43, 0x40, 0xFF}}},
	{{{2, -18, 15},0, {624, 496},{0xA9, 0xBD, 0x40, 0xFF}}},
	{{{25, -23, 23},0, {496, 496},{0xFA, 0xA7, 0x5B, 0xFF}}},
	{{{25, 32, 23},0, {496, 752},{0xFA, 0x59, 0x5B, 0xFF}}},
	{{{48, -18, 19},0, {368, 496},{0x57, 0xBF, 0x42, 0xFF}}},
	{{{48, 27, 19},0, {368, 752},{0x57, 0x41, 0x42, 0xFF}}},
	{{{2, -18, 15},0, {368, 496},{0xA9, 0xBD, 0x40, 0xFF}}},
	{{{-1, -18, -20},0, {624, 496},{0xAD, 0xBF, 0xB9, 0xFF}}},
	{{{23, -23, -20},0, {624, 368},{0x5, 0xA3, 0xA9, 0xFF}}},
	{{{25, -23, 23},0, {368, 368},{0xFA, 0xA7, 0x5B, 0xFF}}},
	{{{46, -18, -16},0, {624, 240},{0x54, 0xBE, 0xBB, 0xFF}}},
	{{{48, -18, 19},0, {368, 240},{0x57, 0xBF, 0x42, 0xFF}}},
	{{{46, -18, -16},0, {880, 496},{0x54, 0xBE, 0xBB, 0xFF}}},
	{{{46, 27, -16},0, {880, 240},{0x54, 0x42, 0xBB, 0xFF}}},
	{{{48, 27, 19},0, {624, 240},{0x57, 0x41, 0x42, 0xFF}}},
	{{{48, -18, 19},0, {624, 496},{0x57, 0xBF, 0x42, 0xFF}}},
};

Gfx mario_000_displaylist_004_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_000_displaylist_004_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 7, 5, 0),
	gsSP2Triangles(4, 8, 7, 0, 4, 9, 8, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 12, 13, 0),
	gsSP2Triangles(14, 10, 13, 0, 14, 13, 15, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
	gsSP2Triangles(19, 18, 20, 0, 19, 20, 21, 0),
	gsSP2Triangles(22, 23, 24, 0, 22, 24, 25, 0),
	gsSP2Triangles(25, 24, 26, 0, 25, 26, 27, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 30, 31, 0),
	gsSPEndDisplayList(),
};

Vtx mario_002_switch_option_left_hand_open_mesh_layer_1_vtx_0[40] = {
	{{{36, 40, -20},0, {496, 1008},{0xEB, 0x58, 0xA6, 0xFF}}},
	{{{27, -16, -20},0, {368, 752},{0xC0, 0xB8, 0xAE, 0xFF}}},
	{{{14, 28, -22},0, {368, 1008},{0xA5, 0x25, 0xAF, 0xFF}}},
	{{{90, 52, -10},0, {368, 496},{0x3B, 0x5A, 0xBD, 0xFF}}},
	{{{34, 40, 13},0, {112, 368},{0xE3, 0x5B, 0x54, 0xFF}}},
	{{{89, 52, 7},0, {112, 496},{0x35, 0x5D, 0x45, 0xFF}}},
	{{{36, 40, -20},0, {368, 368},{0xEB, 0x58, 0xA6, 0xFF}}},
	{{{13, 29, 13},0, {112, 240},{0xA0, 0x29, 0x49, 0xFF}}},
	{{{14, 28, -22},0, {368, 240},{0xA5, 0x25, 0xAF, 0xFF}}},
	{{{90, 52, -10},0, {624, 1008},{0x3B, 0x5A, 0xBD, 0xFF}}},
	{{{103, 8, -9},0, {624, 752},{0x65, 0xD3, 0xC1, 0xFF}}},
	{{{52, -13, -18},0, {496, 752},{0x35, 0xD0, 0x97, 0xFF}}},
	{{{103, 8, -9},0, {880, 496},{0x65, 0xD3, 0xC1, 0xFF}}},
	{{{90, 52, -10},0, {880, 240},{0x3B, 0x5A, 0xBD, 0xFF}}},
	{{{89, 52, 7},0, {624, 240},{0x35, 0x5D, 0x45, 0xFF}}},
	{{{102, 9, 9},0, {624, 496},{0x5F, 0xD6, 0x4A, 0xFF}}},
	{{{34, 40, 13},0, {496, 752},{0xE3, 0x5B, 0x54, 0xFF}}},
	{{{102, 9, 9},0, {368, 496},{0x5F, 0xD6, 0x4A, 0xFF}}},
	{{{89, 52, 7},0, {368, 752},{0x35, 0x5D, 0x45, 0xFF}}},
	{{{50, -12, 14},0, {496, 496},{0x2B, 0xD3, 0x6F, 0xFF}}},
	{{{50, -12, 14},0, {368, 368},{0x2B, 0xD3, 0x6F, 0xFF}}},
	{{{103, 8, -9},0, {624, 240},{0x65, 0xD3, 0xC1, 0xFF}}},
	{{{102, 9, 9},0, {368, 240},{0x5F, 0xD6, 0x4A, 0xFF}}},
	{{{52, -13, -18},0, {624, 368},{0x35, 0xD0, 0x97, 0xFF}}},
	{{{52, -13, -18},0, {496, 819},{0x35, 0xD0, 0x97, 0xFF}}},
	{{{27, -16, -20},0, {369, 752},{0xC0, 0xB8, 0xAE, 0xFF}}},
	{{{55, -26, -9},0, {496, 752},{0x53, 0xA6, 0xDE, 0xFF}}},
	{{{50, -12, 14},0, {532, 569},{0x2B, 0xD3, 0x6F, 0xFF}}},
	{{{55, -26, -9},0, {624, 368},{0x53, 0xA6, 0xDE, 0xFF}}},
	{{{55, -26, 6},0, {496, 496},{0x4F, 0xA7, 0x2D, 0xFF}}},
	{{{27, -14, 15},0, {624, 496},{0xBA, 0xBC, 0x52, 0xFF}}},
	{{{13, 29, 13},0, {624, 752},{0xA0, 0x29, 0x49, 0xFF}}},
	{{{14, 28, -22},0, {624, 240},{0xA5, 0x25, 0xAF, 0xFF}}},
	{{{27, -14, 15},0, {368, -16},{0xBA, 0xBC, 0x52, 0xFF}}},
	{{{13, 29, 13},0, {368, 240},{0xA0, 0x29, 0x49, 0xFF}}},
	{{{27, -16, -20},0, {624, -16},{0xC0, 0xB8, 0xAE, 0xFF}}},
	{{{27, -14, 15},0, {368, 496},{0xBA, 0xBC, 0x52, 0xFF}}},
	{{{27, -16, -20},0, {624, 496},{0xC0, 0xB8, 0xAE, 0xFF}}},
	{{{55, -26, -9},0, {624, 368},{0x53, 0xA6, 0xDE, 0xFF}}},
	{{{55, -26, 6},0, {368, 368},{0x4F, 0xA7, 0x2D, 0xFF}}},
};

Gfx mario_002_switch_option_left_hand_open_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_002_switch_option_left_hand_open_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(3, 6, 4, 0, 6, 7, 4, 0),
	gsSP2Triangles(6, 8, 7, 0, 0, 9, 10, 0),
	gsSP2Triangles(0, 10, 11, 0, 12, 13, 14, 0),
	gsSP2Triangles(12, 14, 15, 0, 16, 17, 18, 0),
	gsSP2Triangles(16, 19, 17, 0, 20, 21, 22, 0),
	gsSP2Triangles(20, 23, 21, 0, 0, 24, 25, 0),
	gsSP2Triangles(24, 26, 25, 0, 27, 28, 24, 0),
	gsSP2Triangles(27, 29, 28, 0, 30, 29, 27, 0),
	gsSP2Triangles(31, 30, 27, 0, 31, 27, 16, 0),
	gsSPVertex(mario_002_switch_option_left_hand_open_mesh_layer_1_vtx_0 + 32, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSPEndDisplayList(),
};

Vtx mario_004_switch_option_left_hand_peace_mesh_layer_1_vtx_0[35] = {
	{{{110, -48, -29},0, {667, 240},{0x1D, 0xA6, 0xAB, 0xFF}}},
	{{{114, -57, 9},0, {581, -16},{0x28, 0x8C, 0x20, 0xFF}}},
	{{{73, -55, -11},0, {496, 240},{0xCA, 0x92, 0xDF, 0xFF}}},
	{{{95, -5, -52},0, {667, 496},{0x6, 0xE8, 0x83, 0xFF}}},
	{{{42, -16, -27},0, {496, 496},{0x9D, 0xD0, 0xC1, 0xFF}}},
	{{{70, -45, 23},0, {325, 240},{0xC6, 0xAB, 0x4A, 0xFF}}},
	{{{114, -57, 9},0, {411, -16},{0x28, 0x8C, 0x20, 0xFF}}},
	{{{38, -2, 21},0, {325, 496},{0x97, 0xEB, 0x44, 0xFF}}},
	{{{105, -28, 40},0, {155, 240},{0x11, 0xD4, 0x76, 0xFF}}},
	{{{114, -57, 9},0, {240, -16},{0x28, 0x8C, 0x20, 0xFF}}},
	{{{88, 23, 45},0, {155, 496},{0xFA, 0x18, 0x7D, 0xFF}}},
	{{{142, -20, 22},0, {-16, 240},{0x65, 0xE2, 0x47, 0xFF}}},
	{{{114, -57, 9},0, {69, -16},{0x28, 0x8C, 0x20, 0xFF}}},
	{{{140, 33, 20},0, {-16, 496},{0x63, 0x30, 0x3F, 0xFF}}},
	{{{72, 65, 21},0, {155, 752},{0xE3, 0x5A, 0x55, 0xFF}}},
	{{{110, 72, 4},0, {-16, 752},{0x36, 0x6E, 0x21, 0xFF}}},
	{{{68, 74, -17},0, {69, 1008},{0xD8, 0x74, 0xE0, 0xFF}}},
	{{{38, 48, 5},0, {325, 752},{0x93, 0x36, 0x25, 0xFF}}},
	{{{40, 38, -29},0, {496, 752},{0x9B, 0x1E, 0xB9, 0xFF}}},
	{{{68, 74, -17},0, {411, 1008},{0xD8, 0x74, 0xE0, 0xFF}}},
	{{{77, 45, -47},0, {667, 752},{0xEF, 0x2C, 0x8A, 0xFF}}},
	{{{68, 74, -17},0, {581, 1008},{0xD8, 0x74, 0xE0, 0xFF}}},
	{{{112, 63, -31},0, {837, 752},{0x3A, 0x55, 0xB6, 0xFF}}},
	{{{68, 74, -17},0, {752, 1008},{0xD8, 0x74, 0xE0, 0xFF}}},
	{{{144, 19, -29},0, {837, 496},{0x69, 0x15, 0xBC, 0xFF}}},
	{{{110, 72, 4},0, {1008, 752},{0x36, 0x6E, 0x21, 0xFF}}},
	{{{68, 74, -17},0, {923, 1008},{0xD8, 0x74, 0xE0, 0xFF}}},
	{{{140, 33, 20},0, {1008, 496},{0x63, 0x30, 0x3F, 0xFF}}},
	{{{145, -30, -12},0, {837, 240},{0x6D, 0xCA, 0xDB, 0xFF}}},
	{{{142, -20, 22},0, {1008, 240},{0x65, 0xE2, 0x47, 0xFF}}},
	{{{114, -57, 9},0, {923, -16},{0x28, 0x8C, 0x20, 0xFF}}},
	{{{114, -57, 9},0, {752, -16},{0x28, 0x8C, 0x20, 0xFF}}},
	{{{68, 74, -17},0, {240, 1008},{0xD8, 0x74, 0xE0, 0xFF}}},
	{{{38, 48, 5},0, {325, 752},{0x93, 0x36, 0x25, 0xFF}}},
	{{{72, 65, 21},0, {155, 752},{0xE3, 0x5A, 0x55, 0xFF}}},
};

Gfx mario_004_switch_option_left_hand_peace_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_004_switch_option_left_hand_peace_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
	gsSP2Triangles(3, 2, 4, 0, 4, 2, 5, 0),
	gsSP2Triangles(2, 6, 5, 0, 4, 5, 7, 0),
	gsSP2Triangles(7, 5, 8, 0, 5, 9, 8, 0),
	gsSP2Triangles(7, 8, 10, 0, 10, 8, 11, 0),
	gsSP2Triangles(8, 12, 11, 0, 10, 11, 13, 0),
	gsSP2Triangles(14, 10, 13, 0, 14, 13, 15, 0),
	gsSP2Triangles(16, 14, 15, 0, 17, 10, 14, 0),
	gsSP2Triangles(17, 7, 10, 0, 18, 7, 17, 0),
	gsSP2Triangles(19, 18, 17, 0, 18, 4, 7, 0),
	gsSP2Triangles(20, 4, 18, 0, 21, 20, 18, 0),
	gsSP2Triangles(20, 3, 4, 0, 22, 3, 20, 0),
	gsSP2Triangles(23, 22, 20, 0, 22, 24, 3, 0),
	gsSP2Triangles(25, 24, 22, 0, 26, 25, 22, 0),
	gsSP2Triangles(25, 27, 24, 0, 27, 28, 24, 0),
	gsSP2Triangles(27, 29, 28, 0, 29, 30, 28, 0),
	gsSP2Triangles(24, 28, 0, 0, 28, 31, 0, 0),
	gsSP1Triangle(24, 0, 3, 0),
	gsSPVertex(mario_004_switch_option_left_hand_peace_mesh_layer_1_vtx_0 + 32, 3, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSPEndDisplayList(),
};

Vtx mario_004_switch_option_left_hand_peace_mesh_layer_1_vtx_1[32] = {
	{{{-10, 32, 33},0, {624, 240},{0xA1, 0x2E, 0x47, 0xFF}}},
	{{{-6, 33, -2},0, {368, 240},{0xA0, 0x34, 0xBE, 0xFF}}},
	{{{4, -11, -2},0, {368, -16},{0xB7, 0xAB, 0xC4, 0xFF}}},
	{{{7, -12, 33},0, {624, -16},{0xCB, 0xAA, 0x4D, 0xFF}}},
	{{{20, 42, 33},0, {496, 1008},{0x18, 0x59, 0x58, 0xFF}}},
	{{{-10, 32, 33},0, {368, 1008},{0xA1, 0x2E, 0x47, 0xFF}}},
	{{{7, -12, 33},0, {368, 752},{0xCB, 0xAA, 0x4D, 0xFF}}},
	{{{25, -11, 33},0, {496, 752},{0x2F, 0xB1, 0x58, 0xFF}}},
	{{{48, -2, 9},0, {624, 752},{0x6F, 0xCE, 0x26, 0xFF}}},
	{{{38, 43, 9},0, {624, 1008},{0x50, 0x5D, 0x21, 0xFF}}},
	{{{20, 42, 33},0, {368, 368},{0x18, 0x59, 0x58, 0xFF}}},
	{{{-6, 33, -2},0, {112, 240},{0xA0, 0x34, 0xBE, 0xFF}}},
	{{{-10, 32, 33},0, {368, 240},{0xA1, 0x2E, 0x47, 0xFF}}},
	{{{21, 43, -10},0, {112, 368},{0xF0, 0x57, 0xA5, 0xFF}}},
	{{{38, 43, 9},0, {368, 496},{0x50, 0x5D, 0x21, 0xFF}}},
	{{{39, 43, -6},0, {112, 496},{0x49, 0x54, 0xC2, 0xFF}}},
	{{{-6, 33, -2},0, {624, 752},{0xA0, 0x34, 0xBE, 0xFF}}},
	{{{27, -11, -10},0, {496, 496},{0xC, 0xA7, 0xA6, 0xFF}}},
	{{{4, -11, -2},0, {624, 496},{0xB7, 0xAB, 0xC4, 0xFF}}},
	{{{21, 43, -10},0, {496, 752},{0xF0, 0x57, 0xA5, 0xFF}}},
	{{{49, -1, -6},0, {368, 496},{0x64, 0xD3, 0xC0, 0xFF}}},
	{{{39, 43, -6},0, {368, 752},{0x49, 0x54, 0xC2, 0xFF}}},
	{{{4, -11, -2},0, {368, 496},{0xB7, 0xAB, 0xC4, 0xFF}}},
	{{{25, -11, 33},0, {624, 368},{0x2F, 0xB1, 0x58, 0xFF}}},
	{{{7, -12, 33},0, {624, 496},{0xCB, 0xAA, 0x4D, 0xFF}}},
	{{{27, -11, -10},0, {368, 368},{0xC, 0xA7, 0xA6, 0xFF}}},
	{{{48, -2, 9},0, {624, 240},{0x6F, 0xCE, 0x26, 0xFF}}},
	{{{49, -1, -6},0, {368, 240},{0x64, 0xD3, 0xC0, 0xFF}}},
	{{{48, -2, 9},0, {880, 496},{0x6F, 0xCE, 0x26, 0xFF}}},
	{{{39, 43, -6},0, {624, 240},{0x49, 0x54, 0xC2, 0xFF}}},
	{{{38, 43, 9},0, {880, 240},{0x50, 0x5D, 0x21, 0xFF}}},
	{{{49, -1, -6},0, {624, 496},{0x64, 0xD3, 0xC0, 0xFF}}},
};

Gfx mario_004_switch_option_left_hand_peace_mesh_layer_1_tri_1[] = {
	gsSPVertex(mario_004_switch_option_left_hand_peace_mesh_layer_1_vtx_1 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(4, 7, 8, 0, 4, 8, 9, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 13, 11, 0),
	gsSP2Triangles(14, 13, 10, 0, 14, 15, 13, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 19, 17, 0),
	gsSP2Triangles(19, 20, 17, 0, 19, 21, 20, 0),
	gsSP2Triangles(22, 23, 24, 0, 22, 25, 23, 0),
	gsSP2Triangles(25, 26, 23, 0, 25, 27, 26, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 31, 29, 0),
	gsSPEndDisplayList(),
};

Vtx mario_004_switch_option_left_hand_peace_mesh_layer_4_vtx_0[8] = {
	{{{85, 188, -47},0, {0, 1024},{0xFA, 0x19, 0x7C, 0xFF}}},
	{{{141, 28, -11},0, {1536, 1024},{0xFA, 0x19, 0x7C, 0xFF}}},
	{{{235, 60, -13},0, {1536, 0},{0xFA, 0x19, 0x7C, 0xFF}}},
	{{{179, 221, -48},0, {0, 0},{0xFA, 0x19, 0x7C, 0xFF}}},
	{{{139, 33, 4},0, {1536, 1024},{0x6, 0xE7, 0x84, 0xFF}}},
	{{{233, 66, 3},0, {1536, 0},{0x6, 0xE7, 0x84, 0xFF}}},
	{{{289, -95, 38},0, {0, 0},{0x6, 0xE7, 0x84, 0xFF}}},
	{{{195, -127, 40},0, {0, 1024},{0x6, 0xE7, 0x84, 0xFF}}},
};

Gfx mario_004_switch_option_left_hand_peace_mesh_layer_4_tri_0[] = {
	gsSPVertex(mario_004_switch_option_left_hand_peace_mesh_layer_4_vtx_0 + 0, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSPEndDisplayList(),
};

Vtx mario_005_switch_option_left_hand_cap_mesh_layer_4_vtx_0[8] = {
	{{{94, 5, 30},0, {543, 372},{0x7B, 0xF1, 0xE2, 0xFF}}},
	{{{79, -79, 9},0, {880, 372},{0x51, 0xA8, 0xD4, 0xFF}}},
	{{{60, -53, -81},0, {880, 12},{0x51, 0xA8, 0xD4, 0xFF}}},
	{{{75, 31, -60},0, {543, 12},{0x7B, 0xF1, 0xE2, 0xFF}}},
	{{{94, 5, 30},0, {481, 372},{0x7B, 0xF1, 0xE2, 0xFF}}},
	{{{75, 31, -60},0, {481, 12},{0x7B, 0xF1, 0xE2, 0xFF}}},
	{{{91, 115, -39},0, {144, 12},{0x6D, 0x41, 0xFA, 0xFF}}},
	{{{110, 89, 51},0, {144, 372},{0x6D, 0x41, 0xFA, 0xFF}}},
};

Gfx mario_005_switch_option_left_hand_cap_mesh_layer_4_tri_0[] = {
	gsSPVertex(mario_005_switch_option_left_hand_cap_mesh_layer_4_vtx_0 + 0, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSPEndDisplayList(),
};

Vtx mario_005_switch_option_left_hand_cap_mesh_layer_1_vtx_0[32] = {
	{{{4, 33, 20},0, {624, 240},{0xA1, 0x2E, 0x47, 0xFF}}},
	{{{8, 33, -15},0, {368, 240},{0x9D, 0x2F, 0xC0, 0xFF}}},
	{{{17, -11, -15},0, {368, -16},{0xB9, 0xAC, 0xC0, 0xFF}}},
	{{{14, -12, 20},0, {624, -16},{0xBC, 0xAF, 0x47, 0xFF}}},
	{{{27, 42, 20},0, {496, 1008},{0xF2, 0x5C, 0x57, 0xFF}}},
	{{{4, 33, 20},0, {368, 1008},{0xA1, 0x2E, 0x47, 0xFF}}},
	{{{14, -12, 20},0, {368, 752},{0xBC, 0xAF, 0x47, 0xFF}}},
	{{{39, -11, 20},0, {496, 752},{0x19, 0xA6, 0x57, 0xFF}}},
	{{{60, -2, 16},0, {624, 752},{0x60, 0xD2, 0x45, 0xFF}}},
	{{{51, 43, 16},0, {624, 1008},{0x44, 0x52, 0x45, 0xFF}}},
	{{{27, 42, 20},0, {368, 368},{0xF2, 0x5C, 0x57, 0xFF}}},
	{{{8, 33, -15},0, {112, 240},{0x9D, 0x2F, 0xC0, 0xFF}}},
	{{{4, 33, 20},0, {368, 240},{0xA1, 0x2E, 0x47, 0xFF}}},
	{{{29, 43, -22},0, {112, 368},{0xE7, 0x56, 0xA5, 0xFF}}},
	{{{51, 43, 16},0, {368, 496},{0x44, 0x52, 0x45, 0xFF}}},
	{{{52, 43, -19},0, {112, 496},{0x47, 0x52, 0xBE, 0xFF}}},
	{{{8, 33, -15},0, {624, 752},{0x9D, 0x2F, 0xC0, 0xFF}}},
	{{{40, -11, -22},0, {496, 496},{0xC, 0xA8, 0xA6, 0xFF}}},
	{{{17, -11, -15},0, {624, 496},{0xB9, 0xAC, 0xC0, 0xFF}}},
	{{{29, 43, -22},0, {496, 752},{0xE7, 0x56, 0xA5, 0xFF}}},
	{{{62, -1, -19},0, {368, 496},{0x63, 0xD3, 0xBE, 0xFF}}},
	{{{52, 43, -19},0, {368, 752},{0x47, 0x52, 0xBE, 0xFF}}},
	{{{17, -11, -15},0, {368, 496},{0xB9, 0xAC, 0xC0, 0xFF}}},
	{{{39, -11, 20},0, {624, 368},{0x19, 0xA6, 0x57, 0xFF}}},
	{{{14, -12, 20},0, {624, 496},{0xBC, 0xAF, 0x47, 0xFF}}},
	{{{40, -11, -22},0, {368, 368},{0xC, 0xA8, 0xA6, 0xFF}}},
	{{{60, -2, 16},0, {624, 240},{0x60, 0xD2, 0x45, 0xFF}}},
	{{{62, -1, -19},0, {368, 240},{0x63, 0xD3, 0xBE, 0xFF}}},
	{{{60, -2, 16},0, {880, 496},{0x60, 0xD2, 0x45, 0xFF}}},
	{{{52, 43, -19},0, {624, 240},{0x47, 0x52, 0xBE, 0xFF}}},
	{{{51, 43, 16},0, {880, 240},{0x44, 0x52, 0x45, 0xFF}}},
	{{{62, -1, -19},0, {624, 496},{0x63, 0xD3, 0xBE, 0xFF}}},
};

Gfx mario_005_switch_option_left_hand_cap_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_005_switch_option_left_hand_cap_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(4, 7, 8, 0, 4, 8, 9, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 13, 11, 0),
	gsSP2Triangles(14, 13, 10, 0, 14, 15, 13, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 19, 17, 0),
	gsSP2Triangles(19, 20, 17, 0, 19, 21, 20, 0),
	gsSP2Triangles(22, 23, 24, 0, 22, 25, 23, 0),
	gsSP2Triangles(25, 26, 23, 0, 25, 27, 26, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 31, 29, 0),
	gsSPEndDisplayList(),
};

Vtx mario_006_switch_option_left_hand_wing_cap_mesh_layer_4_vtx_0[8] = {
	{{{94, 5, 30},0, {543, 372},{0x7B, 0xF1, 0xE2, 0xFF}}},
	{{{79, -79, 9},0, {880, 372},{0x51, 0xA8, 0xD4, 0xFF}}},
	{{{60, -53, -81},0, {880, 12},{0x51, 0xA8, 0xD4, 0xFF}}},
	{{{75, 31, -60},0, {543, 12},{0x7B, 0xF1, 0xE2, 0xFF}}},
	{{{94, 5, 30},0, {481, 372},{0x7B, 0xF1, 0xE2, 0xFF}}},
	{{{75, 31, -60},0, {481, 12},{0x7B, 0xF1, 0xE2, 0xFF}}},
	{{{91, 115, -39},0, {144, 12},{0x6D, 0x41, 0xFA, 0xFF}}},
	{{{110, 89, 51},0, {144, 372},{0x6D, 0x41, 0xFA, 0xFF}}},
};

Gfx mario_006_switch_option_left_hand_wing_cap_mesh_layer_4_tri_0[] = {
	gsSPVertex(mario_006_switch_option_left_hand_wing_cap_mesh_layer_4_vtx_0 + 0, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSPEndDisplayList(),
};

Vtx mario_006_switch_option_left_hand_wing_cap_mesh_layer_1_vtx_0[32] = {
	{{{4, 33, 20},0, {624, 240},{0xA1, 0x2E, 0x47, 0xFF}}},
	{{{8, 33, -15},0, {368, 240},{0x9D, 0x2F, 0xC0, 0xFF}}},
	{{{17, -11, -15},0, {368, -16},{0xB9, 0xAC, 0xC0, 0xFF}}},
	{{{14, -12, 20},0, {624, -16},{0xBC, 0xAF, 0x47, 0xFF}}},
	{{{27, 42, 20},0, {496, 1008},{0xF2, 0x5C, 0x57, 0xFF}}},
	{{{4, 33, 20},0, {368, 1008},{0xA1, 0x2E, 0x47, 0xFF}}},
	{{{14, -12, 20},0, {368, 752},{0xBC, 0xAF, 0x47, 0xFF}}},
	{{{39, -11, 20},0, {496, 752},{0x19, 0xA6, 0x57, 0xFF}}},
	{{{60, -2, 16},0, {624, 752},{0x60, 0xD2, 0x45, 0xFF}}},
	{{{51, 43, 16},0, {624, 1008},{0x44, 0x52, 0x45, 0xFF}}},
	{{{27, 42, 20},0, {368, 368},{0xF2, 0x5C, 0x57, 0xFF}}},
	{{{8, 33, -15},0, {112, 240},{0x9D, 0x2F, 0xC0, 0xFF}}},
	{{{4, 33, 20},0, {368, 240},{0xA1, 0x2E, 0x47, 0xFF}}},
	{{{29, 43, -22},0, {112, 368},{0xE7, 0x56, 0xA5, 0xFF}}},
	{{{51, 43, 16},0, {368, 496},{0x44, 0x52, 0x45, 0xFF}}},
	{{{52, 43, -19},0, {112, 496},{0x47, 0x52, 0xBE, 0xFF}}},
	{{{8, 33, -15},0, {624, 752},{0x9D, 0x2F, 0xC0, 0xFF}}},
	{{{40, -11, -22},0, {496, 496},{0xC, 0xA8, 0xA6, 0xFF}}},
	{{{17, -11, -15},0, {624, 496},{0xB9, 0xAC, 0xC0, 0xFF}}},
	{{{29, 43, -22},0, {496, 752},{0xE7, 0x56, 0xA5, 0xFF}}},
	{{{62, -1, -19},0, {368, 496},{0x63, 0xD3, 0xBE, 0xFF}}},
	{{{52, 43, -19},0, {368, 752},{0x47, 0x52, 0xBE, 0xFF}}},
	{{{17, -11, -15},0, {368, 496},{0xB9, 0xAC, 0xC0, 0xFF}}},
	{{{39, -11, 20},0, {624, 368},{0x19, 0xA6, 0x57, 0xFF}}},
	{{{14, -12, 20},0, {624, 496},{0xBC, 0xAF, 0x47, 0xFF}}},
	{{{40, -11, -22},0, {368, 368},{0xC, 0xA8, 0xA6, 0xFF}}},
	{{{60, -2, 16},0, {624, 240},{0x60, 0xD2, 0x45, 0xFF}}},
	{{{62, -1, -19},0, {368, 240},{0x63, 0xD3, 0xBE, 0xFF}}},
	{{{60, -2, 16},0, {880, 496},{0x60, 0xD2, 0x45, 0xFF}}},
	{{{52, 43, -19},0, {624, 240},{0x47, 0x52, 0xBE, 0xFF}}},
	{{{51, 43, 16},0, {880, 240},{0x44, 0x52, 0x45, 0xFF}}},
	{{{62, -1, -19},0, {624, 496},{0x63, 0xD3, 0xBE, 0xFF}}},
};

Gfx mario_006_switch_option_left_hand_wing_cap_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_006_switch_option_left_hand_wing_cap_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(4, 7, 8, 0, 4, 8, 9, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 13, 11, 0),
	gsSP2Triangles(14, 13, 10, 0, 14, 15, 13, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 19, 17, 0),
	gsSP2Triangles(19, 20, 17, 0, 19, 21, 20, 0),
	gsSP2Triangles(22, 23, 24, 0, 22, 25, 23, 0),
	gsSP2Triangles(25, 26, 23, 0, 25, 27, 26, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 31, 29, 0),
	gsSPEndDisplayList(),
};

Vtx mario_006_switch_option_left_hand_wing_cap_wings_mesh_layer_4_vtx_0[8] = {
	{{{4, 126, 44},0, {-16, 1996},{0x62, 0x4A, 0x21, 0xFF}}},
	{{{-17, 215, -93},0, {-16, -16},{0x62, 0x4A, 0x21, 0xFF}}},
	{{{-69, 265, -54},0, {974, -16},{0x62, 0x4A, 0x21, 0xFF}}},
	{{{-47, 175, 83},0, {974, 1996},{0x62, 0x4A, 0x21, 0xFF}}},
	{{{-110, -133, -162},0, {974, -16},{0x50, 0x9E, 0xF3, 0xFF}}},
	{{{-48, -80, -174},0, {-16, -16},{0x50, 0x9E, 0xF3, 0xFF}}},
	{{{-17, -78, -12},0, {-16, 1996},{0x50, 0x9E, 0xF3, 0xFF}}},
	{{{-80, -131, 0},0, {974, 1996},{0x50, 0x9E, 0xF3, 0xFF}}},
};

Gfx mario_006_switch_option_left_hand_wing_cap_wings_mesh_layer_4_tri_0[] = {
	gsSPVertex(mario_006_switch_option_left_hand_wing_cap_wings_mesh_layer_4_vtx_0 + 0, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSPEndDisplayList(),
};

Vtx mario_006_switch_option_left_hand_wing_cap_wings_mesh_layer_4_vtx_1[8] = {
	{{{-48, -80, -174},0, {974, -16},{0x50, 0x9E, 0xF3, 0xFF}}},
	{{{45, -27, -25},0, {-16, 1996},{0x4F, 0x9E, 0xF3, 0xFF}}},
	{{{-17, -78, -12},0, {974, 1996},{0x50, 0x9E, 0xF3, 0xFF}}},
	{{{14, -29, -186},0, {-16, -16},{0x50, 0x9E, 0xF3, 0xFF}}},
	{{{4, 126, 44},0, {974, 1996},{0x62, 0x4A, 0x21, 0xFF}}},
	{{{56, 76, 3},0, {-16, 1996},{0x62, 0x4A, 0x21, 0xFF}}},
	{{{-17, 215, -93},0, {974, -16},{0x62, 0x4A, 0x21, 0xFF}}},
	{{{34, 165, -133},0, {-16, -16},{0x62, 0x4A, 0x20, 0xFF}}},
};

Gfx mario_006_switch_option_left_hand_wing_cap_wings_mesh_layer_4_tri_1[] = {
	gsSPVertex(mario_006_switch_option_left_hand_wing_cap_wings_mesh_layer_4_vtx_1 + 0, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 5, 7, 6, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_009_skinned_mesh_layer_1_vtx_0[8] = {
	{{{-73, 41, 0},0, {992, 790},{0x8B, 0x31, 0x0, 0xFF}}},
	{{{-73, 41, 0},0, {134, 774},{0x8B, 0x31, 0x0, 0xFF}}},
	{{{-73, 35, 57},0, {770, 376},{0x96, 0x33, 0x30, 0xFF}}},
	{{{-73, 35, 57},0, {221, 776},{0x96, 0x33, 0x30, 0xFF}}},
	{{{-73, -29, 57},0, {673, 380},{0xA3, 0xC2, 0x3D, 0xFF}}},
	{{{-73, -32, 0},0, {428, 778},{0x99, 0xB5, 0x0, 0xFF}}},
	{{{-73, -29, 57},0, {341, 778},{0xA3, 0xC2, 0x3D, 0xFF}}},
	{{{-73, -32, 0},0, {881, 790},{0x99, 0xB5, 0x0, 0xFF}}},
};

Gfx mario_000_offset_009_skinned_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_000_offset_009_skinned_mesh_layer_1_vtx_0 + 0, 8, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_009_mesh_layer_1_vtx_0[9] = {
	{{{48, -24, 29},0, {210, 848},{0xE6, 0x9F, 0x4E, 0xFF}}},
	{{{48, -22, -20},0, {136, 849},{0xE1, 0xA2, 0xB0, 0xFF}}},
	{{{5, 32, 36},0, {673, 374},{0xBE, 0x46, 0x53, 0xFF}}},
	{{{48, -24, 29},0, {755, 304},{0xE6, 0x9F, 0x4E, 0xFF}}},
	{{{5, 32, 36},0, {341, 783},{0xBE, 0x46, 0x53, 0xFF}}},
	{{{5, 35, -21},0, {427, 782},{0xBA, 0x4C, 0xB6, 0xFF}}},
	{{{5, 35, -21},0, {881, 795},{0xBA, 0x4C, 0xB6, 0xFF}}},
	{{{49, 4, -19},0, {928, 861},{0x5, 0x2, 0x81, 0xFF}}},
	{{{48, -22, -20},0, {968, 861},{0xE1, 0xA2, 0xB0, 0xFF}}},
};

Gfx mario_000_offset_009_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_000_offset_009_mesh_layer_1_vtx_0 + 0, 9, 8),
	gsSP2Triangles(1, 8, 3, 0, 1, 9, 8, 0),
	gsSP2Triangles(2, 10, 4, 0, 10, 2, 11, 0),
	gsSP2Triangles(5, 6, 12, 0, 5, 12, 13, 0),
	gsSP2Triangles(0, 7, 14, 0, 15, 0, 14, 0),
	gsSP1Triangle(0, 15, 16, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_009_mesh_layer_1_vtx_1[10] = {
	{{{5, 35, -21},0, {427, 782},{0xBA, 0x4C, 0xB6, 0xFF}}},
	{{{5, 32, 36},0, {341, 783},{0xBE, 0x46, 0x53, 0xFF}}},
	{{{42, 29, 31},0, {349, 840},{0x15, 0x56, 0x5B, 0xFF}}},
	{{{39, 30, -19},0, {425, 835},{0xD, 0x5A, 0xA7, 0xFF}}},
	{{{5, 32, 36},0, {673, 374},{0xBE, 0x46, 0x53, 0xFF}}},
	{{{48, -24, 29},0, {755, 304},{0xE6, 0x9F, 0x4E, 0xFF}}},
	{{{42, 29, 31},0, {675, 317},{0x15, 0x56, 0x5B, 0xFF}}},
	{{{49, 4, -19},0, {928, 861},{0x5, 0x2, 0x81, 0xFF}}},
	{{{5, 35, -21},0, {881, 795},{0xBA, 0x4C, 0xB6, 0xFF}}},
	{{{39, 30, -19},0, {889, 846},{0xD, 0x5A, 0xA7, 0xFF}}},
};

Gfx mario_000_offset_009_mesh_layer_1_tri_1[] = {
	gsSPVertex(mario_000_offset_009_mesh_layer_1_vtx_1 + 0, 10, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 7, 8, 9, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_010_skinned_mesh_layer_1_vtx_0[9] = {
	{{{49, 4, -19},0, {928, 861},{0x5, 0x2, 0x81, 0xFF}}},
	{{{48, -22, -20},0, {136, 849},{0xE1, 0xA2, 0xB0, 0xFF}}},
	{{{48, -24, 29},0, {755, 304},{0xE6, 0x9F, 0x4E, 0xFF}}},
	{{{48, -24, 29},0, {210, 848},{0xE6, 0x9F, 0x4E, 0xFF}}},
	{{{48, -22, -20},0, {968, 861},{0xE1, 0xA2, 0xB0, 0xFF}}},
	{{{39, 30, -19},0, {889, 846},{0xD, 0x5A, 0xA7, 0xFF}}},
	{{{42, 29, 31},0, {349, 840},{0x15, 0x56, 0x5B, 0xFF}}},
	{{{39, 30, -19},0, {425, 835},{0xD, 0x5A, 0xA7, 0xFF}}},
	{{{42, 29, 31},0, {675, 317},{0x15, 0x56, 0x5B, 0xFF}}},
};

Gfx mario_000_offset_010_skinned_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_000_offset_010_skinned_mesh_layer_1_vtx_0 + 0, 9, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_010_mesh_layer_1_vtx_0[11] = {
	{{{3, -23, 28},0, {209, 855},{0x1F, 0xA6, 0x55, 0xFF}}},
	{{{3, -21, -19},0, {137, 856},{0x14, 0xAB, 0xA3, 0xFF}}},
	{{{3, -21, -19},0, {967, 867},{0x14, 0xAB, 0xA3, 0xFF}}},
	{{{43, -13, -18},0, {953, 927},{0x18, 0xAD, 0xA3, 0xFF}}},
	{{{35, 27, -17},0, {893, 917},{0x13, 0x5F, 0xAE, 0xFF}}},
	{{{6, 29, -18},0, {890, 873},{0xA, 0x5C, 0xA9, 0xFF}}},
	{{{6, 29, -18},0, {424, 861},{0xA, 0x5C, 0xA9, 0xFF}}},
	{{{11, 27, 28},0, {354, 869},{0x15, 0x56, 0x5B, 0xFF}}},
	{{{3, -23, 28},0, {753, 297},{0x1F, 0xA6, 0x55, 0xFF}}},
	{{{0, 2, 29},0, {715, 302},{0x14, 0xFE, 0x7D, 0xFF}}},
	{{{11, 27, 28},0, {677, 288},{0x15, 0x56, 0x5B, 0xFF}}},
};

Gfx mario_000_offset_010_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_000_offset_010_mesh_layer_1_vtx_0 + 0, 11, 9),
	gsSP2Triangles(1, 9, 3, 0, 1, 10, 9, 0),
	gsSP2Triangles(11, 4, 0, 0, 11, 0, 12, 0),
	gsSP2Triangles(12, 0, 13, 0, 13, 0, 14, 0),
	gsSP2Triangles(0, 5, 14, 0, 6, 15, 7, 0),
	gsSP2Triangles(6, 16, 15, 0, 2, 17, 18, 0),
	gsSP2Triangles(2, 18, 8, 0, 18, 19, 8, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_010_mesh_layer_1_vtx_1[13] = {
	{{{11, 27, 28},0, {354, 869},{0x15, 0x56, 0x5B, 0xFF}}},
	{{{35, 27, -17},0, {422, 905},{0x13, 0x5F, 0xAE, 0xFF}}},
	{{{6, 29, -18},0, {424, 861},{0xA, 0x5C, 0xA9, 0xFF}}},
	{{{43, 24, 23},0, {361, 917},{0x13, 0x5B, 0x57, 0xFF}}},
	{{{43, -16, 21},0, {740, 236},{0x1F, 0xA1, 0x4E, 0xFF}}},
	{{{0, 2, 29},0, {715, 302},{0x14, 0xFE, 0x7D, 0xFF}}},
	{{{3, -23, 28},0, {753, 297},{0x1F, 0xA6, 0x55, 0xFF}}},
	{{{43, 24, 23},0, {680, 239},{0x13, 0x5B, 0x57, 0xFF}}},
	{{{11, 27, 28},0, {677, 288},{0x15, 0x56, 0x5B, 0xFF}}},
	{{{3, -21, -19},0, {137, 856},{0x14, 0xAB, 0xA3, 0xFF}}},
	{{{43, -16, 21},0, {198, 917},{0x1F, 0xA1, 0x4E, 0xFF}}},
	{{{3, -23, 28},0, {209, 855},{0x1F, 0xA6, 0x55, 0xFF}}},
	{{{43, -13, -18},0, {138, 917},{0x18, 0xAD, 0xA3, 0xFF}}},
};

Gfx mario_000_offset_010_mesh_layer_1_tri_1[] = {
	gsSPVertex(mario_000_offset_010_mesh_layer_1_vtx_1 + 0, 13, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 5, 4, 7, 0),
	gsSP2Triangles(5, 7, 8, 0, 9, 10, 11, 0),
	gsSP1Triangle(9, 12, 10, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_011_skinned_mesh_layer_1_vtx_0[8] = {
	{{{43, 24, 23},0, {361, 917},{0x13, 0x5B, 0x57, 0xFF}}},
	{{{43, -16, 21},0, {740, 236},{0x1F, 0xA1, 0x4E, 0xFF}}},
	{{{43, 24, 23},0, {680, 239},{0x13, 0x5B, 0x57, 0xFF}}},
	{{{43, -16, 21},0, {198, 917},{0x1F, 0xA1, 0x4E, 0xFF}}},
	{{{43, -13, -18},0, {953, 927},{0x18, 0xAD, 0xA3, 0xFF}}},
	{{{35, 27, -17},0, {893, 917},{0x13, 0x5F, 0xAE, 0xFF}}},
	{{{35, 27, -17},0, {422, 905},{0x13, 0x5F, 0xAE, 0xFF}}},
	{{{43, -13, -18},0, {138, 917},{0x18, 0xAD, 0xA3, 0xFF}}},
};

Gfx mario_000_offset_011_skinned_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_000_offset_011_skinned_mesh_layer_1_vtx_0 + 0, 8, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_011_mesh_layer_1_vtx_0[8] = {
	{{{36, -9, 22},0, {706, 152},{0x6E, 0xFE, 0x40, 0xFF}}},
	{{{-11, 8, 25},0, {683, 223},{0x15, 0x52, 0x5E, 0xFF}}},
	{{{32, -8, -19},0, {138, 1003},{0x67, 0x1, 0xB5, 0xFF}}},
	{{{36, -9, 22},0, {200, 1008},{0x6E, 0xFE, 0x40, 0xFF}}},
	{{{-14, 9, -17},0, {900, 939},{0x1B, 0x59, 0xA9, 0xFF}}},
	{{{32, -8, -19},0, {926, 1008},{0x67, 0x1, 0xB5, 0xFF}}},
	{{{-14, 9, -17},0, {422, 929},{0x1B, 0x59, 0xA9, 0xFF}}},
	{{{-11, 8, 25},0, {359, 934},{0x15, 0x52, 0x5E, 0xFF}}},
};

Gfx mario_000_offset_011_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_000_offset_011_mesh_layer_1_vtx_0 + 0, 8, 8),
	gsSP2Triangles(1, 8, 9, 0, 1, 9, 2, 0),
	gsSP2Triangles(3, 10, 11, 0, 3, 7, 10, 0),
	gsSP2Triangles(4, 5, 12, 0, 4, 12, 13, 0),
	gsSP2Triangles(0, 14, 6, 0, 0, 15, 14, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_011_mesh_layer_1_vtx_1[4] = {
	{{{-11, 8, 25},0, {359, 934},{0x15, 0x52, 0x5E, 0xFF}}},
	{{{36, -9, 22},0, {363, 1008},{0x6E, 0xFE, 0x40, 0xFF}}},
	{{{32, -8, -19},0, {426, 1003},{0x67, 0x1, 0xB5, 0xFF}}},
	{{{-14, 9, -17},0, {422, 929},{0x1B, 0x59, 0xA9, 0xFF}}},
};

Gfx mario_000_offset_011_mesh_layer_1_tri_1[] = {
	gsSPVertex(mario_000_offset_011_mesh_layer_1_vtx_1 + 0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_012_skinned_mesh_layer_1_vtx_0[8] = {
	{{{-73, 41, 0},0, {896, 392},{0x8B, 0x31, 0x0, 0xFF}}},
	{{{-73, 41, 0},0, {134, 774},{0x8B, 0x31, 0x0, 0xFF}}},
	{{{-73, 35, -57},0, {668, 385},{0x96, 0x33, 0xD0, 0xFF}}},
	{{{-73, 35, -57},0, {47, 776},{0x96, 0x33, 0xD0, 0xFF}}},
	{{{-73, -29, -57},0, {570, 382},{0xA3, 0xC2, 0xC3, 0xFF}}},
	{{{-73, -32, 0},0, {428, 778},{0x99, 0xB5, 0x0, 0xFF}}},
	{{{-73, -29, -57},0, {515, 778},{0xA3, 0xC2, 0xC3, 0xFF}}},
	{{{-73, -32, 0},0, {1008, 392},{0x99, 0xB5, 0x0, 0xFF}}},
};

Gfx mario_000_offset_012_skinned_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_000_offset_012_skinned_mesh_layer_1_vtx_0 + 0, 8, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_012_mesh_layer_1_vtx_0[9] = {
	{{{48, -24, -29},0, {59, 848},{0xE6, 0x9F, 0xB2, 0xFF}}},
	{{{48, -22, 20},0, {133, 849},{0xE1, 0xA2, 0x50, 0xFF}}},
	{{{5, 32, -36},0, {571, 387},{0xBE, 0x46, 0xAD, 0xFF}}},
	{{{48, -24, -29},0, {653, 457},{0xE6, 0x9F, 0xB2, 0xFF}}},
	{{{5, 32, -36},0, {514, 783},{0xBE, 0x46, 0xAD, 0xFF}}},
	{{{5, 35, 21},0, {428, 782},{0xBA, 0x4C, 0x4A, 0xFF}}},
	{{{5, 35, 21},0, {1008, 396},{0xBA, 0x4C, 0x4A, 0xFF}}},
	{{{49, 4, 19},0, {960, 463},{0x5, 0x2, 0x7F, 0xFF}}},
	{{{48, -22, 20},0, {920, 462},{0xE1, 0xA2, 0x50, 0xFF}}},
};

Gfx mario_000_offset_012_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_000_offset_012_mesh_layer_1_vtx_0 + 0, 9, 8),
	gsSP2Triangles(1, 3, 8, 0, 1, 8, 9, 0),
	gsSP2Triangles(2, 4, 10, 0, 10, 11, 2, 0),
	gsSP2Triangles(5, 12, 6, 0, 5, 13, 12, 0),
	gsSP2Triangles(0, 14, 7, 0, 15, 14, 0, 0),
	gsSP1Triangle(0, 16, 15, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_012_mesh_layer_1_vtx_1[10] = {
	{{{5, 35, 21},0, {428, 782},{0xBA, 0x4C, 0x4A, 0xFF}}},
	{{{42, 29, -31},0, {506, 840},{0x15, 0x56, 0xA5, 0xFF}}},
	{{{5, 32, -36},0, {514, 783},{0xBE, 0x46, 0xAD, 0xFF}}},
	{{{39, 30, 19},0, {430, 835},{0xD, 0x5A, 0x59, 0xFF}}},
	{{{5, 32, -36},0, {571, 387},{0xBE, 0x46, 0xAD, 0xFF}}},
	{{{42, 29, -31},0, {573, 444},{0x15, 0x56, 0xA5, 0xFF}}},
	{{{48, -24, -29},0, {653, 457},{0xE6, 0x9F, 0xB2, 0xFF}}},
	{{{49, 4, 19},0, {960, 463},{0x5, 0x2, 0x7F, 0xFF}}},
	{{{39, 30, 19},0, {1000, 448},{0xD, 0x5A, 0x59, 0xFF}}},
	{{{5, 35, 21},0, {1008, 396},{0xBA, 0x4C, 0x4A, 0xFF}}},
};

Gfx mario_000_offset_012_mesh_layer_1_tri_1[] = {
	gsSPVertex(mario_000_offset_012_mesh_layer_1_vtx_1 + 0, 10, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 7, 8, 9, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_013_skinned_mesh_layer_1_vtx_0[9] = {
	{{{49, 4, 19},0, {960, 463},{0x5, 0x2, 0x7F, 0xFF}}},
	{{{39, 30, 19},0, {1000, 448},{0xD, 0x5A, 0x59, 0xFF}}},
	{{{42, 29, -31},0, {506, 840},{0x15, 0x56, 0xA5, 0xFF}}},
	{{{39, 30, 19},0, {430, 835},{0xD, 0x5A, 0x59, 0xFF}}},
	{{{48, -22, 20},0, {133, 849},{0xE1, 0xA2, 0x50, 0xFF}}},
	{{{48, -24, -29},0, {653, 457},{0xE6, 0x9F, 0xB2, 0xFF}}},
	{{{48, -24, -29},0, {59, 848},{0xE6, 0x9F, 0xB2, 0xFF}}},
	{{{48, -22, 20},0, {920, 462},{0xE1, 0xA2, 0x50, 0xFF}}},
	{{{42, 29, -31},0, {573, 444},{0x15, 0x56, 0xA5, 0xFF}}},
};

Gfx mario_000_offset_013_skinned_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_000_offset_013_skinned_mesh_layer_1_vtx_0 + 0, 9, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_013_mesh_layer_1_vtx_0[11] = {
	{{{6, 29, 18},0, {998, 474},{0xA, 0x5C, 0x57, 0xFF}}},
	{{{35, 27, 17},0, {996, 518},{0x13, 0x5F, 0x52, 0xFF}}},
	{{{43, -13, 18},0, {935, 529},{0x18, 0xAD, 0x5D, 0xFF}}},
	{{{3, -21, 19},0, {922, 469},{0x14, 0xAB, 0x5D, 0xFF}}},
	{{{6, 29, 18},0, {432, 861},{0xA, 0x5C, 0x57, 0xFF}}},
	{{{11, 27, -28},0, {502, 869},{0x15, 0x56, 0xA5, 0xFF}}},
	{{{3, -23, -28},0, {60, 855},{0x1F, 0xA6, 0xAB, 0xFF}}},
	{{{3, -21, 19},0, {133, 856},{0x14, 0xAB, 0x5D, 0xFF}}},
	{{{0, 2, -29},0, {613, 459},{0x14, 0xFE, 0x83, 0xFF}}},
	{{{3, -23, -28},0, {651, 464},{0x1F, 0xA6, 0xAB, 0xFF}}},
	{{{11, 27, -28},0, {575, 473},{0x15, 0x56, 0xA5, 0xFF}}},
};

Gfx mario_000_offset_013_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_000_offset_013_mesh_layer_1_vtx_0 + 0, 11, 9),
	gsSP2Triangles(0, 9, 1, 0, 10, 9, 0, 0),
	gsSP2Triangles(11, 10, 0, 0, 12, 11, 0, 0),
	gsSP2Triangles(12, 0, 7, 0, 2, 3, 13, 0),
	gsSP2Triangles(2, 13, 14, 0, 4, 6, 15, 0),
	gsSP2Triangles(4, 15, 16, 0, 5, 17, 18, 0),
	gsSP2Triangles(5, 8, 17, 0, 17, 8, 19, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_offset_013_mesh_layer_1_vtx_1[13] = {
	{{{11, 27, -28},0, {502, 869},{0x15, 0x56, 0xA5, 0xFF}}},
	{{{6, 29, 18},0, {432, 861},{0xA, 0x5C, 0x57, 0xFF}}},
	{{{35, 27, 17},0, {434, 905},{0x13, 0x5F, 0x52, 0xFF}}},
	{{{43, 24, -23},0, {494, 917},{0x13, 0x5B, 0xA9, 0xFF}}},
	{{{43, -16, -21},0, {638, 525},{0x1F, 0xA1, 0xB2, 0xFF}}},
	{{{3, -23, -28},0, {651, 464},{0x1F, 0xA6, 0xAB, 0xFF}}},
	{{{0, 2, -29},0, {613, 459},{0x14, 0xFE, 0x83, 0xFF}}},
	{{{43, 24, -23},0, {577, 522},{0x13, 0x5B, 0xA9, 0xFF}}},
	{{{11, 27, -28},0, {575, 473},{0x15, 0x56, 0xA5, 0xFF}}},
	{{{3, -21, 19},0, {133, 856},{0x14, 0xAB, 0x5D, 0xFF}}},
	{{{3, -23, -28},0, {60, 855},{0x1F, 0xA6, 0xAB, 0xFF}}},
	{{{43, -16, -21},0, {71, 917},{0x1F, 0xA1, 0xB2, 0xFF}}},
	{{{43, -13, 18},0, {131, 917},{0x18, 0xAD, 0x5D, 0xFF}}},
};

Gfx mario_000_offset_013_mesh_layer_1_tri_1[] = {
	gsSPVertex(mario_000_offset_013_mesh_layer_1_vtx_1 + 0, 13, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 6, 7, 4, 0),
	gsSP2Triangles(6, 8, 7, 0, 9, 10, 11, 0),
	gsSP1Triangle(9, 11, 12, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_displaylist_005_skinned_mesh_layer_1_vtx_0[8] = {
	{{{43, 24, -23},0, {494, 917},{0x13, 0x5B, 0xA9, 0xFF}}},
	{{{43, -16, -21},0, {638, 525},{0x1F, 0xA1, 0xB2, 0xFF}}},
	{{{43, 24, -23},0, {577, 522},{0x13, 0x5B, 0xA9, 0xFF}}},
	{{{43, -16, -21},0, {71, 917},{0x1F, 0xA1, 0xB2, 0xFF}}},
	{{{43, -13, 18},0, {935, 529},{0x18, 0xAD, 0x5D, 0xFF}}},
	{{{35, 27, 17},0, {996, 518},{0x13, 0x5F, 0x52, 0xFF}}},
	{{{35, 27, 17},0, {434, 905},{0x13, 0x5F, 0x52, 0xFF}}},
	{{{43, -13, 18},0, {131, 917},{0x18, 0xAD, 0x5D, 0xFF}}},
};

Gfx mario_000_displaylist_005_skinned_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_000_displaylist_005_skinned_mesh_layer_1_vtx_0 + 0, 8, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_displaylist_005_mesh_layer_1_vtx_0[8] = {
	{{{-11, 8, -25},0, {581, 538},{0x15, 0x52, 0xA2, 0xFF}}},
	{{{36, -9, -22},0, {604, 610},{0x6E, 0xFE, 0xC0, 0xFF}}},
	{{{36, -9, -22},0, {70, 1008},{0x6E, 0xFE, 0xC0, 0xFF}}},
	{{{32, -8, 19},0, {133, 1003},{0x67, 0x1, 0x4B, 0xFF}}},
	{{{-14, 9, 17},0, {988, 540},{0x1B, 0x59, 0x57, 0xFF}}},
	{{{32, -8, 19},0, {962, 610},{0x67, 0x1, 0x4B, 0xFF}}},
	{{{-14, 9, 17},0, {434, 929},{0x1B, 0x59, 0x57, 0xFF}}},
	{{{-11, 8, -25},0, {496, 934},{0x15, 0x52, 0xA2, 0xFF}}},
};

Gfx mario_000_displaylist_005_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_000_displaylist_005_mesh_layer_1_vtx_0 + 0, 8, 8),
	gsSP2Triangles(1, 8, 9, 0, 1, 2, 8, 0),
	gsSP2Triangles(3, 10, 11, 0, 3, 11, 7, 0),
	gsSP2Triangles(4, 12, 5, 0, 4, 13, 12, 0),
	gsSP2Triangles(0, 6, 14, 0, 0, 14, 15, 0),
	gsSPEndDisplayList(),
};

Vtx mario_000_displaylist_005_mesh_layer_1_vtx_1[4] = {
	{{{-11, 8, -25},0, {496, 934},{0x15, 0x52, 0xA2, 0xFF}}},
	{{{32, -8, 19},0, {430, 1003},{0x67, 0x1, 0x4B, 0xFF}}},
	{{{36, -9, -22},0, {493, 1008},{0x6E, 0xFE, 0xC0, 0xFF}}},
	{{{-14, 9, 17},0, {434, 929},{0x1B, 0x59, 0x57, 0xFF}}},
};

Gfx mario_000_displaylist_005_mesh_layer_1_tri_1[] = {
	gsSPVertex(mario_000_displaylist_005_mesh_layer_1_vtx_1 + 0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_mesh_layer_1_vtx_0[5] = {
	{{{-8, 32, -83},0, {35, 679},{0xD5, 0x47, 0xA0, 0xFF}}},
	{{{-73, 35, -57},0, {111, 776},{0x96, 0x33, 0xD0, 0xFF}}},
	{{{-73, 41, 0},0, {284, 774},{0x8B, 0x31, 0x0, 0xFF}}},
	{{{-8, 32, 83},0, {539, 679},{0xD5, 0x47, 0x60, 0xFF}}},
	{{{-73, 35, 57},0, {459, 776},{0x96, 0x33, 0x30, 0xFF}}},
};

Gfx mario_001_switch_000_offset_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_000_offset_mesh_layer_1_vtx_0 + 0, 5, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 2, 4, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_001_skinned_mesh_layer_1_vtx_0[12] = {
	{{{-8, 32, -83},0, {35, 679},{0xD5, 0x47, 0xA0, 0xFF}}},
	{{{-73, 41, 0},0, {284, 774},{0x8B, 0x31, 0x0, 0xFF}}},
	{{{-8, 32, 83},0, {539, 679},{0xD5, 0x47, 0x60, 0xFF}}},
	{{{-8, 32, -83},0, {1352, 281},{0xD5, 0x47, 0xA0, 0xFF}}},
	{{{-73, -29, -57},0, {1046, 778},{0xA3, 0xC2, 0xC3, 0xFF}}},
	{{{-73, -32, 0},0, {871, 778},{0x99, 0xB5, 0x0, 0xFF}}},
	{{{-73, -29, 57},0, {697, 778},{0xA3, 0xC2, 0x3D, 0xFF}}},
	{{{-73, -29, -57},0, {1157, 382},{0xA3, 0xC2, 0xC3, 0xFF}}},
	{{{-73, 35, -57},0, {1352, 385},{0x96, 0x33, 0xD0, 0xFF}}},
	{{{-8, 32, 83},0, {1556, 480},{0xD5, 0x47, 0x60, 0xFF}}},
	{{{-73, -29, 57},0, {1361, 380},{0xA3, 0xC2, 0x3D, 0xFF}}},
	{{{-73, 35, 57},0, {1556, 376},{0x96, 0x33, 0x30, 0xFF}}},
};

Gfx mario_001_switch_000_offset_001_skinned_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_000_offset_001_skinned_mesh_layer_1_vtx_0 + 0, 12, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_001_mesh_layer_1_vtx_0[12] = {
	{{{-42, 54, 0},0, {282, 651},{0xD9, 0x79, 0x0, 0xFF}}},
	{{{-40, 21, -90},0, {14, 657},{0xD2, 0x41, 0x9D, 0xFF}}},
	{{{-40, 21, 90},0, {561, 657},{0xD2, 0x41, 0x63, 0xFF}}},
	{{{-40, 21, -90},0, {1352, 257},{0xD2, 0x41, 0x9D, 0xFF}}},
	{{{-47, -12, -85},0, {1250, 266},{0xD0, 0xF8, 0x8B, 0xFF}}},
	{{{-53, -45, -79},0, {1150, 275},{0xDA, 0xAD, 0xA8, 0xFF}}},
	{{{-53, -45, -79},0, {1112, 676},{0xDA, 0xAD, 0xA8, 0xFF}}},
	{{{-37, -64, 0},0, {871, 647},{0xEF, 0x82, 0x0, 0xFF}}},
	{{{-53, -45, 79},0, {630, 676},{0xDA, 0xAD, 0x58, 0xFF}}},
	{{{-47, -12, 85},0, {1455, 495},{0xD0, 0xF8, 0x75, 0xFF}}},
	{{{-40, 21, 90},0, {1556, 504},{0xD2, 0x41, 0x63, 0xFF}}},
	{{{-53, -45, 79},0, {1354, 486},{0xDA, 0xAD, 0x58, 0xFF}}},
};

Gfx mario_001_switch_000_offset_001_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_000_offset_001_mesh_layer_1_vtx_0 + 0, 12, 12),
	gsSP2Triangles(12, 13, 0, 0, 1, 12, 0, 0),
	gsSP2Triangles(1, 2, 12, 0, 12, 2, 14, 0),
	gsSP2Triangles(3, 15, 16, 0, 8, 3, 16, 0),
	gsSP2Triangles(7, 8, 16, 0, 16, 17, 7, 0),
	gsSP2Triangles(4, 18, 19, 0, 4, 19, 5, 0),
	gsSP2Triangles(6, 5, 19, 0, 6, 19, 20, 0),
	gsSP2Triangles(9, 21, 22, 0, 11, 21, 9, 0),
	gsSP2Triangles(10, 21, 11, 0, 21, 10, 23, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_001_mesh_layer_1_vtx_1[61] = {
	{{{71, 29, -101},0, {1596, 717},{0x3F, 0x34, 0x9F, 0xFF}}},
	{{{38, 38, -49},0, {1596, 626},{0x54, 0x5D, 0x15, 0xFF}}},
	{{{71, 12, -35},0, {1499, 627},{0x69, 0x47, 0xF5, 0xFF}}},
	{{{-9, 66, 0},0, {595, 150},{0xFD, 0x7F, 0x0, 0xFF}}},
	{{{38, 38, -49},0, {563, 240},{0x54, 0x5D, 0x15, 0xFF}}},
	{{{71, 29, -101},0, {595, 319},{0x3F, 0x34, 0x9F, 0xFF}}},
	{{{-9, 66, 0},0, {595, 489},{0xFD, 0x7F, 0x0, 0xFF}}},
	{{{71, 29, 101},0, {595, 319},{0x3F, 0x36, 0x60, 0xFF}}},
	{{{38, 38, 49},0, {563, 399},{0x54, 0x5D, 0xEB, 0xFF}}},
	{{{71, 29, 101},0, {1683, 717},{0x3F, 0x36, 0x60, 0xFF}}},
	{{{71, 12, 35},0, {1683, 618},{0x69, 0x47, 0xB, 0xFF}}},
	{{{38, 38, 49},0, {1596, 635},{0x54, 0x5D, 0xEB, 0xFF}}},
	{{{-9, 66, 0},0, {281, 599},{0xFD, 0x7F, 0x0, 0xFF}}},
	{{{71, 29, -101},0, {-16, 489},{0x3F, 0x34, 0x9F, 0xFF}}},
	{{{-32, 20, -94},0, {3, 644},{0xF6, 0x2E, 0x8A, 0xFF}}},
	{{{-40, 21, -90},0, {14, 657},{0xD2, 0x41, 0x9D, 0xFF}}},
	{{{-42, 54, 0},0, {282, 651},{0xD9, 0x79, 0x0, 0xFF}}},
	{{{-40, 21, 90},0, {561, 657},{0xD2, 0x41, 0x63, 0xFF}}},
	{{{-32, 20, 94},0, {573, 644},{0xF6, 0x2E, 0x76, 0xFF}}},
	{{{71, 29, 101},0, {595, 489},{0x3F, 0x36, 0x60, 0xFF}}},
	{{{-33, -47, -87},0, {1136, 646},{0xF8, 0xB9, 0x97, 0xFF}}},
	{{{72, -58, -91},0, {1148, 485},{0x3F, 0xBB, 0xAA, 0xFF}}},
	{{{48, -72, 0},0, {871, 518},{0x31, 0x8B, 0x0, 0xFF}}},
	{{{-37, -64, 0},0, {871, 647},{0xEF, 0x82, 0x0, 0xFF}}},
	{{{-33, -47, 87},0, {606, 646},{0xF8, 0xB9, 0x69, 0xFF}}},
	{{{72, -58, 91},0, {595, 485},{0x3F, 0xBA, 0x56, 0xFF}}},
	{{{-37, -46, 86},0, {611, 652},{0xD7, 0xAE, 0x58, 0xFF}}},
	{{{-53, -45, 79},0, {630, 676},{0xDA, 0xAD, 0x58, 0xFF}}},
	{{{41, 45, 0},0, {1915, 716},{0x46, 0x6A, 0x0, 0xFF}}},
	{{{38, 38, -49},0, {1915, 642},{0x54, 0x5D, 0x15, 0xFF}}},
	{{{-9, 66, 0},0, {1777, 708},{0xFD, 0x7F, 0x0, 0xFF}}},
	{{{38, 38, 49},0, {1889, 790},{0x54, 0x5D, 0xEB, 0xFF}}},
	{{{71, 12, -35},0, {1271, 745},{0x69, 0x47, 0xF5, 0xFF}}},
	{{{38, 38, -49},0, {1186, 718},{0x54, 0x5D, 0x15, 0xFF}}},
	{{{41, 45, 0},0, {1148, 790},{0x46, 0x6A, 0x0, 0xFF}}},
	{{{88, -7, 0},0, {1320, 801},{0x7F, 0x8, 0x0, 0xFF}}},
	{{{71, 12, 35},0, {1247, 849},{0x69, 0x47, 0xB, 0xFF}}},
	{{{38, 38, 49},0, {1151, 865},{0x54, 0x5D, 0xEB, 0xFF}}},
	{{{84, -7, 23},0, {1311, 835},{0x7D, 0xB, 0x15, 0xFF}}},
	{{{48, -72, 0},0, {1499, 811},{0x31, 0x8B, 0x0, 0xFF}}},
	{{{72, -58, 91},0, {1434, 946},{0x3F, 0xBA, 0x56, 0xFF}}},
	{{{71, 29, 101},0, {1172, 946},{0x3F, 0x36, 0x60, 0xFF}}},
	{{{84, -7, -23},0, {1327, 766},{0x7D, 0xB, 0xEB, 0xFF}}},
	{{{72, -58, -91},0, {1499, 672},{0x3F, 0xBB, 0xAA, 0xFF}}},
	{{{71, 29, -101},0, {1244, 642},{0x3F, 0x34, 0x9F, 0xFF}}},
	{{{-37, -64, 0},0, {871, 647},{0xEF, 0x82, 0x0, 0xFF}}},
	{{{-37, -46, -86},0, {1131, 652},{0xD7, 0xAE, 0xA8, 0xFF}}},
	{{{-33, -47, -87},0, {1136, 646},{0xF8, 0xB9, 0x97, 0xFF}}},
	{{{-53, -45, -79},0, {1112, 676},{0xDA, 0xAD, 0xA8, 0xFF}}},
	{{{-47, -12, -85},0, {1250, 266},{0xD0, 0xF8, 0x8B, 0xFF}}},
	{{{-40, 21, -90},0, {1352, 257},{0xD2, 0x41, 0x9D, 0xFF}}},
	{{{-32, 20, -94},0, {1352, 243},{0xF6, 0x2E, 0x8A, 0xFF}}},
	{{{-33, -47, -87},0, {1148, 243},{0xF8, 0xB9, 0x97, 0xFF}}},
	{{{-37, -46, -86},0, {1148, 250},{0xD7, 0xAE, 0xA8, 0xFF}}},
	{{{-53, -45, -79},0, {1150, 275},{0xDA, 0xAD, 0xA8, 0xFF}}},
	{{{-47, -12, 85},0, {1455, 495},{0xD0, 0xF8, 0x75, 0xFF}}},
	{{{-32, 20, 94},0, {1556, 518},{0xF6, 0x2E, 0x76, 0xFF}}},
	{{{-40, 21, 90},0, {1556, 504},{0xD2, 0x41, 0x63, 0xFF}}},
	{{{-33, -47, 87},0, {1352, 518},{0xF8, 0xB9, 0x69, 0xFF}}},
	{{{-37, -46, 86},0, {1352, 511},{0xD7, 0xAE, 0x58, 0xFF}}},
	{{{-53, -45, 79},0, {1354, 486},{0xDA, 0xAD, 0x58, 0xFF}}},
};

Gfx mario_001_switch_000_offset_001_mesh_layer_1_tri_1[] = {
	gsSPVertex(mario_001_switch_000_offset_001_mesh_layer_1_vtx_1 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 14, 15, 12, 0),
	gsSP2Triangles(15, 16, 12, 0, 17, 12, 16, 0),
	gsSP2Triangles(18, 12, 17, 0, 12, 18, 19, 0),
	gsSP2Triangles(20, 21, 22, 0, 22, 23, 20, 0),
	gsSP2Triangles(22, 24, 23, 0, 24, 22, 25, 0),
	gsSP2Triangles(23, 24, 26, 0, 27, 23, 26, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 30, 31, 0),
	gsSPVertex(mario_001_switch_000_offset_001_mesh_layer_1_vtx_1 + 32, 29, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 3, 2, 0, 4, 2, 5, 0),
	gsSP2Triangles(6, 3, 4, 0, 7, 3, 6, 0),
	gsSP2Triangles(6, 8, 7, 0, 8, 6, 4, 0),
	gsSP2Triangles(8, 4, 9, 0, 7, 10, 3, 0),
	gsSP2Triangles(10, 7, 11, 0, 11, 0, 10, 0),
	gsSP2Triangles(11, 12, 0, 0, 10, 0, 3, 0),
	gsSP2Triangles(13, 14, 15, 0, 16, 14, 13, 0),
	gsSP2Triangles(17, 18, 19, 0, 17, 19, 20, 0),
	gsSP2Triangles(20, 21, 17, 0, 17, 21, 22, 0),
	gsSP2Triangles(23, 24, 25, 0, 23, 26, 24, 0),
	gsSP2Triangles(26, 23, 27, 0, 23, 28, 27, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_displaylist_mesh_layer_1_vtx_0[106] = {
	{{{62, 284, 0},0, {534, 926},{0xED, 0x7E, 0x0, 0xFF}}},
	{{{84, 68, -56},0, {637, 926},{0xED, 0x5F, 0xAE, 0xFF}}},
	{{{62, 74, 0},0, {637, 875},{0x8D, 0x36, 0x0, 0xFF}}},
	{{{62, 74, 0},0, {637, 926},{0x8D, 0x36, 0x0, 0xFF}}},
	{{{84, 68, 56},0, {637, 875},{0xED, 0x5F, 0x52, 0xFF}}},
	{{{78, 90, 103},0, {534, 926},{0xE7, 0x5B, 0x55, 0xFF}}},
	{{{-43, 55, 56},0, {637, 875},{0xA4, 0x3C, 0x41, 0xFF}}},
	{{{3, 28, 76},0, {637, 926},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{-18, -27, 0},0, {534, 926},{0xBC, 0x9C, 0x27, 0xFF}}},
	{{{3, 28, 76},0, {637, 875},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{-43, 55, 56},0, {637, 926},{0xA4, 0x3C, 0x41, 0xFF}}},
	{{{-44, 55, 0},0, {637, 926},{0x91, 0x39, 0x1A, 0xFF}}},
	{{{68, 44, 113},0, {637, 926},{0xF5, 0xC, 0x7E, 0xFF}}},
	{{{-43, 55, -56},0, {534, 926},{0x90, 0x30, 0xDC, 0xFF}}},
	{{{-18, -27, 0},0, {637, 875},{0xBC, 0x9C, 0x27, 0xFF}}},
	{{{3, 28, -76},0, {637, 875},{0xB0, 0xF9, 0x9D, 0xFF}}},
	{{{-18, -27, 0},0, {637, 926},{0xBC, 0x9C, 0x27, 0xFF}}},
	{{{3, 28, -76},0, {534, 926},{0xB0, 0xF9, 0x9D, 0xFF}}},
	{{{-43, 55, -56},0, {637, 875},{0x90, 0x30, 0xDC, 0xFF}}},
	{{{78, 90, -103},0, {637, 926},{0xE5, 0x5B, 0xAB, 0xFF}}},
	{{{78, 90, -103},0, {637, 875},{0xE5, 0x5B, 0xAB, 0xFF}}},
	{{{68, 44, -113},0, {637, 926},{0xF2, 0x10, 0x83, 0xFF}}},
	{{{125, 78, 0},0, {549, 436},{0x7A, 0x25, 0x0, 0xFF}}},
	{{{84, 68, -56},0, {511, 798},{0xED, 0x5F, 0xAE, 0xFF}}},
	{{{62, 284, 0},0, {549, 798},{0xED, 0x7E, 0x0, 0xFF}}},
	{{{84, 68, 56},0, {587, 798},{0xED, 0x5F, 0x52, 0xFF}}},
	{{{-6, -27, 65},0, {240, 496},{0xD8, 0xB6, 0x5F, 0xFF}}},
	{{{3, 28, 76},0, {240, 368},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{-18, -27, 0},0, {496, 368},{0xBC, 0x9C, 0x27, 0xFF}}},
	{{{83, -104, 145},0, {496, 496},{0x57, 0x25, 0x55, 0xFF}}},
	{{{-6, -27, 0},0, {240, 496},{0xD1, 0xA6, 0xB4, 0xFF}}},
	{{{3, 28, -76},0, {240, 368},{0xB0, 0xF9, 0x9D, 0xFF}}},
	{{{206, 72, 89},0, {535, 436},{0xD1, 0x57, 0x50, 0xFF}}},
	{{{111, 73, 89},0, {534, 650},{0x18, 0x62, 0x4E, 0xFF}}},
	{{{109, 3, 102},0, {628, 654},{0xF5, 0x5, 0x7E, 0xFF}}},
	{{{68, 44, 113},0, {572, 749},{0xF5, 0xC, 0x7E, 0xFF}}},
	{{{78, 90, 103},0, {529, 725},{0xE7, 0x5B, 0x55, 0xFF}}},
	{{{206, 80, 0},0, {1264, 112},{0xC7, 0x72, 0x0, 0xFF}}},
	{{{206, 72, 89},0, {1264, -16},{0xD1, 0x57, 0x50, 0xFF}}},
	{{{242, 95, 86},0, {1264, -16},{0x2A, 0x6F, 0x2D, 0xFF}}},
	{{{242, 121, 0},0, {1264, 112},{0xFF, 0x7A, 0x23, 0xFF}}},
	{{{242, 95, -86},0, {1264, -16},{0x30, 0x64, 0xC2, 0xFF}}},
	{{{206, 72, -89},0, {1264, -16},{0xEA, 0x4E, 0x9E, 0xFF}}},
	{{{206, 80, 0},0, {1008, 448},{0xC7, 0x72, 0x0, 0xFF}}},
	{{{111, 73, 89},0, {672, 652},{0x18, 0x62, 0x4E, 0xFF}}},
	{{{206, 72, 89},0, {670, 444},{0xD1, 0x57, 0x50, 0xFF}}},
	{{{111, 85, 0},0, {1008, 652},{0xD, 0x7E, 0xE, 0xFF}}},
	{{{111, 73, -89},0, {1344, 652},{0x15, 0x63, 0xB4, 0xFF}}},
	{{{206, 72, -89},0, {1346, 444},{0xEA, 0x4E, 0x9E, 0xFF}}},
	{{{78, 90, 0},0, {1008, 723},{0xE8, 0x7D, 0x3, 0xFF}}},
	{{{78, 90, 103},0, {620, 723},{0xE7, 0x5B, 0x55, 0xFF}}},
	{{{-43, 55, 56},0, {799, 939},{0xA4, 0x3C, 0x41, 0xFF}}},
	{{{-44, 55, 0},0, {1008, 940},{0x91, 0x39, 0x1A, 0xFF}}},
	{{{-43, 55, -56},0, {1217, 939},{0x90, 0x30, 0xDC, 0xFF}}},
	{{{78, 90, -103},0, {1396, 723},{0xE5, 0x5B, 0xAB, 0xFF}}},
	{{{206, 72, 89},0, {1264, 1008},{0xD1, 0x57, 0x50, 0xFF}}},
	{{{255, 10, 136},0, {1264, 880},{0x29, 0x1E, 0x74, 0xFF}}},
	{{{242, 95, 86},0, {1264, 1008},{0x2A, 0x6F, 0x2D, 0xFF}}},
	{{{188, -10, 104},0, {1264, 880},{0xED, 0x31, 0x74, 0xFF}}},
	{{{109, 3, 102},0, {1136, 880},{0xF5, 0x5, 0x7E, 0xFF}}},
	{{{216, -77, 182},0, {1136, 752},{0x4D, 0x2, 0x65, 0xFF}}},
	{{{88, -72, 77},0, {1008, 752},{0x1, 0xF5, 0x7F, 0xFF}}},
	{{{68, 44, 113},0, {1008, 880},{0xF5, 0xC, 0x7E, 0xFF}}},
	{{{3, 28, 76},0, {752, 880},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{3, 28, 76},0, {752, 880},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{-6, -27, 65},0, {752, 752},{0xD8, 0xB6, 0x5F, 0xFF}}},
	{{{88, -72, 77},0, {1008, 752},{0x1, 0xF5, 0x7F, 0xFF}}},
	{{{83, -104, 145},0, {752, 624},{0x57, 0x25, 0x55, 0xFF}}},
	{{{83, -168, 0},0, {1008, 624},{0x52, 0xA6, 0xDC, 0xFF}}},
	{{{-6, -27, 0},0, {752, 752},{0xD1, 0xA6, 0xB4, 0xFF}}},
	{{{60, -72, -77},0, {1008, 752},{0xC9, 0xBF, 0xA1, 0xFF}}},
	{{{3, 28, -76},0, {752, 880},{0xB0, 0xF9, 0x9D, 0xFF}}},
	{{{68, 44, -113},0, {1008, 880},{0xF2, 0x10, 0x83, 0xFF}}},
	{{{109, 3, -102},0, {1136, 880},{0x1, 0xF6, 0x81, 0xFF}}},
	{{{88, -77, -82},0, {1136, 752},{0xFC, 0xBE, 0x93, 0xFF}}},
	{{{188, -10, -104},0, {1264, 880},{0x3, 0x0, 0x81, 0xFF}}},
	{{{206, 72, -89},0, {1264, 1008},{0xEA, 0x4E, 0x9E, 0xFF}}},
	{{{258, 10, -94},0, {1264, 880},{0x53, 0xF, 0xA1, 0xFF}}},
	{{{242, 95, -86},0, {1264, 1008},{0x30, 0x64, 0xC2, 0xFF}}},
	{{{258, -49, -84},0, {1264, 752},{0x5E, 0xCB, 0xBD, 0xFF}}},
	{{{200, -99, -92},0, {1264, 752},{0x2A, 0xB4, 0xA4, 0xFF}}},
	{{{199, -129, 0},0, {1264, 624},{0x40, 0x92, 0x7, 0xFF}}},
	{{{265, -55, 0},0, {1264, 624},{0x6E, 0xC4, 0x18, 0xFF}}},
	{{{212, -70, 128},0, {1264, 752},{0x3F, 0x92, 0xFE, 0xFF}}},
	{{{274, -49, 200},0, {1264, 752},{0x2F, 0x1A, 0x73, 0xFF}}},
	{{{255, 10, 136},0, {1264, 880},{0x29, 0x1E, 0x74, 0xFF}}},
	{{{188, -10, 104},0, {1264, 880},{0xED, 0x31, 0x74, 0xFF}}},
	{{{216, -77, 182},0, {1136, 752},{0x4D, 0x2, 0x65, 0xFF}}},
	{{{88, -109, 0},0, {1136, 624},{0x5E, 0xB1, 0x22, 0xFF}}},
	{{{265, -55, 0},0, {1520, 496},{0x6E, 0xC4, 0x18, 0xFF}}},
	{{{255, 10, 136},0, {1776, 368},{0x29, 0x1E, 0x74, 0xFF}}},
	{{{274, -49, 200},0, {1776, 496},{0x2F, 0x1A, 0x73, 0xFF}}},
	{{{285, 73, 0},0, {1520, 368},{0x6D, 0x42, 0xFE, 0xFF}}},
	{{{258, 10, -94},0, {1776, 368},{0x53, 0xF, 0xA1, 0xFF}}},
	{{{258, -49, -84},0, {1776, 496},{0x5E, 0xCB, 0xBD, 0xFF}}},
	{{{242, 95, -86},0, {1776, 240},{0x30, 0x64, 0xC2, 0xFF}}},
	{{{285, 73, 0},0, {1520, 368},{0x6D, 0x42, 0xFE, 0xFF}}},
	{{{242, 95, -86},0, {1776, 240},{0x30, 0x64, 0xC2, 0xFF}}},
	{{{242, 121, 0},0, {1520, 240},{0xFF, 0x7A, 0x23, 0xFF}}},
	{{{242, 95, 86},0, {1776, 240},{0x2A, 0x6F, 0x2D, 0xFF}}},
	{{{255, 10, 136},0, {1776, 368},{0x29, 0x1E, 0x74, 0xFF}}},
	{{{206, 72, -89},0, {535, 436},{0xEA, 0x4E, 0x9E, 0xFF}}},
	{{{109, 3, -102},0, {628, 654},{0x1, 0xF6, 0x81, 0xFF}}},
	{{{111, 73, -89},0, {534, 650},{0x15, 0x63, 0xB4, 0xFF}}},
	{{{68, 44, -113},0, {572, 749},{0xF2, 0x10, 0x83, 0xFF}}},
	{{{78, 90, -103},0, {529, 725},{0xE5, 0x5B, 0xAB, 0xFF}}},
};

Gfx mario_001_switch_000_displaylist_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_000_displaylist_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 4, 0),
	gsSP2Triangles(5, 6, 7, 0, 8, 9, 10, 0),
	gsSP2Triangles(8, 6, 11, 0, 5, 9, 12, 0),
	gsSP2Triangles(13, 14, 11, 0, 13, 15, 16, 0),
	gsSP2Triangles(17, 18, 19, 0, 17, 20, 21, 0),
	gsSP2Triangles(22, 23, 24, 0, 22, 24, 25, 0),
	gsSP2Triangles(26, 27, 28, 0, 26, 28, 29, 0),
	gsSP2Triangles(30, 29, 28, 0, 30, 28, 31, 0),
	gsSPVertex(mario_001_switch_000_displaylist_mesh_layer_1_vtx_0 + 32, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 3, 2, 0),
	gsSP2Triangles(1, 4, 3, 0, 5, 6, 7, 0),
	gsSP2Triangles(5, 7, 8, 0, 9, 5, 8, 0),
	gsSP2Triangles(9, 10, 5, 0, 11, 12, 13, 0),
	gsSP2Triangles(11, 14, 12, 0, 15, 14, 11, 0),
	gsSP2Triangles(15, 11, 16, 0, 17, 14, 15, 0),
	gsSP2Triangles(17, 12, 14, 0, 17, 18, 12, 0),
	gsSP2Triangles(17, 19, 18, 0, 17, 20, 19, 0),
	gsSP2Triangles(21, 20, 17, 0, 21, 17, 22, 0),
	gsSP2Triangles(17, 15, 22, 0, 23, 24, 25, 0),
	gsSP2Triangles(23, 26, 24, 0, 23, 27, 26, 0),
	gsSP2Triangles(26, 27, 28, 0, 27, 29, 28, 0),
	gsSP2Triangles(27, 30, 29, 0, 31, 29, 30, 0),
	gsSPVertex(mario_001_switch_000_displaylist_mesh_layer_1_vtx_0 + 64, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
	gsSP2Triangles(2, 3, 4, 0, 5, 4, 3, 0),
	gsSP2Triangles(5, 6, 4, 0, 7, 6, 5, 0),
	gsSP2Triangles(7, 8, 6, 0, 9, 6, 8, 0),
	gsSP2Triangles(9, 10, 6, 0, 11, 10, 9, 0),
	gsSP2Triangles(12, 11, 9, 0, 13, 11, 12, 0),
	gsSP2Triangles(13, 12, 14, 0, 15, 11, 13, 0),
	gsSP2Triangles(15, 16, 11, 0, 17, 16, 15, 0),
	gsSP2Triangles(17, 15, 18, 0, 19, 17, 18, 0),
	gsSP2Triangles(19, 18, 20, 0, 19, 20, 21, 0),
	gsSP2Triangles(19, 21, 22, 0, 22, 23, 19, 0),
	gsSP2Triangles(19, 23, 24, 0, 2, 24, 23, 0),
	gsSP2Triangles(2, 4, 24, 0, 4, 10, 24, 0),
	gsSP2Triangles(4, 6, 10, 0, 24, 10, 16, 0),
	gsSP2Triangles(11, 16, 10, 0, 24, 16, 17, 0),
	gsSP2Triangles(19, 24, 17, 0, 25, 26, 27, 0),
	gsSP2Triangles(25, 28, 26, 0, 25, 29, 28, 0),
	gsSP2Triangles(25, 30, 29, 0, 28, 29, 31, 0),
	gsSPVertex(mario_001_switch_000_displaylist_mesh_layer_1_vtx_0 + 96, 10, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(0, 3, 4, 0, 5, 6, 7, 0),
	gsSP2Triangles(8, 7, 6, 0, 8, 9, 7, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_002_switch_option_head__no_cap__mesh_layer_1_vtx_0[106] = {
	{{{62, 295, 0},0, {534, 926},{0xED, 0x7E, 0x0, 0xFF}}},
	{{{84, 79, -56},0, {637, 926},{0xED, 0x5F, 0xAE, 0xFF}}},
	{{{62, 85, 0},0, {637, 875},{0x8D, 0x36, 0x0, 0xFF}}},
	{{{62, 85, 0},0, {637, 926},{0x8D, 0x36, 0x0, 0xFF}}},
	{{{84, 79, 56},0, {637, 875},{0xED, 0x5F, 0x52, 0xFF}}},
	{{{78, 101, 103},0, {534, 926},{0xE7, 0x5B, 0x55, 0xFF}}},
	{{{-43, 66, 56},0, {637, 875},{0xA4, 0x3C, 0x41, 0xFF}}},
	{{{3, 40, 76},0, {637, 926},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{-18, -16, 0},0, {534, 926},{0xBC, 0x9C, 0x27, 0xFF}}},
	{{{3, 40, 76},0, {637, 875},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{-43, 66, 56},0, {637, 926},{0xA4, 0x3C, 0x41, 0xFF}}},
	{{{-44, 66, 0},0, {637, 926},{0x91, 0x39, 0x1A, 0xFF}}},
	{{{68, 56, 113},0, {637, 926},{0xF5, 0xC, 0x7E, 0xFF}}},
	{{{-43, 66, -56},0, {534, 926},{0x90, 0x30, 0xDC, 0xFF}}},
	{{{-18, -16, 0},0, {637, 875},{0xBC, 0x9C, 0x27, 0xFF}}},
	{{{3, 40, -76},0, {637, 875},{0xB0, 0xF9, 0x9D, 0xFF}}},
	{{{-18, -16, 0},0, {637, 926},{0xBC, 0x9C, 0x27, 0xFF}}},
	{{{3, 40, -76},0, {534, 926},{0xB0, 0xF9, 0x9D, 0xFF}}},
	{{{-43, 66, -56},0, {637, 875},{0x90, 0x30, 0xDC, 0xFF}}},
	{{{78, 101, -103},0, {637, 926},{0xE5, 0x5B, 0xAB, 0xFF}}},
	{{{78, 101, -103},0, {637, 875},{0xE5, 0x5B, 0xAB, 0xFF}}},
	{{{68, 56, -113},0, {637, 926},{0xF2, 0x10, 0x83, 0xFF}}},
	{{{125, 89, 0},0, {549, 436},{0x7A, 0x25, 0x0, 0xFF}}},
	{{{84, 79, -56},0, {511, 798},{0xED, 0x5F, 0xAE, 0xFF}}},
	{{{62, 295, 0},0, {549, 798},{0xED, 0x7E, 0x0, 0xFF}}},
	{{{84, 79, 56},0, {587, 798},{0xED, 0x5F, 0x52, 0xFF}}},
	{{{-6, -16, 65},0, {240, 496},{0xD8, 0xB6, 0x5F, 0xFF}}},
	{{{3, 40, 76},0, {240, 368},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{-18, -16, 0},0, {496, 368},{0xBC, 0x9C, 0x27, 0xFF}}},
	{{{83, -93, 145},0, {496, 496},{0x57, 0x25, 0x55, 0xFF}}},
	{{{-6, -16, 0},0, {240, 496},{0xD1, 0xA6, 0xB4, 0xFF}}},
	{{{3, 40, -76},0, {240, 368},{0xB0, 0xF9, 0x9D, 0xFF}}},
	{{{206, 83, 89},0, {535, 436},{0xD1, 0x57, 0x50, 0xFF}}},
	{{{111, 84, 89},0, {534, 650},{0x18, 0x62, 0x4E, 0xFF}}},
	{{{109, 14, 102},0, {628, 654},{0xF5, 0x5, 0x7E, 0xFF}}},
	{{{68, 56, 113},0, {572, 749},{0xF5, 0xC, 0x7E, 0xFF}}},
	{{{78, 101, 103},0, {529, 725},{0xE7, 0x5B, 0x55, 0xFF}}},
	{{{206, 91, 0},0, {1264, 112},{0xC7, 0x72, 0x0, 0xFF}}},
	{{{206, 83, 89},0, {1264, -16},{0xD1, 0x57, 0x50, 0xFF}}},
	{{{242, 107, 86},0, {1264, -16},{0x2A, 0x6F, 0x2D, 0xFF}}},
	{{{242, 132, 0},0, {1264, 112},{0xFF, 0x7A, 0x23, 0xFF}}},
	{{{242, 107, -86},0, {1264, -16},{0x30, 0x64, 0xC2, 0xFF}}},
	{{{206, 83, -89},0, {1264, -16},{0xEA, 0x4E, 0x9E, 0xFF}}},
	{{{206, 91, 0},0, {1008, 448},{0xC7, 0x72, 0x0, 0xFF}}},
	{{{111, 84, 89},0, {672, 652},{0x18, 0x62, 0x4E, 0xFF}}},
	{{{206, 83, 89},0, {670, 444},{0xD1, 0x57, 0x50, 0xFF}}},
	{{{111, 96, 0},0, {1008, 652},{0xD, 0x7E, 0xE, 0xFF}}},
	{{{111, 84, -89},0, {1344, 652},{0x15, 0x63, 0xB4, 0xFF}}},
	{{{206, 83, -89},0, {1346, 444},{0xEA, 0x4E, 0x9E, 0xFF}}},
	{{{78, 101, 0},0, {1008, 723},{0xE8, 0x7D, 0x3, 0xFF}}},
	{{{78, 101, 103},0, {620, 723},{0xE7, 0x5B, 0x55, 0xFF}}},
	{{{-43, 66, 56},0, {799, 939},{0xA4, 0x3C, 0x41, 0xFF}}},
	{{{-44, 66, 0},0, {1008, 940},{0x91, 0x39, 0x1A, 0xFF}}},
	{{{-43, 66, -56},0, {1217, 939},{0x90, 0x30, 0xDC, 0xFF}}},
	{{{78, 101, -103},0, {1396, 723},{0xE5, 0x5B, 0xAB, 0xFF}}},
	{{{206, 83, 89},0, {1264, 1008},{0xD1, 0x57, 0x50, 0xFF}}},
	{{{255, 21, 136},0, {1264, 880},{0x29, 0x1E, 0x74, 0xFF}}},
	{{{242, 107, 86},0, {1264, 1008},{0x2A, 0x6F, 0x2D, 0xFF}}},
	{{{188, 2, 104},0, {1264, 880},{0xED, 0x31, 0x74, 0xFF}}},
	{{{109, 14, 102},0, {1136, 880},{0xF5, 0x5, 0x7E, 0xFF}}},
	{{{216, -66, 182},0, {1136, 752},{0x4D, 0x2, 0x65, 0xFF}}},
	{{{88, -60, 77},0, {1008, 752},{0x1, 0xF5, 0x7F, 0xFF}}},
	{{{68, 56, 113},0, {1008, 880},{0xF5, 0xC, 0x7E, 0xFF}}},
	{{{3, 40, 76},0, {752, 880},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{3, 40, 76},0, {752, 880},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{-6, -16, 65},0, {752, 752},{0xD8, 0xB6, 0x5F, 0xFF}}},
	{{{88, -60, 77},0, {1008, 752},{0x1, 0xF5, 0x7F, 0xFF}}},
	{{{83, -93, 145},0, {752, 624},{0x57, 0x25, 0x55, 0xFF}}},
	{{{83, -157, 0},0, {1008, 624},{0x52, 0xA6, 0xDC, 0xFF}}},
	{{{-6, -16, 0},0, {752, 752},{0xD1, 0xA6, 0xB4, 0xFF}}},
	{{{60, -60, -77},0, {1008, 752},{0xC9, 0xBF, 0xA1, 0xFF}}},
	{{{3, 40, -76},0, {752, 880},{0xB0, 0xF9, 0x9D, 0xFF}}},
	{{{68, 56, -113},0, {1008, 880},{0xF2, 0x10, 0x83, 0xFF}}},
	{{{109, 14, -102},0, {1136, 880},{0x1, 0xF6, 0x81, 0xFF}}},
	{{{88, -66, -82},0, {1136, 752},{0xFC, 0xBE, 0x93, 0xFF}}},
	{{{188, 2, -104},0, {1264, 880},{0x3, 0x0, 0x81, 0xFF}}},
	{{{206, 83, -89},0, {1264, 1008},{0xEA, 0x4E, 0x9E, 0xFF}}},
	{{{258, 21, -94},0, {1264, 880},{0x53, 0xF, 0xA1, 0xFF}}},
	{{{242, 107, -86},0, {1264, 1008},{0x30, 0x64, 0xC2, 0xFF}}},
	{{{258, -38, -84},0, {1264, 752},{0x5E, 0xCB, 0xBD, 0xFF}}},
	{{{201, -88, -92},0, {1264, 752},{0x2A, 0xB4, 0xA4, 0xFF}}},
	{{{199, -118, 0},0, {1264, 624},{0x40, 0x92, 0x7, 0xFF}}},
	{{{266, -44, 0},0, {1264, 624},{0x6E, 0xC4, 0x18, 0xFF}}},
	{{{212, -59, 128},0, {1264, 752},{0x3F, 0x92, 0xFE, 0xFF}}},
	{{{274, -38, 200},0, {1264, 752},{0x2F, 0x1A, 0x73, 0xFF}}},
	{{{255, 21, 136},0, {1264, 880},{0x29, 0x1E, 0x74, 0xFF}}},
	{{{188, 2, 104},0, {1264, 880},{0xED, 0x31, 0x74, 0xFF}}},
	{{{216, -66, 182},0, {1136, 752},{0x4D, 0x2, 0x65, 0xFF}}},
	{{{88, -97, 0},0, {1136, 624},{0x5E, 0xB1, 0x22, 0xFF}}},
	{{{266, -44, 0},0, {1520, 496},{0x6E, 0xC4, 0x18, 0xFF}}},
	{{{255, 21, 136},0, {1776, 368},{0x29, 0x1E, 0x74, 0xFF}}},
	{{{274, -38, 200},0, {1776, 496},{0x2F, 0x1A, 0x73, 0xFF}}},
	{{{285, 84, 0},0, {1520, 368},{0x6D, 0x42, 0xFE, 0xFF}}},
	{{{258, 21, -94},0, {1776, 368},{0x53, 0xF, 0xA1, 0xFF}}},
	{{{258, -38, -84},0, {1776, 496},{0x5E, 0xCB, 0xBD, 0xFF}}},
	{{{242, 107, -86},0, {1776, 240},{0x30, 0x64, 0xC2, 0xFF}}},
	{{{285, 84, 0},0, {1520, 368},{0x6D, 0x42, 0xFE, 0xFF}}},
	{{{242, 107, -86},0, {1776, 240},{0x30, 0x64, 0xC2, 0xFF}}},
	{{{242, 132, 0},0, {1520, 240},{0xFF, 0x7A, 0x23, 0xFF}}},
	{{{242, 107, 86},0, {1776, 240},{0x2A, 0x6F, 0x2D, 0xFF}}},
	{{{255, 21, 136},0, {1776, 368},{0x29, 0x1E, 0x74, 0xFF}}},
	{{{206, 83, -89},0, {535, 436},{0xEA, 0x4E, 0x9E, 0xFF}}},
	{{{109, 14, -102},0, {628, 654},{0x1, 0xF6, 0x81, 0xFF}}},
	{{{111, 84, -89},0, {534, 650},{0x15, 0x63, 0xB4, 0xFF}}},
	{{{68, 56, -113},0, {572, 749},{0xF2, 0x10, 0x83, 0xFF}}},
	{{{78, 101, -103},0, {529, 725},{0xE5, 0x5B, 0xAB, 0xFF}}},
};

Gfx mario_001_switch_002_switch_option_head__no_cap__mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_002_switch_option_head__no_cap__mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 4, 0),
	gsSP2Triangles(5, 6, 7, 0, 8, 9, 10, 0),
	gsSP2Triangles(8, 6, 11, 0, 5, 9, 12, 0),
	gsSP2Triangles(13, 14, 11, 0, 13, 15, 16, 0),
	gsSP2Triangles(17, 18, 19, 0, 17, 20, 21, 0),
	gsSP2Triangles(22, 23, 24, 0, 22, 24, 25, 0),
	gsSP2Triangles(26, 27, 28, 0, 26, 28, 29, 0),
	gsSP2Triangles(30, 29, 28, 0, 30, 28, 31, 0),
	gsSPVertex(mario_001_switch_002_switch_option_head__no_cap__mesh_layer_1_vtx_0 + 32, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 3, 2, 0),
	gsSP2Triangles(1, 4, 3, 0, 5, 6, 7, 0),
	gsSP2Triangles(5, 7, 8, 0, 9, 5, 8, 0),
	gsSP2Triangles(9, 10, 5, 0, 11, 12, 13, 0),
	gsSP2Triangles(11, 14, 12, 0, 15, 14, 11, 0),
	gsSP2Triangles(15, 11, 16, 0, 17, 14, 15, 0),
	gsSP2Triangles(17, 12, 14, 0, 17, 18, 12, 0),
	gsSP2Triangles(17, 19, 18, 0, 17, 20, 19, 0),
	gsSP2Triangles(21, 20, 17, 0, 21, 17, 22, 0),
	gsSP2Triangles(17, 15, 22, 0, 23, 24, 25, 0),
	gsSP2Triangles(23, 26, 24, 0, 23, 27, 26, 0),
	gsSP2Triangles(26, 27, 28, 0, 27, 29, 28, 0),
	gsSP2Triangles(27, 30, 29, 0, 31, 29, 30, 0),
	gsSPVertex(mario_001_switch_002_switch_option_head__no_cap__mesh_layer_1_vtx_0 + 64, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
	gsSP2Triangles(2, 3, 4, 0, 5, 4, 3, 0),
	gsSP2Triangles(5, 6, 4, 0, 7, 6, 5, 0),
	gsSP2Triangles(7, 8, 6, 0, 9, 6, 8, 0),
	gsSP2Triangles(9, 10, 6, 0, 11, 10, 9, 0),
	gsSP2Triangles(12, 11, 9, 0, 13, 11, 12, 0),
	gsSP2Triangles(13, 12, 14, 0, 15, 11, 13, 0),
	gsSP2Triangles(15, 16, 11, 0, 17, 16, 15, 0),
	gsSP2Triangles(17, 15, 18, 0, 19, 17, 18, 0),
	gsSP2Triangles(19, 18, 20, 0, 19, 20, 21, 0),
	gsSP2Triangles(19, 21, 22, 0, 22, 23, 19, 0),
	gsSP2Triangles(19, 23, 24, 0, 2, 24, 23, 0),
	gsSP2Triangles(2, 4, 24, 0, 4, 10, 24, 0),
	gsSP2Triangles(4, 6, 10, 0, 24, 10, 16, 0),
	gsSP2Triangles(11, 16, 10, 0, 24, 16, 17, 0),
	gsSP2Triangles(19, 24, 17, 0, 25, 26, 27, 0),
	gsSP2Triangles(25, 28, 26, 0, 25, 29, 28, 0),
	gsSP2Triangles(25, 30, 29, 0, 28, 29, 31, 0),
	gsSPVertex(mario_001_switch_002_switch_option_head__no_cap__mesh_layer_1_vtx_0 + 96, 10, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(0, 3, 4, 0, 5, 6, 7, 0),
	gsSP2Triangles(8, 7, 6, 0, 8, 9, 7, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_displaylist_001_mesh_layer_4_vtx_0[4] = {
	{{{172, -31, 2},0, {-16, 2030},{0x5, 0x1E, 0x7B, 0xFF}}},
	{{{347, 32, -21},0, {1006, 2030},{0x6, 0x1E, 0x7B, 0xFF}}},
	{{{211, 374, -98},0, {1006, -34},{0x5, 0x1E, 0x7B, 0xFF}}},
	{{{38, 311, -75},0, {-16, -34},{0x4, 0x1E, 0x7B, 0xFF}}},
};

Gfx mario_001_switch_000_displaylist_001_mesh_layer_4_tri_0[] = {
	gsSPVertex(mario_001_switch_000_displaylist_001_mesh_layer_4_vtx_0 + 0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_displaylist_001_mesh_layer_4_vtx_1[4] = {
	{{{-136, 247, -53},0, {-16, -34},{0x4, 0x1E, 0x7B, 0xFF}}},
	{{{172, -31, 2},0, {1006, 2030},{0x5, 0x1E, 0x7B, 0xFF}}},
	{{{38, 311, -75},0, {1006, -34},{0x4, 0x1E, 0x7B, 0xFF}}},
	{{{-1, -95, 25},0, {-16, 2030},{0x4, 0x1E, 0x7B, 0xFF}}},
};

Gfx mario_001_switch_000_displaylist_001_mesh_layer_4_tri_1[] = {
	gsSPVertex(mario_001_switch_000_displaylist_001_mesh_layer_4_vtx_1 + 0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_displaylist_002_mesh_layer_4_vtx_0[4] = {
	{{{173, -31, -1},0, {-16, 2030},{0xFB, 0xE2, 0x7B, 0xFF}}},
	{{{348, 32, 23},0, {1006, 2030},{0xFA, 0xE2, 0x7B, 0xFF}}},
	{{{212, 374, 99},0, {1006, -34},{0xFB, 0xE2, 0x7B, 0xFF}}},
	{{{39, 311, 77},0, {-16, -34},{0xFC, 0xE2, 0x7B, 0xFF}}},
};

Gfx mario_001_switch_000_displaylist_002_mesh_layer_4_tri_0[] = {
	gsSPVertex(mario_001_switch_000_displaylist_002_mesh_layer_4_vtx_0 + 0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_displaylist_002_mesh_layer_4_vtx_1[4] = {
	{{{-135, 247, 54},0, {-16, -34},{0xFC, 0xE2, 0x7B, 0xFF}}},
	{{{0, -95, -23},0, {-16, 2030},{0xFC, 0xE2, 0x7B, 0xFF}}},
	{{{173, -31, -1},0, {1006, 2030},{0xFB, 0xE2, 0x7B, 0xFF}}},
	{{{39, 311, 77},0, {1006, -34},{0xFC, 0xE2, 0x7B, 0xFF}}},
};

Gfx mario_001_switch_000_displaylist_002_mesh_layer_4_tri_1[] = {
	gsSPVertex(mario_001_switch_000_displaylist_002_mesh_layer_4_vtx_1 + 0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_003_skinned_mesh_layer_1_vtx_0[12] = {
	{{{71, 29, 101},0, {271, 93},{0x3F, 0x36, 0x60, 0xFF}}},
	{{{-32, 20, 94},0, {495, 197},{0xF6, 0x2E, 0x76, 0xFF}}},
	{{{-32, 20, 94},0, {1272, 151},{0xF6, 0x2E, 0x76, 0xFF}}},
	{{{71, 29, 101},0, {1544, 1008},{0x3F, 0x36, 0x60, 0xFF}}},
	{{{72, -58, 91},0, {66, 195},{0x3F, 0xBA, 0x56, 0xFF}}},
	{{{-32, 20, 94},0, {1556, 518},{0xF6, 0x2E, 0x76, 0xFF}}},
	{{{-33, -47, 87},0, {1352, 518},{0xF8, 0xB9, 0x69, 0xFF}}},
	{{{72, -58, 91},0, {191, 62},{0x3F, 0xBA, 0x56, 0xFF}}},
	{{{-33, -47, 87},0, {30, 195},{0xF8, 0xB9, 0x69, 0xFF}}},
	{{{71, 29, 101},0, {1128, 485},{0x3F, 0x36, 0x60, 0xFF}}},
	{{{71, 29, 101},0, {1172, 946},{0x3F, 0x36, 0x60, 0xFF}}},
	{{{72, -58, 91},0, {1434, 946},{0x3F, 0xBA, 0x56, 0xFF}}},
};

Gfx mario_001_switch_000_offset_003_skinned_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_000_offset_003_skinned_mesh_layer_1_vtx_0 + 0, 12, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_003_mesh_layer_1_vtx_0[12] = {
	{{{5, -29, -68},0, {495, 60},{0xD6, 0xA7, 0xAF, 0xFF}}},
	{{{1, 36, -68},0, {1272, 3},{0xC7, 0x50, 0xB0, 0xFF}}},
	{{{5, -29, -68},0, {1148, 79},{0xD6, 0xA7, 0xAF, 0xFF}}},
	{{{1, 36, -68},0, {1360, 610},{0xC7, 0x50, 0xB0, 0xFF}}},
	{{{1, 36, -68},0, {-16, 62},{0xC7, 0x50, 0xB0, 0xFF}}},
	{{{4, 46, 32},0, {1398, 1008},{0xB5, 0x49, 0x48, 0xFF}}},
	{{{5, -29, -68},0, {1777, 988},{0xD6, 0xA7, 0xAF, 0xFF}}},
	{{{10, -37, 31},0, {1499, 933},{0xB8, 0xB2, 0x47, 0xFF}}},
	{{{4, 46, 32},0, {-16, 270},{0xB5, 0x49, 0x48, 0xFF}}},
	{{{1, 36, -68},0, {271, 217},{0xC7, 0x50, 0xB0, 0xFF}}},
	{{{10, -37, 31},0, {1128, 430},{0xB8, 0xB2, 0x47, 0xFF}}},
	{{{4, 46, 32},0, {876, 435},{0xB5, 0x49, 0x48, 0xFF}}},
};

Gfx mario_001_switch_000_offset_003_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_000_offset_003_mesh_layer_1_vtx_0 + 0, 12, 12),
	gsSP2Triangles(0, 1, 12, 0, 2, 13, 14, 0),
	gsSP2Triangles(5, 6, 15, 0, 7, 16, 8, 0),
	gsSP2Triangles(10, 17, 11, 0, 3, 18, 19, 0),
	gsSP2Triangles(4, 20, 21, 0, 9, 22, 23, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_003_mesh_layer_1_vtx_1[19] = {
	{{{10, -37, 31},0, {1499, 933},{0xB8, 0xB2, 0x47, 0xFF}}},
	{{{5, -29, -68},0, {1777, 988},{0xD6, 0xA7, 0xAF, 0xFF}}},
	{{{54, -23, -50},0, {1777, 907},{0x2A, 0xAD, 0xA9, 0xFF}}},
	{{{58, -28, 27},0, {1558, 865},{0x17, 0xA5, 0x55, 0xFF}}},
	{{{1, 36, -68},0, {1753, 70},{0xC7, 0x50, 0xB0, 0xFF}}},
	{{{54, -23, -50},0, {1939, 149},{0x2A, 0xAD, 0xA9, 0xFF}}},
	{{{5, -29, -68},0, {1951, 70},{0xD6, 0xA7, 0xAF, 0xFF}}},
	{{{67, 29, -45},0, {1783, 173},{0x27, 0x54, 0xA9, 0xFF}}},
	{{{70, 4, -44},0, {1860, 176},{0x2A, 0x1, 0x88, 0xFF}}},
	{{{4, 46, 32},0, {-16, 270},{0xB5, 0x49, 0x48, 0xFF}}},
	{{{67, 29, -45},0, {271, 322},{0x27, 0x54, 0xA9, 0xFF}}},
	{{{1, 36, -68},0, {271, 217},{0xC7, 0x50, 0xB0, 0xFF}}},
	{{{67, 35, 27},0, {65, 359},{0x17, 0x5C, 0x55, 0xFF}}},
	{{{58, -28, 27},0, {1106, 357},{0x17, 0xA5, 0x55, 0xFF}}},
	{{{4, 46, 32},0, {876, 435},{0xB5, 0x49, 0x48, 0xFF}}},
	{{{10, -37, 31},0, {1128, 430},{0xB8, 0xB2, 0x47, 0xFF}}},
	{{{67, 35, 27},0, {915, 340},{0xB, 0x0, 0x7F, 0xFF}}},
	{{{72, 5, 26},0, {1006, 335},{0xA, 0x0, 0x7F, 0xFF}}},
	{{{67, 35, 27},0, {914, 340},{0x17, 0x5C, 0x55, 0xFF}}},
};

Gfx mario_001_switch_000_offset_003_mesh_layer_1_tri_1[] = {
	gsSPVertex(mario_001_switch_000_offset_003_mesh_layer_1_vtx_1 + 0, 19, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 7, 5, 0),
	gsSP2Triangles(7, 8, 5, 0, 9, 10, 11, 0),
	gsSP2Triangles(9, 12, 10, 0, 13, 14, 15, 0),
	gsSP2Triangles(14, 13, 16, 0, 13, 17, 16, 0),
	gsSP1Triangle(14, 16, 18, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_004_skinned_mesh_layer_1_vtx_0[11] = {
	{{{70, 4, -44},0, {1860, 176},{0x2A, 0x1, 0x88, 0xFF}}},
	{{{54, -23, -50},0, {1939, 149},{0x2A, 0xAD, 0xA9, 0xFF}}},
	{{{58, -28, 27},0, {1558, 865},{0x17, 0xA5, 0x55, 0xFF}}},
	{{{54, -23, -50},0, {1777, 907},{0x2A, 0xAD, 0xA9, 0xFF}}},
	{{{67, 35, 27},0, {65, 359},{0x17, 0x5C, 0x55, 0xFF}}},
	{{{67, 35, 27},0, {915, 340},{0xB, 0x0, 0x7F, 0xFF}}},
	{{{72, 5, 26},0, {1006, 335},{0xA, 0x0, 0x7F, 0xFF}}},
	{{{67, 35, 27},0, {914, 340},{0x17, 0x5C, 0x55, 0xFF}}},
	{{{67, 29, -45},0, {1783, 173},{0x27, 0x54, 0xA9, 0xFF}}},
	{{{67, 29, -45},0, {271, 322},{0x27, 0x54, 0xA9, 0xFF}}},
	{{{58, -28, 27},0, {1106, 357},{0x17, 0xA5, 0x55, 0xFF}}},
};

Gfx mario_001_switch_000_offset_004_skinned_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_000_offset_004_skinned_mesh_layer_1_vtx_0 + 0, 11, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_004_mesh_layer_1_vtx_0[8] = {
	{{{17, -18, -37},0, {1931, 206},{0x29, 0xAD, 0xA9, 0xFF}}},
	{{{-1, 28, -43},0, {1786, 181},{0x27, 0x54, 0xA9, 0xFF}}},
	{{{17, -18, -37},0, {1777, 849},{0x29, 0xAD, 0xA9, 0xFF}}},
	{{{19, -22, 25},0, {1601, 817},{0x17, 0xA6, 0x57, 0xFF}}},
	{{{-1, 34, 26},0, {917, 332},{0x16, 0x5B, 0x55, 0xFF}}},
	{{{19, -22, 25},0, {1090, 305},{0x17, 0xA6, 0x57, 0xFF}}},
	{{{-1, 28, -43},0, {271, 331},{0x27, 0x54, 0xA9, 0xFF}}},
	{{{-1, 34, 26},0, {72, 366},{0x16, 0x5B, 0x55, 0xFF}}},
};

Gfx mario_001_switch_000_offset_004_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_000_offset_004_mesh_layer_1_vtx_0 + 0, 8, 11),
	gsSP2Triangles(0, 11, 1, 0, 12, 11, 0, 0),
	gsSP2Triangles(8, 12, 0, 0, 2, 3, 13, 0),
	gsSP2Triangles(2, 13, 14, 0, 5, 15, 7, 0),
	gsSP2Triangles(5, 6, 15, 0, 16, 15, 6, 0),
	gsSP2Triangles(10, 16, 6, 0, 4, 17, 9, 0),
	gsSP1Triangle(4, 18, 17, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_004_mesh_layer_1_vtx_1[20] = {
	{{{88, 19, -12},0, {1827, 323},{0x58, 0x47, 0xC6, 0xFF}}},
	{{{17, -18, -37},0, {1931, 206},{0x29, 0xAD, 0xA9, 0xFF}}},
	{{{-1, 28, -43},0, {1786, 181},{0x27, 0x54, 0xA9, 0xFF}}},
	{{{90, -9, -11},0, {1914, 324},{0x5D, 0xBF, 0xC7, 0xFF}}},
	{{{19, -22, 25},0, {1601, 817},{0x17, 0xA6, 0x57, 0xFF}}},
	{{{17, -18, -37},0, {1777, 849},{0x29, 0xAD, 0xA9, 0xFF}}},
	{{{90, -9, -11},0, {1777, 731},{0x5D, 0xBF, 0xC7, 0xFF}}},
	{{{89, -9, 19},0, {1689, 717},{0x54, 0xC2, 0x49, 0xFF}}},
	{{{-1, 34, 26},0, {72, 366},{0x16, 0x5B, 0x55, 0xFF}}},
	{{{88, 19, -12},0, {271, 476},{0x58, 0x47, 0xC6, 0xFF}}},
	{{{-1, 28, -43},0, {271, 331},{0x27, 0x54, 0xA9, 0xFF}}},
	{{{86, 19, 19},0, {182, 489},{0x4D, 0x46, 0x49, 0xFF}}},
	{{{86, 19, 19},0, {970, 200},{0x4D, 0x46, 0x49, 0xFF}}},
	{{{-1, 34, 26},0, {917, 332},{0x16, 0x5B, 0x55, 0xFF}}},
	{{{19, -22, 25},0, {1090, 305},{0x17, 0xA6, 0x57, 0xFF}}},
	{{{89, -9, 19},0, {1057, 198},{0x54, 0xC2, 0x49, 0xFF}}},
	{{{90, -9, -11},0, {1683, 717},{0x5D, 0xBF, 0xC7, 0xFF}}},
	{{{86, 19, 19},0, {1770, 671},{0x4D, 0x46, 0x49, 0xFF}}},
	{{{89, -9, 19},0, {1683, 671},{0x54, 0xC2, 0x49, 0xFF}}},
	{{{88, 19, -12},0, {1770, 717},{0x58, 0x47, 0xC6, 0xFF}}},
};

Gfx mario_001_switch_000_offset_004_mesh_layer_1_tri_1[] = {
	gsSPVertex(mario_001_switch_000_offset_004_mesh_layer_1_vtx_1 + 0, 20, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 0, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 11, 9, 0),
	gsSP2Triangles(12, 13, 14, 0, 15, 12, 14, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 19, 17, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_displaylist_003_mesh_layer_1_vtx_0[32] = {
	{{{1, 27, 21},0, {1264, 240},{0xAD, 0x41, 0x47, 0xFF}}},
	{{{4, 27, -14},0, {752, 240},{0xA9, 0x43, 0xC0, 0xFF}}},
	{{{4, -18, -14},0, {752, -16},{0xA9, 0xBD, 0xC0, 0xFF}}},
	{{{1, -18, 21},0, {1264, -16},{0xAD, 0xBF, 0x47, 0xFF}}},
	{{{25, 32, 21},0, {1008, 1008},{0x5, 0x5D, 0x57, 0xFF}}},
	{{{1, 27, 21},0, {752, 1008},{0xAD, 0x41, 0x47, 0xFF}}},
	{{{1, -18, 21},0, {752, 752},{0xAD, 0xBF, 0x47, 0xFF}}},
	{{{25, -23, 21},0, {1008, 752},{0x5, 0xA3, 0x57, 0xFF}}},
	{{{49, -18, 17},0, {1264, 752},{0x54, 0xBE, 0x45, 0xFF}}},
	{{{49, 27, 17},0, {1264, 1008},{0x54, 0x42, 0x45, 0xFF}}},
	{{{25, 32, 21},0, {752, 368},{0x5, 0x5D, 0x57, 0xFF}}},
	{{{4, 27, -14},0, {240, 240},{0xA9, 0x43, 0xC0, 0xFF}}},
	{{{1, 27, 21},0, {752, 240},{0xAD, 0x41, 0x47, 0xFF}}},
	{{{27, 32, -22},0, {240, 368},{0xFA, 0x59, 0xA5, 0xFF}}},
	{{{49, 27, 17},0, {752, 496},{0x54, 0x42, 0x45, 0xFF}}},
	{{{50, 27, -18},0, {240, 496},{0x57, 0x41, 0xBE, 0xFF}}},
	{{{4, 27, -14},0, {1264, 752},{0xA9, 0x43, 0xC0, 0xFF}}},
	{{{27, -23, -22},0, {1008, 496},{0xFA, 0xA7, 0xA5, 0xFF}}},
	{{{4, -18, -14},0, {1264, 496},{0xA9, 0xBD, 0xC0, 0xFF}}},
	{{{27, 32, -22},0, {1008, 752},{0xFA, 0x59, 0xA5, 0xFF}}},
	{{{50, -18, -18},0, {752, 496},{0x57, 0xBF, 0xBE, 0xFF}}},
	{{{50, 27, -18},0, {752, 752},{0x57, 0x41, 0xBE, 0xFF}}},
	{{{4, -18, -14},0, {752, 496},{0xA9, 0xBD, 0xC0, 0xFF}}},
	{{{25, -23, 21},0, {1264, 368},{0x5, 0xA3, 0x57, 0xFF}}},
	{{{1, -18, 21},0, {1264, 496},{0xAD, 0xBF, 0x47, 0xFF}}},
	{{{27, -23, -22},0, {752, 368},{0xFA, 0xA7, 0xA5, 0xFF}}},
	{{{49, -18, 17},0, {1264, 240},{0x54, 0xBE, 0x45, 0xFF}}},
	{{{50, -18, -18},0, {752, 240},{0x57, 0xBF, 0xBE, 0xFF}}},
	{{{49, -18, 17},0, {1776, 496},{0x54, 0xBE, 0x45, 0xFF}}},
	{{{50, 27, -18},0, {1264, 240},{0x57, 0x41, 0xBE, 0xFF}}},
	{{{49, 27, 17},0, {1776, 240},{0x54, 0x42, 0x45, 0xFF}}},
	{{{50, -18, -18},0, {1264, 496},{0x57, 0xBF, 0xBE, 0xFF}}},
};

Gfx mario_001_switch_000_displaylist_003_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_000_displaylist_003_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(4, 7, 8, 0, 4, 8, 9, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 13, 11, 0),
	gsSP2Triangles(14, 13, 10, 0, 14, 15, 13, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 19, 17, 0),
	gsSP2Triangles(19, 20, 17, 0, 19, 21, 20, 0),
	gsSP2Triangles(22, 23, 24, 0, 22, 25, 23, 0),
	gsSP2Triangles(25, 26, 23, 0, 25, 27, 26, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 31, 29, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_002_switch_option_right_hand_open_mesh_layer_1_vtx_0[40] = {
	{{{27, 40, 15},0, {1008, 1008},{0xEB, 0x58, 0x5A, 0xFF}}},
	{{{5, 28, 17},0, {752, 1008},{0xA5, 0x25, 0x51, 0xFF}}},
	{{{19, -16, 16},0, {752, 752},{0xDB, 0xAD, 0x59, 0xFF}}},
	{{{81, 52, 6},0, {752, 496},{0x3B, 0x5A, 0x43, 0xFF}}},
	{{{81, 52, -12},0, {240, 496},{0x35, 0x5D, 0xBB, 0xFF}}},
	{{{26, 40, -18},0, {240, 368},{0xE3, 0x5B, 0xAC, 0xFF}}},
	{{{27, 40, 15},0, {752, 368},{0xEB, 0x58, 0x5A, 0xFF}}},
	{{{5, 29, -18},0, {240, 240},{0xA0, 0x29, 0xB7, 0xFF}}},
	{{{5, 28, 17},0, {752, 240},{0xA5, 0x25, 0x51, 0xFF}}},
	{{{95, 8, 4},0, {1264, 752},{0x65, 0xD3, 0x3F, 0xFF}}},
	{{{81, 52, 6},0, {1264, 1008},{0x3B, 0x5A, 0x43, 0xFF}}},
	{{{43, -13, 13},0, {1008, 752},{0x35, 0xD0, 0x69, 0xFF}}},
	{{{95, 8, 4},0, {1776, 496},{0x65, 0xD3, 0x3F, 0xFF}}},
	{{{81, 52, -12},0, {1264, 240},{0x35, 0x5D, 0xBB, 0xFF}}},
	{{{81, 52, 6},0, {1776, 240},{0x3B, 0x5A, 0x43, 0xFF}}},
	{{{94, 9, -13},0, {1264, 496},{0x5F, 0xD6, 0xB6, 0xFF}}},
	{{{26, 40, -18},0, {1008, 752},{0xE3, 0x5B, 0xAC, 0xFF}}},
	{{{81, 52, -12},0, {752, 752},{0x35, 0x5D, 0xBB, 0xFF}}},
	{{{94, 9, -13},0, {752, 496},{0x5F, 0xD6, 0xB6, 0xFF}}},
	{{{42, -12, -19},0, {1008, 496},{0x2B, 0xD3, 0x91, 0xFF}}},
	{{{42, -12, -19},0, {752, 368},{0x2B, 0xD3, 0x91, 0xFF}}},
	{{{94, 9, -13},0, {752, 240},{0x5F, 0xD6, 0xB6, 0xFF}}},
	{{{95, 8, 4},0, {1264, 240},{0x65, 0xD3, 0x3F, 0xFF}}},
	{{{43, -13, 13},0, {1264, 368},{0x35, 0xD0, 0x69, 0xFF}}},
	{{{19, -16, 16},0, {753, 752},{0xDB, 0xAD, 0x59, 0xFF}}},
	{{{43, -13, 13},0, {1008, 819},{0x35, 0xD0, 0x69, 0xFF}}},
	{{{47, -26, 4},0, {1008, 752},{0x53, 0xA6, 0x22, 0xFF}}},
	{{{42, -12, -19},0, {1081, 569},{0x2B, 0xD3, 0x91, 0xFF}}},
	{{{47, -26, 4},0, {1264, 368},{0x53, 0xA6, 0x22, 0xFF}}},
	{{{46, -26, -11},0, {1008, 496},{0x4F, 0xA7, 0xD3, 0xFF}}},
	{{{18, -14, -19},0, {1264, 496},{0xBA, 0xBC, 0xAE, 0xFF}}},
	{{{5, 29, -18},0, {1264, 752},{0xA0, 0x29, 0xB7, 0xFF}}},
	{{{5, 28, 17},0, {1264, 240},{0xA5, 0x25, 0x51, 0xFF}}},
	{{{5, 29, -18},0, {752, 240},{0xA0, 0x29, 0xB7, 0xFF}}},
	{{{18, -14, -19},0, {752, -16},{0xBA, 0xBC, 0xAE, 0xFF}}},
	{{{19, -16, 16},0, {1264, -16},{0xDB, 0xAD, 0x59, 0xFF}}},
	{{{18, -14, -19},0, {752, 496},{0xBA, 0xBC, 0xAE, 0xFF}}},
	{{{47, -26, 4},0, {1264, 368},{0x53, 0xA6, 0x22, 0xFF}}},
	{{{19, -16, 16},0, {1264, 496},{0xDB, 0xAD, 0x59, 0xFF}}},
	{{{46, -26, -11},0, {752, 368},{0x4F, 0xA7, 0xD3, 0xFF}}},
};

Gfx mario_001_switch_002_switch_option_right_hand_open_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_002_switch_option_right_hand_open_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(3, 5, 6, 0, 6, 5, 7, 0),
	gsSP2Triangles(6, 7, 8, 0, 0, 9, 10, 0),
	gsSP2Triangles(0, 11, 9, 0, 12, 13, 14, 0),
	gsSP2Triangles(12, 15, 13, 0, 16, 17, 18, 0),
	gsSP2Triangles(16, 18, 19, 0, 20, 21, 22, 0),
	gsSP2Triangles(20, 22, 23, 0, 0, 24, 25, 0),
	gsSP2Triangles(25, 24, 26, 0, 27, 25, 28, 0),
	gsSP2Triangles(27, 28, 29, 0, 30, 27, 29, 0),
	gsSP2Triangles(31, 27, 30, 0, 31, 16, 27, 0),
	gsSPVertex(mario_001_switch_002_switch_option_right_hand_open_mesh_layer_1_vtx_0 + 32, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 7, 5, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_006_skinned_mesh_layer_1_vtx_0[12] = {
	{{{72, -58, -91},0, {351, 489},{0x3F, 0xBB, 0xAA, 0xFF}}},
	{{{71, 29, -101},0, {1809, 324},{0x3F, 0x34, 0x9F, 0xFF}}},
	{{{71, 29, -101},0, {1244, 642},{0x3F, 0x34, 0x9F, 0xFF}}},
	{{{72, -58, -91},0, {1499, 672},{0x3F, 0xBB, 0xAA, 0xFF}}},
	{{{71, 29, -101},0, {876, 163},{0x3F, 0x34, 0x9F, 0xFF}}},
	{{{-32, 20, -94},0, {1099, 59},{0xF6, 0x2E, 0x8A, 0xFF}}},
	{{{-32, 20, -94},0, {1477, 3},{0xF6, 0x2E, 0x8A, 0xFF}}},
	{{{71, 29, -101},0, {640, 196},{0x3F, 0x34, 0x9F, 0xFF}}},
	{{{-32, 20, -94},0, {1352, 243},{0xF6, 0x2E, 0x8A, 0xFF}}},
	{{{-33, -47, -87},0, {1148, 243},{0xF8, 0xB9, 0x97, 0xFF}}},
	{{{72, -58, -91},0, {595, 60},{0x3F, 0xBB, 0xAA, 0xFF}}},
	{{{-33, -47, -87},0, {746, 196},{0xF8, 0xB9, 0x97, 0xFF}}},
};

Gfx mario_001_switch_000_offset_006_skinned_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_000_offset_006_skinned_mesh_layer_1_vtx_0 + 0, 12, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_006_mesh_layer_1_vtx_0[12] = {
	{{{4, 46, -31},0, {1493, 610},{0xB5, 0x49, 0xB8, 0xFF}}},
	{{{5, -29, 69},0, {1099, 198},{0xD7, 0xA7, 0x51, 0xFF}}},
	{{{5, -29, 69},0, {1352, 76},{0xD7, 0xA7, 0x51, 0xFF}}},
	{{{1, 36, 69},0, {1477, 152},{0xC7, 0x51, 0x50, 0xFF}}},
	{{{1, 36, 69},0, {1156, 151},{0xC7, 0x51, 0x50, 0xFF}}},
	{{{1, 36, 69},0, {798, 60},{0xC7, 0x51, 0x50, 0xFF}}},
	{{{1, 36, 69},0, {558, 469},{0xC7, 0x51, 0x50, 0xFF}}},
	{{{4, 46, -31},0, {271, 416},{0xB5, 0x49, 0xB8, 0xFF}}},
	{{{4, 46, -31},0, {1556, 372},{0xB5, 0x49, 0xB8, 0xFF}}},
	{{{10, -37, -30},0, {1809, 377},{0xB9, 0xB2, 0xB9, 0xFF}}},
	{{{10, -37, -30},0, {595, 269},{0xB9, 0xB2, 0xB9, 0xFF}}},
	{{{5, -29, 69},0, {876, 213},{0xD7, 0xA7, 0x51, 0xFF}}},
};

Gfx mario_001_switch_000_offset_006_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_000_offset_006_mesh_layer_1_vtx_0 + 0, 12, 12),
	gsSP2Triangles(2, 3, 12, 0, 4, 13, 5, 0),
	gsSP2Triangles(6, 14, 15, 0, 8, 16, 9, 0),
	gsSP2Triangles(10, 11, 17, 0, 0, 18, 19, 0),
	gsSP2Triangles(1, 20, 21, 0, 7, 22, 23, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_006_mesh_layer_1_vtx_1[19] = {
	{{{58, -28, -26},0, {1787, 450},{0x17, 0xA5, 0xAB, 0xFF}}},
	{{{10, -37, -30},0, {1809, 377},{0xB9, 0xB2, 0xB9, 0xFF}}},
	{{{4, 46, -31},0, {1556, 372},{0xB5, 0x49, 0xB8, 0xFF}}},
	{{{67, 35, -26},0, {1596, 468},{0xB, 0x0, 0x81, 0xFF}}},
	{{{67, 35, -26},0, {1595, 468},{0x17, 0x5C, 0xAB, 0xFF}}},
	{{{72, 5, -25},0, {1687, 473},{0xA, 0x0, 0x81, 0xFF}}},
	{{{4, 46, -31},0, {271, 416},{0xB5, 0x49, 0xB8, 0xFF}}},
	{{{1, 36, 69},0, {558, 469},{0xC7, 0x51, 0x50, 0xFF}}},
	{{{67, 29, 46},0, {558, 363},{0x27, 0x54, 0x57, 0xFF}}},
	{{{67, 35, -26},0, {352, 327},{0x17, 0x5C, 0xAB, 0xFF}}},
	{{{1, 36, 69},0, {1753, 70},{0xC7, 0x51, 0x50, 0xFF}}},
	{{{5, -29, 69},0, {1556, 70},{0xD7, 0xA7, 0x51, 0xFF}}},
	{{{54, -23, 51},0, {1568, 149},{0x2A, 0xAD, 0x57, 0xFF}}},
	{{{67, 29, 46},0, {1723, 173},{0x27, 0x54, 0x57, 0xFF}}},
	{{{70, 4, 45},0, {1647, 176},{0x2A, 0x1, 0x78, 0xFF}}},
	{{{10, -37, -30},0, {595, 269},{0xB9, 0xB2, 0xB9, 0xFF}}},
	{{{54, -23, 51},0, {876, 294},{0x2A, 0xAD, 0x57, 0xFF}}},
	{{{5, -29, 69},0, {876, 213},{0xD7, 0xA7, 0x51, 0xFF}}},
	{{{58, -28, -26},0, {655, 337},{0x17, 0xA5, 0xAB, 0xFF}}},
};

Gfx mario_001_switch_000_offset_006_mesh_layer_1_tri_1[] = {
	gsSPVertex(mario_001_switch_000_offset_006_mesh_layer_1_vtx_1 + 0, 19, 0),
	gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
	gsSP2Triangles(2, 4, 3, 0, 0, 3, 5, 0),
	gsSP2Triangles(6, 7, 8, 0, 6, 8, 9, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 12, 13, 0),
	gsSP2Triangles(13, 12, 14, 0, 15, 16, 17, 0),
	gsSP1Triangle(15, 18, 16, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_007_skinned_mesh_layer_1_vtx_0[11] = {
	{{{58, -28, -26},0, {1787, 450},{0x17, 0xA5, 0xAB, 0xFF}}},
	{{{72, 5, -25},0, {1687, 473},{0xA, 0x0, 0x81, 0xFF}}},
	{{{58, -28, -26},0, {655, 337},{0x17, 0xA5, 0xAB, 0xFF}}},
	{{{70, 4, 45},0, {1647, 176},{0x2A, 0x1, 0x78, 0xFF}}},
	{{{54, -23, 51},0, {1568, 149},{0x2A, 0xAD, 0x57, 0xFF}}},
	{{{54, -23, 51},0, {876, 294},{0x2A, 0xAD, 0x57, 0xFF}}},
	{{{67, 35, -26},0, {352, 327},{0x17, 0x5C, 0xAB, 0xFF}}},
	{{{67, 35, -26},0, {1596, 468},{0xB, 0x0, 0x81, 0xFF}}},
	{{{67, 35, -26},0, {1595, 468},{0x17, 0x5C, 0xAB, 0xFF}}},
	{{{67, 29, 46},0, {1723, 173},{0x27, 0x54, 0x57, 0xFF}}},
	{{{67, 29, 46},0, {558, 363},{0x27, 0x54, 0x57, 0xFF}}},
};

Gfx mario_001_switch_000_offset_007_skinned_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_000_offset_007_skinned_mesh_layer_1_vtx_0 + 0, 11, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_007_mesh_layer_1_vtx_0[8] = {
	{{{19, -22, -24},0, {1771, 502},{0x17, 0xA6, 0xA9, 0xFF}}},
	{{{-1, 34, -25},0, {1598, 476},{0x16, 0x5B, 0xAB, 0xFF}}},
	{{{17, -18, 38},0, {1576, 206},{0x29, 0xAD, 0x57, 0xFF}}},
	{{{-1, 28, 44},0, {1721, 181},{0x27, 0x54, 0x57, 0xFF}}},
	{{{17, -18, 38},0, {876, 352},{0x29, 0xAD, 0x57, 0xFF}}},
	{{{19, -22, -24},0, {699, 385},{0x17, 0xA6, 0xA9, 0xFF}}},
	{{{-1, 28, 44},0, {558, 354},{0x27, 0x54, 0x57, 0xFF}}},
	{{{-1, 34, -25},0, {359, 319},{0x16, 0x5B, 0xAB, 0xFF}}},
};

Gfx mario_001_switch_000_offset_007_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_000_offset_007_mesh_layer_1_vtx_0 + 0, 8, 11),
	gsSP2Triangles(0, 1, 11, 0, 11, 1, 12, 0),
	gsSP2Triangles(7, 12, 1, 0, 7, 8, 12, 0),
	gsSP2Triangles(3, 4, 13, 0, 14, 3, 13, 0),
	gsSP2Triangles(9, 3, 14, 0, 2, 15, 5, 0),
	gsSP2Triangles(2, 16, 15, 0, 6, 10, 17, 0),
	gsSP1Triangle(6, 17, 18, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_007_mesh_layer_1_vtx_1[20] = {
	{{{19, -22, -24},0, {699, 385},{0x17, 0xA6, 0xA9, 0xFF}}},
	{{{90, -9, 12},0, {876, 471},{0x5D, 0xBF, 0x39, 0xFF}}},
	{{{17, -18, 38},0, {876, 352},{0x29, 0xAD, 0x57, 0xFF}}},
	{{{89, -9, -18},0, {788, 485},{0x54, 0xC2, 0xB7, 0xFF}}},
	{{{17, -18, 38},0, {1576, 206},{0x29, 0xAD, 0x57, 0xFF}}},
	{{{90, -9, 12},0, {1593, 324},{0x5D, 0xBF, 0x39, 0xFF}}},
	{{{88, 19, 13},0, {1680, 323},{0x58, 0x47, 0x3A, 0xFF}}},
	{{{-1, 28, 44},0, {1721, 181},{0x27, 0x54, 0x57, 0xFF}}},
	{{{90, -9, 12},0, {1683, 625},{0x5D, 0xBF, 0x39, 0xFF}}},
	{{{86, 19, -18},0, {1770, 670},{0x4D, 0x46, 0xB7, 0xFF}}},
	{{{88, 19, 13},0, {1770, 625},{0x58, 0x47, 0x3A, 0xFF}}},
	{{{89, -9, -18},0, {1683, 671},{0x54, 0xC2, 0xB7, 0xFF}}},
	{{{89, -9, -18},0, {1738, 610},{0x54, 0xC2, 0xB7, 0xFF}}},
	{{{19, -22, -24},0, {1771, 502},{0x17, 0xA6, 0xA9, 0xFF}}},
	{{{86, 19, -18},0, {1651, 607},{0x4D, 0x46, 0xB7, 0xFF}}},
	{{{-1, 34, -25},0, {1598, 476},{0x16, 0x5B, 0xAB, 0xFF}}},
	{{{-1, 34, -25},0, {359, 319},{0x16, 0x5B, 0xAB, 0xFF}}},
	{{{88, 19, 13},0, {558, 209},{0x58, 0x47, 0x3A, 0xFF}}},
	{{{86, 19, -18},0, {470, 197},{0x4D, 0x46, 0xB7, 0xFF}}},
	{{{-1, 28, 44},0, {558, 354},{0x27, 0x54, 0x57, 0xFF}}},
};

Gfx mario_001_switch_000_offset_007_mesh_layer_1_tri_1[] = {
	gsSPVertex(mario_001_switch_000_offset_007_mesh_layer_1_vtx_1 + 0, 20, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 6, 7, 4, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 11, 9, 0),
	gsSP2Triangles(12, 13, 14, 0, 14, 13, 15, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 19, 17, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_displaylist_004_mesh_layer_1_vtx_0[32] = {
	{{{-1, 27, -20},0, {1264, 240},{0xAD, 0x41, 0xB9, 0xFF}}},
	{{{2, -18, 15},0, {752, -16},{0xA9, 0xBD, 0x40, 0xFF}}},
	{{{2, 27, 15},0, {752, 240},{0xA9, 0x43, 0x40, 0xFF}}},
	{{{-1, -18, -20},0, {1264, -16},{0xAD, 0xBF, 0xB9, 0xFF}}},
	{{{23, 32, -20},0, {1008, 1008},{0x5, 0x5D, 0xA9, 0xFF}}},
	{{{-1, -18, -20},0, {752, 752},{0xAD, 0xBF, 0xB9, 0xFF}}},
	{{{-1, 27, -20},0, {752, 1008},{0xAD, 0x41, 0xB9, 0xFF}}},
	{{{23, -23, -20},0, {1008, 752},{0x5, 0xA3, 0xA9, 0xFF}}},
	{{{46, -18, -16},0, {1264, 752},{0x54, 0xBE, 0xBB, 0xFF}}},
	{{{46, 27, -16},0, {1264, 1008},{0x54, 0x42, 0xBB, 0xFF}}},
	{{{23, 32, -20},0, {752, 368},{0x5, 0x5D, 0xA9, 0xFF}}},
	{{{-1, 27, -20},0, {752, 240},{0xAD, 0x41, 0xB9, 0xFF}}},
	{{{2, 27, 15},0, {240, 240},{0xA9, 0x43, 0x40, 0xFF}}},
	{{{25, 32, 23},0, {240, 368},{0xFA, 0x59, 0x5B, 0xFF}}},
	{{{46, 27, -16},0, {752, 496},{0x54, 0x42, 0xBB, 0xFF}}},
	{{{48, 27, 19},0, {240, 496},{0x57, 0x41, 0x42, 0xFF}}},
	{{{2, 27, 15},0, {1264, 752},{0xA9, 0x43, 0x40, 0xFF}}},
	{{{2, -18, 15},0, {1264, 496},{0xA9, 0xBD, 0x40, 0xFF}}},
	{{{25, -23, 23},0, {1008, 496},{0xFA, 0xA7, 0x5B, 0xFF}}},
	{{{25, 32, 23},0, {1008, 752},{0xFA, 0x59, 0x5B, 0xFF}}},
	{{{48, -18, 19},0, {752, 496},{0x57, 0xBF, 0x42, 0xFF}}},
	{{{48, 27, 19},0, {752, 752},{0x57, 0x41, 0x42, 0xFF}}},
	{{{2, -18, 15},0, {752, 496},{0xA9, 0xBD, 0x40, 0xFF}}},
	{{{-1, -18, -20},0, {1264, 496},{0xAD, 0xBF, 0xB9, 0xFF}}},
	{{{23, -23, -20},0, {1264, 368},{0x5, 0xA3, 0xA9, 0xFF}}},
	{{{25, -23, 23},0, {752, 368},{0xFA, 0xA7, 0x5B, 0xFF}}},
	{{{46, -18, -16},0, {1264, 240},{0x54, 0xBE, 0xBB, 0xFF}}},
	{{{48, -18, 19},0, {752, 240},{0x57, 0xBF, 0x42, 0xFF}}},
	{{{46, -18, -16},0, {1776, 496},{0x54, 0xBE, 0xBB, 0xFF}}},
	{{{46, 27, -16},0, {1776, 240},{0x54, 0x42, 0xBB, 0xFF}}},
	{{{48, 27, 19},0, {1264, 240},{0x57, 0x41, 0x42, 0xFF}}},
	{{{48, -18, 19},0, {1264, 496},{0x57, 0xBF, 0x42, 0xFF}}},
};

Gfx mario_001_switch_000_displaylist_004_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_000_displaylist_004_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 7, 5, 0),
	gsSP2Triangles(4, 8, 7, 0, 4, 9, 8, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 12, 13, 0),
	gsSP2Triangles(14, 10, 13, 0, 14, 13, 15, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
	gsSP2Triangles(19, 18, 20, 0, 19, 20, 21, 0),
	gsSP2Triangles(22, 23, 24, 0, 22, 24, 25, 0),
	gsSP2Triangles(25, 24, 26, 0, 25, 26, 27, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 30, 31, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_002_switch_option_left_hand_open_mesh_layer_1_vtx_0[40] = {
	{{{36, 40, -20},0, {1008, 1008},{0xEB, 0x58, 0xA6, 0xFF}}},
	{{{27, -16, -20},0, {752, 752},{0xC0, 0xB8, 0xAE, 0xFF}}},
	{{{14, 28, -22},0, {752, 1008},{0xA5, 0x25, 0xAF, 0xFF}}},
	{{{90, 52, -10},0, {752, 496},{0x3B, 0x5A, 0xBD, 0xFF}}},
	{{{34, 40, 13},0, {240, 368},{0xE3, 0x5B, 0x54, 0xFF}}},
	{{{89, 52, 7},0, {240, 496},{0x35, 0x5D, 0x45, 0xFF}}},
	{{{36, 40, -20},0, {752, 368},{0xEB, 0x58, 0xA6, 0xFF}}},
	{{{13, 29, 13},0, {240, 240},{0xA0, 0x29, 0x49, 0xFF}}},
	{{{14, 28, -22},0, {752, 240},{0xA5, 0x25, 0xAF, 0xFF}}},
	{{{90, 52, -10},0, {1264, 1008},{0x3B, 0x5A, 0xBD, 0xFF}}},
	{{{103, 8, -9},0, {1264, 752},{0x65, 0xD3, 0xC1, 0xFF}}},
	{{{52, -13, -18},0, {1008, 752},{0x35, 0xD0, 0x97, 0xFF}}},
	{{{103, 8, -9},0, {1776, 496},{0x65, 0xD3, 0xC1, 0xFF}}},
	{{{90, 52, -10},0, {1776, 240},{0x3B, 0x5A, 0xBD, 0xFF}}},
	{{{89, 52, 7},0, {1264, 240},{0x35, 0x5D, 0x45, 0xFF}}},
	{{{102, 9, 9},0, {1264, 496},{0x5F, 0xD6, 0x4A, 0xFF}}},
	{{{34, 40, 13},0, {1008, 752},{0xE3, 0x5B, 0x54, 0xFF}}},
	{{{102, 9, 9},0, {752, 496},{0x5F, 0xD6, 0x4A, 0xFF}}},
	{{{89, 52, 7},0, {752, 752},{0x35, 0x5D, 0x45, 0xFF}}},
	{{{50, -12, 14},0, {1008, 496},{0x2B, 0xD3, 0x6F, 0xFF}}},
	{{{50, -12, 14},0, {752, 368},{0x2B, 0xD3, 0x6F, 0xFF}}},
	{{{103, 8, -9},0, {1264, 240},{0x65, 0xD3, 0xC1, 0xFF}}},
	{{{102, 9, 9},0, {752, 240},{0x5F, 0xD6, 0x4A, 0xFF}}},
	{{{52, -13, -18},0, {1264, 368},{0x35, 0xD0, 0x97, 0xFF}}},
	{{{52, -13, -18},0, {1008, 819},{0x35, 0xD0, 0x97, 0xFF}}},
	{{{27, -16, -20},0, {753, 752},{0xC0, 0xB8, 0xAE, 0xFF}}},
	{{{55, -26, -9},0, {1008, 752},{0x53, 0xA6, 0xDE, 0xFF}}},
	{{{50, -12, 14},0, {1081, 569},{0x2B, 0xD3, 0x6F, 0xFF}}},
	{{{55, -26, -9},0, {1264, 368},{0x53, 0xA6, 0xDE, 0xFF}}},
	{{{55, -26, 6},0, {1008, 496},{0x4F, 0xA7, 0x2D, 0xFF}}},
	{{{27, -14, 15},0, {1264, 496},{0xBA, 0xBC, 0x52, 0xFF}}},
	{{{13, 29, 13},0, {1264, 752},{0xA0, 0x29, 0x49, 0xFF}}},
	{{{14, 28, -22},0, {1264, 240},{0xA5, 0x25, 0xAF, 0xFF}}},
	{{{27, -14, 15},0, {752, -16},{0xBA, 0xBC, 0x52, 0xFF}}},
	{{{13, 29, 13},0, {752, 240},{0xA0, 0x29, 0x49, 0xFF}}},
	{{{27, -16, -20},0, {1264, -16},{0xC0, 0xB8, 0xAE, 0xFF}}},
	{{{27, -14, 15},0, {752, 496},{0xBA, 0xBC, 0x52, 0xFF}}},
	{{{27, -16, -20},0, {1264, 496},{0xC0, 0xB8, 0xAE, 0xFF}}},
	{{{55, -26, -9},0, {1264, 368},{0x53, 0xA6, 0xDE, 0xFF}}},
	{{{55, -26, 6},0, {752, 368},{0x4F, 0xA7, 0x2D, 0xFF}}},
};

Gfx mario_001_switch_002_switch_option_left_hand_open_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_002_switch_option_left_hand_open_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(3, 6, 4, 0, 6, 7, 4, 0),
	gsSP2Triangles(6, 8, 7, 0, 0, 9, 10, 0),
	gsSP2Triangles(0, 10, 11, 0, 12, 13, 14, 0),
	gsSP2Triangles(12, 14, 15, 0, 16, 17, 18, 0),
	gsSP2Triangles(16, 19, 17, 0, 20, 21, 22, 0),
	gsSP2Triangles(20, 23, 21, 0, 0, 24, 25, 0),
	gsSP2Triangles(24, 26, 25, 0, 27, 28, 24, 0),
	gsSP2Triangles(27, 29, 28, 0, 30, 29, 27, 0),
	gsSP2Triangles(31, 30, 27, 0, 31, 27, 16, 0),
	gsSPVertex(mario_001_switch_002_switch_option_left_hand_open_mesh_layer_1_vtx_0 + 32, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_004_switch_option_left_hand_peace_mesh_layer_1_vtx_0[35] = {
	{{{110, -48, -29},0, {1349, 240},{0x1D, 0xA6, 0xAB, 0xFF}}},
	{{{114, -57, 9},0, {1179, -16},{0x28, 0x8C, 0x20, 0xFF}}},
	{{{73, -55, -11},0, {1008, 240},{0xCA, 0x92, 0xDF, 0xFF}}},
	{{{95, -5, -52},0, {1349, 496},{0x6, 0xE8, 0x83, 0xFF}}},
	{{{42, -16, -27},0, {1008, 496},{0x9D, 0xD0, 0xC1, 0xFF}}},
	{{{70, -45, 23},0, {667, 240},{0xC6, 0xAB, 0x4A, 0xFF}}},
	{{{114, -57, 9},0, {837, -16},{0x28, 0x8C, 0x20, 0xFF}}},
	{{{38, -2, 21},0, {667, 496},{0x97, 0xEB, 0x44, 0xFF}}},
	{{{105, -28, 40},0, {325, 240},{0x11, 0xD4, 0x76, 0xFF}}},
	{{{114, -57, 9},0, {496, -16},{0x28, 0x8C, 0x20, 0xFF}}},
	{{{88, 23, 45},0, {325, 496},{0xFA, 0x18, 0x7D, 0xFF}}},
	{{{142, -20, 22},0, {-16, 240},{0x65, 0xE2, 0x47, 0xFF}}},
	{{{114, -57, 9},0, {155, -16},{0x28, 0x8C, 0x20, 0xFF}}},
	{{{140, 33, 20},0, {-16, 496},{0x63, 0x30, 0x3F, 0xFF}}},
	{{{72, 65, 21},0, {325, 752},{0xE3, 0x5A, 0x55, 0xFF}}},
	{{{110, 72, 4},0, {-16, 752},{0x36, 0x6E, 0x21, 0xFF}}},
	{{{68, 74, -17},0, {155, 1008},{0xD8, 0x74, 0xE0, 0xFF}}},
	{{{38, 48, 5},0, {667, 752},{0x93, 0x36, 0x25, 0xFF}}},
	{{{40, 38, -29},0, {1008, 752},{0x9B, 0x1E, 0xB9, 0xFF}}},
	{{{68, 74, -17},0, {837, 1008},{0xD8, 0x74, 0xE0, 0xFF}}},
	{{{77, 45, -47},0, {1349, 752},{0xEF, 0x2C, 0x8A, 0xFF}}},
	{{{68, 74, -17},0, {1179, 1008},{0xD8, 0x74, 0xE0, 0xFF}}},
	{{{112, 63, -31},0, {1691, 752},{0x3A, 0x55, 0xB6, 0xFF}}},
	{{{68, 74, -17},0, {1520, 1008},{0xD8, 0x74, 0xE0, 0xFF}}},
	{{{144, 19, -29},0, {1691, 496},{0x69, 0x15, 0xBC, 0xFF}}},
	{{{110, 72, 4},0, {2032, 752},{0x36, 0x6E, 0x21, 0xFF}}},
	{{{68, 74, -17},0, {1861, 1008},{0xD8, 0x74, 0xE0, 0xFF}}},
	{{{140, 33, 20},0, {2032, 496},{0x63, 0x30, 0x3F, 0xFF}}},
	{{{145, -30, -12},0, {1691, 240},{0x6D, 0xCA, 0xDB, 0xFF}}},
	{{{142, -20, 22},0, {2032, 240},{0x65, 0xE2, 0x47, 0xFF}}},
	{{{114, -57, 9},0, {1861, -16},{0x28, 0x8C, 0x20, 0xFF}}},
	{{{114, -57, 9},0, {1520, -16},{0x28, 0x8C, 0x20, 0xFF}}},
	{{{68, 74, -17},0, {496, 1008},{0xD8, 0x74, 0xE0, 0xFF}}},
	{{{38, 48, 5},0, {667, 752},{0x93, 0x36, 0x25, 0xFF}}},
	{{{72, 65, 21},0, {325, 752},{0xE3, 0x5A, 0x55, 0xFF}}},
};

Gfx mario_001_switch_004_switch_option_left_hand_peace_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_004_switch_option_left_hand_peace_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
	gsSP2Triangles(3, 2, 4, 0, 4, 2, 5, 0),
	gsSP2Triangles(2, 6, 5, 0, 4, 5, 7, 0),
	gsSP2Triangles(7, 5, 8, 0, 5, 9, 8, 0),
	gsSP2Triangles(7, 8, 10, 0, 10, 8, 11, 0),
	gsSP2Triangles(8, 12, 11, 0, 10, 11, 13, 0),
	gsSP2Triangles(14, 10, 13, 0, 14, 13, 15, 0),
	gsSP2Triangles(16, 14, 15, 0, 17, 10, 14, 0),
	gsSP2Triangles(17, 7, 10, 0, 18, 7, 17, 0),
	gsSP2Triangles(19, 18, 17, 0, 18, 4, 7, 0),
	gsSP2Triangles(20, 4, 18, 0, 21, 20, 18, 0),
	gsSP2Triangles(20, 3, 4, 0, 22, 3, 20, 0),
	gsSP2Triangles(23, 22, 20, 0, 22, 24, 3, 0),
	gsSP2Triangles(25, 24, 22, 0, 26, 25, 22, 0),
	gsSP2Triangles(25, 27, 24, 0, 27, 28, 24, 0),
	gsSP2Triangles(27, 29, 28, 0, 29, 30, 28, 0),
	gsSP2Triangles(24, 28, 0, 0, 28, 31, 0, 0),
	gsSP1Triangle(24, 0, 3, 0),
	gsSPVertex(mario_001_switch_004_switch_option_left_hand_peace_mesh_layer_1_vtx_0 + 32, 3, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_004_switch_option_left_hand_peace_mesh_layer_1_vtx_1[32] = {
	{{{-10, 32, 33},0, {1264, 240},{0xA1, 0x2E, 0x47, 0xFF}}},
	{{{-6, 33, -2},0, {752, 240},{0xA0, 0x34, 0xBE, 0xFF}}},
	{{{4, -11, -2},0, {752, -16},{0xB7, 0xAB, 0xC4, 0xFF}}},
	{{{7, -12, 33},0, {1264, -16},{0xCB, 0xAA, 0x4D, 0xFF}}},
	{{{20, 42, 33},0, {1008, 1008},{0x18, 0x59, 0x58, 0xFF}}},
	{{{-10, 32, 33},0, {752, 1008},{0xA1, 0x2E, 0x47, 0xFF}}},
	{{{7, -12, 33},0, {752, 752},{0xCB, 0xAA, 0x4D, 0xFF}}},
	{{{25, -11, 33},0, {1008, 752},{0x2F, 0xB1, 0x58, 0xFF}}},
	{{{48, -2, 9},0, {1264, 752},{0x6F, 0xCE, 0x26, 0xFF}}},
	{{{38, 43, 9},0, {1264, 1008},{0x50, 0x5D, 0x21, 0xFF}}},
	{{{20, 42, 33},0, {752, 368},{0x18, 0x59, 0x58, 0xFF}}},
	{{{-6, 33, -2},0, {240, 240},{0xA0, 0x34, 0xBE, 0xFF}}},
	{{{-10, 32, 33},0, {752, 240},{0xA1, 0x2E, 0x47, 0xFF}}},
	{{{21, 43, -10},0, {240, 368},{0xF0, 0x57, 0xA5, 0xFF}}},
	{{{38, 43, 9},0, {752, 496},{0x50, 0x5D, 0x21, 0xFF}}},
	{{{39, 43, -6},0, {240, 496},{0x49, 0x54, 0xC2, 0xFF}}},
	{{{-6, 33, -2},0, {1264, 752},{0xA0, 0x34, 0xBE, 0xFF}}},
	{{{27, -11, -10},0, {1008, 496},{0xC, 0xA7, 0xA6, 0xFF}}},
	{{{4, -11, -2},0, {1264, 496},{0xB7, 0xAB, 0xC4, 0xFF}}},
	{{{21, 43, -10},0, {1008, 752},{0xF0, 0x57, 0xA5, 0xFF}}},
	{{{49, -1, -6},0, {752, 496},{0x64, 0xD3, 0xC0, 0xFF}}},
	{{{39, 43, -6},0, {752, 752},{0x49, 0x54, 0xC2, 0xFF}}},
	{{{4, -11, -2},0, {752, 496},{0xB7, 0xAB, 0xC4, 0xFF}}},
	{{{25, -11, 33},0, {1264, 368},{0x2F, 0xB1, 0x58, 0xFF}}},
	{{{7, -12, 33},0, {1264, 496},{0xCB, 0xAA, 0x4D, 0xFF}}},
	{{{27, -11, -10},0, {752, 368},{0xC, 0xA7, 0xA6, 0xFF}}},
	{{{48, -2, 9},0, {1264, 240},{0x6F, 0xCE, 0x26, 0xFF}}},
	{{{49, -1, -6},0, {752, 240},{0x64, 0xD3, 0xC0, 0xFF}}},
	{{{48, -2, 9},0, {1776, 496},{0x6F, 0xCE, 0x26, 0xFF}}},
	{{{39, 43, -6},0, {1264, 240},{0x49, 0x54, 0xC2, 0xFF}}},
	{{{38, 43, 9},0, {1776, 240},{0x50, 0x5D, 0x21, 0xFF}}},
	{{{49, -1, -6},0, {1264, 496},{0x64, 0xD3, 0xC0, 0xFF}}},
};

Gfx mario_001_switch_004_switch_option_left_hand_peace_mesh_layer_1_tri_1[] = {
	gsSPVertex(mario_001_switch_004_switch_option_left_hand_peace_mesh_layer_1_vtx_1 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(4, 7, 8, 0, 4, 8, 9, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 13, 11, 0),
	gsSP2Triangles(14, 13, 10, 0, 14, 15, 13, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 19, 17, 0),
	gsSP2Triangles(19, 20, 17, 0, 19, 21, 20, 0),
	gsSP2Triangles(22, 23, 24, 0, 22, 25, 23, 0),
	gsSP2Triangles(25, 26, 23, 0, 25, 27, 26, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 31, 29, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_004_switch_option_left_hand_peace_mesh_layer_4_vtx_0[8] = {
	{{{85, 188, -47},0, {0, 1024},{0xFA, 0x19, 0x7C, 0xFF}}},
	{{{141, 28, -11},0, {1536, 1024},{0xFA, 0x19, 0x7C, 0xFF}}},
	{{{235, 60, -13},0, {1536, 0},{0xFA, 0x19, 0x7C, 0xFF}}},
	{{{179, 221, -48},0, {0, 0},{0xFA, 0x19, 0x7C, 0xFF}}},
	{{{139, 33, 4},0, {1536, 1024},{0x6, 0xE7, 0x84, 0xFF}}},
	{{{233, 66, 3},0, {1536, 0},{0x6, 0xE7, 0x84, 0xFF}}},
	{{{289, -95, 38},0, {0, 0},{0x6, 0xE7, 0x84, 0xFF}}},
	{{{195, -127, 40},0, {0, 1024},{0x6, 0xE7, 0x84, 0xFF}}},
};

Gfx mario_001_switch_004_switch_option_left_hand_peace_mesh_layer_4_tri_0[] = {
	gsSPVertex(mario_001_switch_004_switch_option_left_hand_peace_mesh_layer_4_vtx_0 + 0, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_005_switch_option_left_hand_cap_mesh_layer_4_vtx_0[8] = {
	{{{94, 5, 30},0, {543, 372},{0x7B, 0xF1, 0xE2, 0xFF}}},
	{{{79, -79, 9},0, {880, 372},{0x51, 0xA8, 0xD4, 0xFF}}},
	{{{60, -53, -81},0, {880, 12},{0x51, 0xA8, 0xD4, 0xFF}}},
	{{{75, 31, -60},0, {543, 12},{0x7B, 0xF1, 0xE2, 0xFF}}},
	{{{94, 5, 30},0, {481, 372},{0x7B, 0xF1, 0xE2, 0xFF}}},
	{{{75, 31, -60},0, {481, 12},{0x7B, 0xF1, 0xE2, 0xFF}}},
	{{{91, 115, -39},0, {144, 12},{0x6D, 0x41, 0xFA, 0xFF}}},
	{{{110, 89, 51},0, {144, 372},{0x6D, 0x41, 0xFA, 0xFF}}},
};

Gfx mario_001_switch_005_switch_option_left_hand_cap_mesh_layer_4_tri_0[] = {
	gsSPVertex(mario_001_switch_005_switch_option_left_hand_cap_mesh_layer_4_vtx_0 + 0, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_005_switch_option_left_hand_cap_mesh_layer_1_vtx_0[32] = {
	{{{4, 33, 20},0, {1264, 240},{0xA1, 0x2E, 0x47, 0xFF}}},
	{{{8, 33, -15},0, {752, 240},{0x9D, 0x2F, 0xC0, 0xFF}}},
	{{{17, -11, -15},0, {752, -16},{0xB9, 0xAC, 0xC0, 0xFF}}},
	{{{14, -12, 20},0, {1264, -16},{0xBC, 0xAF, 0x47, 0xFF}}},
	{{{27, 42, 20},0, {1008, 1008},{0xF2, 0x5C, 0x57, 0xFF}}},
	{{{4, 33, 20},0, {752, 1008},{0xA1, 0x2E, 0x47, 0xFF}}},
	{{{14, -12, 20},0, {752, 752},{0xBC, 0xAF, 0x47, 0xFF}}},
	{{{39, -11, 20},0, {1008, 752},{0x19, 0xA6, 0x57, 0xFF}}},
	{{{60, -2, 16},0, {1264, 752},{0x60, 0xD2, 0x45, 0xFF}}},
	{{{51, 43, 16},0, {1264, 1008},{0x44, 0x52, 0x45, 0xFF}}},
	{{{27, 42, 20},0, {752, 368},{0xF2, 0x5C, 0x57, 0xFF}}},
	{{{8, 33, -15},0, {240, 240},{0x9D, 0x2F, 0xC0, 0xFF}}},
	{{{4, 33, 20},0, {752, 240},{0xA1, 0x2E, 0x47, 0xFF}}},
	{{{29, 43, -22},0, {240, 368},{0xE7, 0x56, 0xA5, 0xFF}}},
	{{{51, 43, 16},0, {752, 496},{0x44, 0x52, 0x45, 0xFF}}},
	{{{52, 43, -19},0, {240, 496},{0x47, 0x52, 0xBE, 0xFF}}},
	{{{8, 33, -15},0, {1264, 752},{0x9D, 0x2F, 0xC0, 0xFF}}},
	{{{40, -11, -22},0, {1008, 496},{0xC, 0xA8, 0xA6, 0xFF}}},
	{{{17, -11, -15},0, {1264, 496},{0xB9, 0xAC, 0xC0, 0xFF}}},
	{{{29, 43, -22},0, {1008, 752},{0xE7, 0x56, 0xA5, 0xFF}}},
	{{{62, -1, -19},0, {752, 496},{0x63, 0xD3, 0xBE, 0xFF}}},
	{{{52, 43, -19},0, {752, 752},{0x47, 0x52, 0xBE, 0xFF}}},
	{{{17, -11, -15},0, {752, 496},{0xB9, 0xAC, 0xC0, 0xFF}}},
	{{{39, -11, 20},0, {1264, 368},{0x19, 0xA6, 0x57, 0xFF}}},
	{{{14, -12, 20},0, {1264, 496},{0xBC, 0xAF, 0x47, 0xFF}}},
	{{{40, -11, -22},0, {752, 368},{0xC, 0xA8, 0xA6, 0xFF}}},
	{{{60, -2, 16},0, {1264, 240},{0x60, 0xD2, 0x45, 0xFF}}},
	{{{62, -1, -19},0, {752, 240},{0x63, 0xD3, 0xBE, 0xFF}}},
	{{{60, -2, 16},0, {1776, 496},{0x60, 0xD2, 0x45, 0xFF}}},
	{{{52, 43, -19},0, {1264, 240},{0x47, 0x52, 0xBE, 0xFF}}},
	{{{51, 43, 16},0, {1776, 240},{0x44, 0x52, 0x45, 0xFF}}},
	{{{62, -1, -19},0, {1264, 496},{0x63, 0xD3, 0xBE, 0xFF}}},
};

Gfx mario_001_switch_005_switch_option_left_hand_cap_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_005_switch_option_left_hand_cap_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(4, 7, 8, 0, 4, 8, 9, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 13, 11, 0),
	gsSP2Triangles(14, 13, 10, 0, 14, 15, 13, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 19, 17, 0),
	gsSP2Triangles(19, 20, 17, 0, 19, 21, 20, 0),
	gsSP2Triangles(22, 23, 24, 0, 22, 25, 23, 0),
	gsSP2Triangles(25, 26, 23, 0, 25, 27, 26, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 31, 29, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_006_switch_option_left_hand_wing_cap_mesh_layer_4_vtx_0[8] = {
	{{{94, 5, 30},0, {543, 372},{0x7B, 0xF1, 0xE2, 0xFF}}},
	{{{79, -79, 9},0, {880, 372},{0x51, 0xA8, 0xD4, 0xFF}}},
	{{{60, -53, -81},0, {880, 12},{0x51, 0xA8, 0xD4, 0xFF}}},
	{{{75, 31, -60},0, {543, 12},{0x7B, 0xF1, 0xE2, 0xFF}}},
	{{{94, 5, 30},0, {481, 372},{0x7B, 0xF1, 0xE2, 0xFF}}},
	{{{75, 31, -60},0, {481, 12},{0x7B, 0xF1, 0xE2, 0xFF}}},
	{{{91, 115, -39},0, {144, 12},{0x6D, 0x41, 0xFA, 0xFF}}},
	{{{110, 89, 51},0, {144, 372},{0x6D, 0x41, 0xFA, 0xFF}}},
};

Gfx mario_001_switch_006_switch_option_left_hand_wing_cap_mesh_layer_4_tri_0[] = {
	gsSPVertex(mario_001_switch_006_switch_option_left_hand_wing_cap_mesh_layer_4_vtx_0 + 0, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_006_switch_option_left_hand_wing_cap_mesh_layer_1_vtx_0[32] = {
	{{{4, 33, 20},0, {1264, 240},{0xA1, 0x2E, 0x47, 0xFF}}},
	{{{8, 33, -15},0, {752, 240},{0x9D, 0x2F, 0xC0, 0xFF}}},
	{{{17, -11, -15},0, {752, -16},{0xB9, 0xAC, 0xC0, 0xFF}}},
	{{{14, -12, 20},0, {1264, -16},{0xBC, 0xAF, 0x47, 0xFF}}},
	{{{27, 42, 20},0, {1008, 1008},{0xF2, 0x5C, 0x57, 0xFF}}},
	{{{4, 33, 20},0, {752, 1008},{0xA1, 0x2E, 0x47, 0xFF}}},
	{{{14, -12, 20},0, {752, 752},{0xBC, 0xAF, 0x47, 0xFF}}},
	{{{39, -11, 20},0, {1008, 752},{0x19, 0xA6, 0x57, 0xFF}}},
	{{{60, -2, 16},0, {1264, 752},{0x60, 0xD2, 0x45, 0xFF}}},
	{{{51, 43, 16},0, {1264, 1008},{0x44, 0x52, 0x45, 0xFF}}},
	{{{27, 42, 20},0, {752, 368},{0xF2, 0x5C, 0x57, 0xFF}}},
	{{{8, 33, -15},0, {240, 240},{0x9D, 0x2F, 0xC0, 0xFF}}},
	{{{4, 33, 20},0, {752, 240},{0xA1, 0x2E, 0x47, 0xFF}}},
	{{{29, 43, -22},0, {240, 368},{0xE7, 0x56, 0xA5, 0xFF}}},
	{{{51, 43, 16},0, {752, 496},{0x44, 0x52, 0x45, 0xFF}}},
	{{{52, 43, -19},0, {240, 496},{0x47, 0x52, 0xBE, 0xFF}}},
	{{{8, 33, -15},0, {1264, 752},{0x9D, 0x2F, 0xC0, 0xFF}}},
	{{{40, -11, -22},0, {1008, 496},{0xC, 0xA8, 0xA6, 0xFF}}},
	{{{17, -11, -15},0, {1264, 496},{0xB9, 0xAC, 0xC0, 0xFF}}},
	{{{29, 43, -22},0, {1008, 752},{0xE7, 0x56, 0xA5, 0xFF}}},
	{{{62, -1, -19},0, {752, 496},{0x63, 0xD3, 0xBE, 0xFF}}},
	{{{52, 43, -19},0, {752, 752},{0x47, 0x52, 0xBE, 0xFF}}},
	{{{17, -11, -15},0, {752, 496},{0xB9, 0xAC, 0xC0, 0xFF}}},
	{{{39, -11, 20},0, {1264, 368},{0x19, 0xA6, 0x57, 0xFF}}},
	{{{14, -12, 20},0, {1264, 496},{0xBC, 0xAF, 0x47, 0xFF}}},
	{{{40, -11, -22},0, {752, 368},{0xC, 0xA8, 0xA6, 0xFF}}},
	{{{60, -2, 16},0, {1264, 240},{0x60, 0xD2, 0x45, 0xFF}}},
	{{{62, -1, -19},0, {752, 240},{0x63, 0xD3, 0xBE, 0xFF}}},
	{{{60, -2, 16},0, {1776, 496},{0x60, 0xD2, 0x45, 0xFF}}},
	{{{52, 43, -19},0, {1264, 240},{0x47, 0x52, 0xBE, 0xFF}}},
	{{{51, 43, 16},0, {1776, 240},{0x44, 0x52, 0x45, 0xFF}}},
	{{{62, -1, -19},0, {1264, 496},{0x63, 0xD3, 0xBE, 0xFF}}},
};

Gfx mario_001_switch_006_switch_option_left_hand_wing_cap_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_006_switch_option_left_hand_wing_cap_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(4, 7, 8, 0, 4, 8, 9, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 13, 11, 0),
	gsSP2Triangles(14, 13, 10, 0, 14, 15, 13, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 19, 17, 0),
	gsSP2Triangles(19, 20, 17, 0, 19, 21, 20, 0),
	gsSP2Triangles(22, 23, 24, 0, 22, 25, 23, 0),
	gsSP2Triangles(25, 26, 23, 0, 25, 27, 26, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 31, 29, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_006_switch_option_left_hand_wing_cap_wings_mesh_layer_4_vtx_0[8] = {
	{{{4, 126, 44},0, {-16, 1996},{0x62, 0x4A, 0x21, 0xFF}}},
	{{{-17, 215, -93},0, {-16, -16},{0x62, 0x4A, 0x21, 0xFF}}},
	{{{-69, 265, -54},0, {974, -16},{0x62, 0x4A, 0x21, 0xFF}}},
	{{{-47, 175, 83},0, {974, 1996},{0x62, 0x4A, 0x21, 0xFF}}},
	{{{-110, -133, -162},0, {974, -16},{0x50, 0x9E, 0xF3, 0xFF}}},
	{{{-48, -80, -174},0, {-16, -16},{0x50, 0x9E, 0xF3, 0xFF}}},
	{{{-17, -78, -12},0, {-16, 1996},{0x50, 0x9E, 0xF3, 0xFF}}},
	{{{-80, -131, 0},0, {974, 1996},{0x50, 0x9E, 0xF3, 0xFF}}},
};

Gfx mario_001_switch_006_switch_option_left_hand_wing_cap_wings_mesh_layer_4_tri_0[] = {
	gsSPVertex(mario_001_switch_006_switch_option_left_hand_wing_cap_wings_mesh_layer_4_vtx_0 + 0, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_006_switch_option_left_hand_wing_cap_wings_mesh_layer_4_vtx_1[8] = {
	{{{-48, -80, -174},0, {974, -16},{0x50, 0x9E, 0xF3, 0xFF}}},
	{{{45, -27, -25},0, {-16, 1996},{0x4F, 0x9E, 0xF3, 0xFF}}},
	{{{-17, -78, -12},0, {974, 1996},{0x50, 0x9E, 0xF3, 0xFF}}},
	{{{14, -29, -186},0, {-16, -16},{0x50, 0x9E, 0xF3, 0xFF}}},
	{{{4, 126, 44},0, {974, 1996},{0x62, 0x4A, 0x21, 0xFF}}},
	{{{56, 76, 3},0, {-16, 1996},{0x62, 0x4A, 0x21, 0xFF}}},
	{{{-17, 215, -93},0, {974, -16},{0x62, 0x4A, 0x21, 0xFF}}},
	{{{34, 165, -133},0, {-16, -16},{0x62, 0x4A, 0x20, 0xFF}}},
};

Gfx mario_001_switch_006_switch_option_left_hand_wing_cap_wings_mesh_layer_4_tri_1[] = {
	gsSPVertex(mario_001_switch_006_switch_option_left_hand_wing_cap_wings_mesh_layer_4_vtx_1 + 0, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 5, 7, 6, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_009_skinned_mesh_layer_1_vtx_0[8] = {
	{{{-73, 41, 0},0, {2000, 790},{0x8B, 0x31, 0x0, 0xFF}}},
	{{{-73, 41, 0},0, {284, 774},{0x8B, 0x31, 0x0, 0xFF}}},
	{{{-73, 35, 57},0, {1556, 376},{0x96, 0x33, 0x30, 0xFF}}},
	{{{-73, 35, 57},0, {459, 776},{0x96, 0x33, 0x30, 0xFF}}},
	{{{-73, -29, 57},0, {1361, 380},{0xA3, 0xC2, 0x3D, 0xFF}}},
	{{{-73, -32, 0},0, {871, 778},{0x99, 0xB5, 0x0, 0xFF}}},
	{{{-73, -29, 57},0, {697, 778},{0xA3, 0xC2, 0x3D, 0xFF}}},
	{{{-73, -32, 0},0, {1777, 790},{0x99, 0xB5, 0x0, 0xFF}}},
};

Gfx mario_001_switch_000_offset_009_skinned_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_000_offset_009_skinned_mesh_layer_1_vtx_0 + 0, 8, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_009_mesh_layer_1_vtx_0[9] = {
	{{{48, -24, 29},0, {436, 848},{0xE6, 0x9F, 0x4E, 0xFF}}},
	{{{48, -22, -20},0, {289, 849},{0xE1, 0xA2, 0xB0, 0xFF}}},
	{{{5, 32, 36},0, {1362, 374},{0xBE, 0x46, 0x53, 0xFF}}},
	{{{48, -24, 29},0, {1526, 304},{0xE6, 0x9F, 0x4E, 0xFF}}},
	{{{5, 32, 36},0, {699, 783},{0xBE, 0x46, 0x53, 0xFF}}},
	{{{5, 35, -21},0, {871, 782},{0xBA, 0x4C, 0xB6, 0xFF}}},
	{{{5, 35, -21},0, {1778, 795},{0xBA, 0x4C, 0xB6, 0xFF}}},
	{{{49, 4, -19},0, {1873, 861},{0x5, 0x2, 0x81, 0xFF}}},
	{{{48, -22, -20},0, {1952, 861},{0xE1, 0xA2, 0xB0, 0xFF}}},
};

Gfx mario_001_switch_000_offset_009_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_000_offset_009_mesh_layer_1_vtx_0 + 0, 9, 8),
	gsSP2Triangles(1, 8, 3, 0, 1, 9, 8, 0),
	gsSP2Triangles(2, 10, 4, 0, 10, 2, 11, 0),
	gsSP2Triangles(5, 6, 12, 0, 5, 12, 13, 0),
	gsSP2Triangles(0, 7, 14, 0, 15, 0, 14, 0),
	gsSP1Triangle(0, 15, 16, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_009_mesh_layer_1_vtx_1[10] = {
	{{{5, 35, -21},0, {871, 782},{0xBA, 0x4C, 0xB6, 0xFF}}},
	{{{5, 32, 36},0, {699, 783},{0xBE, 0x46, 0x53, 0xFF}}},
	{{{42, 29, 31},0, {715, 840},{0x15, 0x56, 0x5B, 0xFF}}},
	{{{39, 30, -19},0, {866, 835},{0xD, 0x5A, 0xA7, 0xFF}}},
	{{{5, 32, 36},0, {1362, 374},{0xBE, 0x46, 0x53, 0xFF}}},
	{{{48, -24, 29},0, {1526, 304},{0xE6, 0x9F, 0x4E, 0xFF}}},
	{{{42, 29, 31},0, {1367, 317},{0x15, 0x56, 0x5B, 0xFF}}},
	{{{49, 4, -19},0, {1873, 861},{0x5, 0x2, 0x81, 0xFF}}},
	{{{5, 35, -21},0, {1778, 795},{0xBA, 0x4C, 0xB6, 0xFF}}},
	{{{39, 30, -19},0, {1793, 846},{0xD, 0x5A, 0xA7, 0xFF}}},
};

Gfx mario_001_switch_000_offset_009_mesh_layer_1_tri_1[] = {
	gsSPVertex(mario_001_switch_000_offset_009_mesh_layer_1_vtx_1 + 0, 10, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 7, 8, 9, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_010_skinned_mesh_layer_1_vtx_0[9] = {
	{{{49, 4, -19},0, {1873, 861},{0x5, 0x2, 0x81, 0xFF}}},
	{{{48, -22, -20},0, {289, 849},{0xE1, 0xA2, 0xB0, 0xFF}}},
	{{{48, -24, 29},0, {1526, 304},{0xE6, 0x9F, 0x4E, 0xFF}}},
	{{{48, -24, 29},0, {436, 848},{0xE6, 0x9F, 0x4E, 0xFF}}},
	{{{48, -22, -20},0, {1952, 861},{0xE1, 0xA2, 0xB0, 0xFF}}},
	{{{39, 30, -19},0, {1793, 846},{0xD, 0x5A, 0xA7, 0xFF}}},
	{{{42, 29, 31},0, {715, 840},{0x15, 0x56, 0x5B, 0xFF}}},
	{{{39, 30, -19},0, {866, 835},{0xD, 0x5A, 0xA7, 0xFF}}},
	{{{42, 29, 31},0, {1367, 317},{0x15, 0x56, 0x5B, 0xFF}}},
};

Gfx mario_001_switch_000_offset_010_skinned_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_000_offset_010_skinned_mesh_layer_1_vtx_0 + 0, 9, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_010_mesh_layer_1_vtx_0[11] = {
	{{{3, -23, 28},0, {433, 855},{0x1F, 0xA6, 0x55, 0xFF}}},
	{{{3, -21, -19},0, {289, 856},{0x14, 0xAB, 0xA3, 0xFF}}},
	{{{3, -21, -19},0, {1949, 867},{0x14, 0xAB, 0xA3, 0xFF}}},
	{{{43, -13, -18},0, {1923, 927},{0x18, 0xAD, 0xA3, 0xFF}}},
	{{{35, 27, -17},0, {1801, 917},{0x13, 0x5F, 0xAE, 0xFF}}},
	{{{6, 29, -18},0, {1796, 873},{0xA, 0x5C, 0xA9, 0xFF}}},
	{{{6, 29, -18},0, {864, 861},{0xA, 0x5C, 0xA9, 0xFF}}},
	{{{11, 27, 28},0, {724, 869},{0x15, 0x56, 0x5B, 0xFF}}},
	{{{3, -23, 28},0, {1523, 297},{0x1F, 0xA6, 0x55, 0xFF}}},
	{{{0, 2, 29},0, {1446, 302},{0x14, 0xFE, 0x7D, 0xFF}}},
	{{{11, 27, 28},0, {1370, 288},{0x15, 0x56, 0x5B, 0xFF}}},
};

Gfx mario_001_switch_000_offset_010_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_000_offset_010_mesh_layer_1_vtx_0 + 0, 11, 9),
	gsSP2Triangles(1, 9, 3, 0, 1, 10, 9, 0),
	gsSP2Triangles(11, 4, 0, 0, 11, 0, 12, 0),
	gsSP2Triangles(12, 0, 13, 0, 13, 0, 14, 0),
	gsSP2Triangles(0, 5, 14, 0, 6, 15, 7, 0),
	gsSP2Triangles(6, 16, 15, 0, 2, 17, 18, 0),
	gsSP2Triangles(2, 18, 8, 0, 18, 19, 8, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_010_mesh_layer_1_vtx_1[13] = {
	{{{11, 27, 28},0, {724, 869},{0x15, 0x56, 0x5B, 0xFF}}},
	{{{35, 27, -17},0, {859, 905},{0x13, 0x5F, 0xAE, 0xFF}}},
	{{{6, 29, -18},0, {864, 861},{0xA, 0x5C, 0xA9, 0xFF}}},
	{{{43, 24, 23},0, {739, 917},{0x13, 0x5B, 0x57, 0xFF}}},
	{{{43, -16, 21},0, {1496, 236},{0x1F, 0xA1, 0x4E, 0xFF}}},
	{{{0, 2, 29},0, {1446, 302},{0x14, 0xFE, 0x7D, 0xFF}}},
	{{{3, -23, 28},0, {1523, 297},{0x1F, 0xA6, 0x55, 0xFF}}},
	{{{43, 24, 23},0, {1375, 239},{0x13, 0x5B, 0x57, 0xFF}}},
	{{{11, 27, 28},0, {1370, 288},{0x15, 0x56, 0x5B, 0xFF}}},
	{{{3, -21, -19},0, {289, 856},{0x14, 0xAB, 0xA3, 0xFF}}},
	{{{43, -16, 21},0, {413, 917},{0x1F, 0xA1, 0x4E, 0xFF}}},
	{{{3, -23, 28},0, {433, 855},{0x1F, 0xA6, 0x55, 0xFF}}},
	{{{43, -13, -18},0, {293, 917},{0x18, 0xAD, 0xA3, 0xFF}}},
};

Gfx mario_001_switch_000_offset_010_mesh_layer_1_tri_1[] = {
	gsSPVertex(mario_001_switch_000_offset_010_mesh_layer_1_vtx_1 + 0, 13, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 5, 4, 7, 0),
	gsSP2Triangles(5, 7, 8, 0, 9, 10, 11, 0),
	gsSP1Triangle(9, 12, 10, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_011_skinned_mesh_layer_1_vtx_0[8] = {
	{{{43, 24, 23},0, {739, 917},{0x13, 0x5B, 0x57, 0xFF}}},
	{{{43, -16, 21},0, {1496, 236},{0x1F, 0xA1, 0x4E, 0xFF}}},
	{{{43, 24, 23},0, {1375, 239},{0x13, 0x5B, 0x57, 0xFF}}},
	{{{43, -16, 21},0, {413, 917},{0x1F, 0xA1, 0x4E, 0xFF}}},
	{{{43, -13, -18},0, {1923, 927},{0x18, 0xAD, 0xA3, 0xFF}}},
	{{{35, 27, -17},0, {1801, 917},{0x13, 0x5F, 0xAE, 0xFF}}},
	{{{35, 27, -17},0, {859, 905},{0x13, 0x5F, 0xAE, 0xFF}}},
	{{{43, -13, -18},0, {293, 917},{0x18, 0xAD, 0xA3, 0xFF}}},
};

Gfx mario_001_switch_000_offset_011_skinned_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_000_offset_011_skinned_mesh_layer_1_vtx_0 + 0, 8, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_011_mesh_layer_1_vtx_0[8] = {
	{{{36, -9, 22},0, {1428, 152},{0x6E, 0xFE, 0x40, 0xFF}}},
	{{{-11, 8, 25},0, {1382, 223},{0x15, 0x52, 0x5E, 0xFF}}},
	{{{32, -8, -19},0, {291, 1003},{0x67, 0x1, 0xB5, 0xFF}}},
	{{{36, -9, 22},0, {416, 1008},{0x6E, 0xFE, 0x40, 0xFF}}},
	{{{-14, 9, -17},0, {1816, 939},{0x1B, 0x59, 0xA9, 0xFF}}},
	{{{32, -8, -19},0, {1868, 1008},{0x67, 0x1, 0xB5, 0xFF}}},
	{{{-14, 9, -17},0, {860, 929},{0x1B, 0x59, 0xA9, 0xFF}}},
	{{{-11, 8, 25},0, {734, 934},{0x15, 0x52, 0x5E, 0xFF}}},
};

Gfx mario_001_switch_000_offset_011_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_000_offset_011_mesh_layer_1_vtx_0 + 0, 8, 8),
	gsSP2Triangles(1, 8, 9, 0, 1, 9, 2, 0),
	gsSP2Triangles(3, 10, 11, 0, 3, 7, 10, 0),
	gsSP2Triangles(4, 5, 12, 0, 4, 12, 13, 0),
	gsSP2Triangles(0, 14, 6, 0, 0, 15, 14, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_011_mesh_layer_1_vtx_1[4] = {
	{{{-11, 8, 25},0, {734, 934},{0x15, 0x52, 0x5E, 0xFF}}},
	{{{36, -9, 22},0, {741, 1008},{0x6E, 0xFE, 0x40, 0xFF}}},
	{{{32, -8, -19},0, {867, 1003},{0x67, 0x1, 0xB5, 0xFF}}},
	{{{-14, 9, -17},0, {860, 929},{0x1B, 0x59, 0xA9, 0xFF}}},
};

Gfx mario_001_switch_000_offset_011_mesh_layer_1_tri_1[] = {
	gsSPVertex(mario_001_switch_000_offset_011_mesh_layer_1_vtx_1 + 0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_012_skinned_mesh_layer_1_vtx_0[8] = {
	{{{-73, 41, 0},0, {1809, 392},{0x8B, 0x31, 0x0, 0xFF}}},
	{{{-73, 41, 0},0, {284, 774},{0x8B, 0x31, 0x0, 0xFF}}},
	{{{-73, 35, -57},0, {1352, 385},{0x96, 0x33, 0xD0, 0xFF}}},
	{{{-73, 35, -57},0, {111, 776},{0x96, 0x33, 0xD0, 0xFF}}},
	{{{-73, -29, -57},0, {1157, 382},{0xA3, 0xC2, 0xC3, 0xFF}}},
	{{{-73, -32, 0},0, {871, 778},{0x99, 0xB5, 0x0, 0xFF}}},
	{{{-73, -29, -57},0, {1046, 778},{0xA3, 0xC2, 0xC3, 0xFF}}},
	{{{-73, -32, 0},0, {2032, 392},{0x99, 0xB5, 0x0, 0xFF}}},
};

Gfx mario_001_switch_000_offset_012_skinned_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_000_offset_012_skinned_mesh_layer_1_vtx_0 + 0, 8, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_012_mesh_layer_1_vtx_0[9] = {
	{{{48, -24, -29},0, {134, 848},{0xE6, 0x9F, 0xB2, 0xFF}}},
	{{{48, -22, 20},0, {281, 849},{0xE1, 0xA2, 0x50, 0xFF}}},
	{{{5, 32, -36},0, {1157, 387},{0xBE, 0x46, 0xAD, 0xFF}}},
	{{{48, -24, -29},0, {1322, 457},{0xE6, 0x9F, 0xB2, 0xFF}}},
	{{{5, 32, -36},0, {1044, 783},{0xBE, 0x46, 0xAD, 0xFF}}},
	{{{5, 35, 21},0, {872, 782},{0xBA, 0x4C, 0x4A, 0xFF}}},
	{{{5, 35, 21},0, {2031, 396},{0xBA, 0x4C, 0x4A, 0xFF}}},
	{{{49, 4, 19},0, {1936, 463},{0x5, 0x2, 0x7F, 0xFF}}},
	{{{48, -22, 20},0, {1857, 462},{0xE1, 0xA2, 0x50, 0xFF}}},
};

Gfx mario_001_switch_000_offset_012_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_000_offset_012_mesh_layer_1_vtx_0 + 0, 9, 8),
	gsSP2Triangles(1, 3, 8, 0, 1, 8, 9, 0),
	gsSP2Triangles(2, 4, 10, 0, 10, 11, 2, 0),
	gsSP2Triangles(5, 12, 6, 0, 5, 13, 12, 0),
	gsSP2Triangles(0, 14, 7, 0, 15, 14, 0, 0),
	gsSP1Triangle(0, 16, 15, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_012_mesh_layer_1_vtx_1[10] = {
	{{{5, 35, 21},0, {872, 782},{0xBA, 0x4C, 0x4A, 0xFF}}},
	{{{42, 29, -31},0, {1028, 840},{0x15, 0x56, 0xA5, 0xFF}}},
	{{{5, 32, -36},0, {1044, 783},{0xBE, 0x46, 0xAD, 0xFF}}},
	{{{39, 30, 19},0, {877, 835},{0xD, 0x5A, 0x59, 0xFF}}},
	{{{5, 32, -36},0, {1157, 387},{0xBE, 0x46, 0xAD, 0xFF}}},
	{{{42, 29, -31},0, {1163, 444},{0x15, 0x56, 0xA5, 0xFF}}},
	{{{48, -24, -29},0, {1322, 457},{0xE6, 0x9F, 0xB2, 0xFF}}},
	{{{49, 4, 19},0, {1936, 463},{0x5, 0x2, 0x7F, 0xFF}}},
	{{{39, 30, 19},0, {2016, 448},{0xD, 0x5A, 0x59, 0xFF}}},
	{{{5, 35, 21},0, {2031, 396},{0xBA, 0x4C, 0x4A, 0xFF}}},
};

Gfx mario_001_switch_000_offset_012_mesh_layer_1_tri_1[] = {
	gsSPVertex(mario_001_switch_000_offset_012_mesh_layer_1_vtx_1 + 0, 10, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 7, 8, 9, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_013_skinned_mesh_layer_1_vtx_0[9] = {
	{{{49, 4, 19},0, {1936, 463},{0x5, 0x2, 0x7F, 0xFF}}},
	{{{39, 30, 19},0, {2016, 448},{0xD, 0x5A, 0x59, 0xFF}}},
	{{{42, 29, -31},0, {1028, 840},{0x15, 0x56, 0xA5, 0xFF}}},
	{{{39, 30, 19},0, {877, 835},{0xD, 0x5A, 0x59, 0xFF}}},
	{{{48, -22, 20},0, {281, 849},{0xE1, 0xA2, 0x50, 0xFF}}},
	{{{48, -24, -29},0, {1322, 457},{0xE6, 0x9F, 0xB2, 0xFF}}},
	{{{48, -24, -29},0, {134, 848},{0xE6, 0x9F, 0xB2, 0xFF}}},
	{{{48, -22, 20},0, {1857, 462},{0xE1, 0xA2, 0x50, 0xFF}}},
	{{{42, 29, -31},0, {1163, 444},{0x15, 0x56, 0xA5, 0xFF}}},
};

Gfx mario_001_switch_000_offset_013_skinned_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_000_offset_013_skinned_mesh_layer_1_vtx_0 + 0, 9, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_013_mesh_layer_1_vtx_0[11] = {
	{{{6, 29, 18},0, {2013, 474},{0xA, 0x5C, 0x57, 0xFF}}},
	{{{35, 27, 17},0, {2008, 518},{0x13, 0x5F, 0x52, 0xFF}}},
	{{{43, -13, 18},0, {1886, 529},{0x18, 0xAD, 0x5D, 0xFF}}},
	{{{3, -21, 19},0, {1860, 469},{0x14, 0xAB, 0x5D, 0xFF}}},
	{{{6, 29, 18},0, {879, 861},{0xA, 0x5C, 0x57, 0xFF}}},
	{{{11, 27, -28},0, {1019, 869},{0x15, 0x56, 0xA5, 0xFF}}},
	{{{3, -23, -28},0, {136, 855},{0x1F, 0xA6, 0xAB, 0xFF}}},
	{{{3, -21, 19},0, {281, 856},{0x14, 0xAB, 0x5D, 0xFF}}},
	{{{0, 2, -29},0, {1242, 459},{0x14, 0xFE, 0x83, 0xFF}}},
	{{{3, -23, -28},0, {1319, 464},{0x1F, 0xA6, 0xAB, 0xFF}}},
	{{{11, 27, -28},0, {1166, 473},{0x15, 0x56, 0xA5, 0xFF}}},
};

Gfx mario_001_switch_000_offset_013_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_000_offset_013_mesh_layer_1_vtx_0 + 0, 11, 9),
	gsSP2Triangles(0, 9, 1, 0, 10, 9, 0, 0),
	gsSP2Triangles(11, 10, 0, 0, 12, 11, 0, 0),
	gsSP2Triangles(12, 0, 7, 0, 2, 3, 13, 0),
	gsSP2Triangles(2, 13, 14, 0, 4, 6, 15, 0),
	gsSP2Triangles(4, 15, 16, 0, 5, 17, 18, 0),
	gsSP2Triangles(5, 8, 17, 0, 17, 8, 19, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_offset_013_mesh_layer_1_vtx_1[13] = {
	{{{11, 27, -28},0, {1019, 869},{0x15, 0x56, 0xA5, 0xFF}}},
	{{{6, 29, 18},0, {879, 861},{0xA, 0x5C, 0x57, 0xFF}}},
	{{{35, 27, 17},0, {884, 905},{0x13, 0x5F, 0x52, 0xFF}}},
	{{{43, 24, -23},0, {1004, 917},{0x13, 0x5B, 0xA9, 0xFF}}},
	{{{43, -16, -21},0, {1292, 525},{0x1F, 0xA1, 0xB2, 0xFF}}},
	{{{3, -23, -28},0, {1319, 464},{0x1F, 0xA6, 0xAB, 0xFF}}},
	{{{0, 2, -29},0, {1242, 459},{0x14, 0xFE, 0x83, 0xFF}}},
	{{{43, 24, -23},0, {1171, 522},{0x13, 0x5B, 0xA9, 0xFF}}},
	{{{11, 27, -28},0, {1166, 473},{0x15, 0x56, 0xA5, 0xFF}}},
	{{{3, -21, 19},0, {281, 856},{0x14, 0xAB, 0x5D, 0xFF}}},
	{{{3, -23, -28},0, {136, 855},{0x1F, 0xA6, 0xAB, 0xFF}}},
	{{{43, -16, -21},0, {157, 917},{0x1F, 0xA1, 0xB2, 0xFF}}},
	{{{43, -13, 18},0, {278, 917},{0x18, 0xAD, 0x5D, 0xFF}}},
};

Gfx mario_001_switch_000_offset_013_mesh_layer_1_tri_1[] = {
	gsSPVertex(mario_001_switch_000_offset_013_mesh_layer_1_vtx_1 + 0, 13, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 6, 7, 4, 0),
	gsSP2Triangles(6, 8, 7, 0, 9, 10, 11, 0),
	gsSP1Triangle(9, 11, 12, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_displaylist_005_skinned_mesh_layer_1_vtx_0[8] = {
	{{{43, 24, -23},0, {1004, 917},{0x13, 0x5B, 0xA9, 0xFF}}},
	{{{43, -16, -21},0, {1292, 525},{0x1F, 0xA1, 0xB2, 0xFF}}},
	{{{43, 24, -23},0, {1171, 522},{0x13, 0x5B, 0xA9, 0xFF}}},
	{{{43, -16, -21},0, {157, 917},{0x1F, 0xA1, 0xB2, 0xFF}}},
	{{{43, -13, 18},0, {1886, 529},{0x18, 0xAD, 0x5D, 0xFF}}},
	{{{35, 27, 17},0, {2008, 518},{0x13, 0x5F, 0x52, 0xFF}}},
	{{{35, 27, 17},0, {884, 905},{0x13, 0x5F, 0x52, 0xFF}}},
	{{{43, -13, 18},0, {278, 917},{0x18, 0xAD, 0x5D, 0xFF}}},
};

Gfx mario_001_switch_000_displaylist_005_skinned_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_000_displaylist_005_skinned_mesh_layer_1_vtx_0 + 0, 8, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_displaylist_005_mesh_layer_1_vtx_0[8] = {
	{{{-11, 8, -25},0, {1178, 538},{0x15, 0x52, 0xA2, 0xFF}}},
	{{{36, -9, -22},0, {1224, 610},{0x6E, 0xFE, 0xC0, 0xFF}}},
	{{{36, -9, -22},0, {157, 1008},{0x6E, 0xFE, 0xC0, 0xFF}}},
	{{{32, -8, 19},0, {283, 1003},{0x67, 0x1, 0x4B, 0xFF}}},
	{{{-14, 9, 17},0, {1993, 540},{0x1B, 0x59, 0x57, 0xFF}}},
	{{{32, -8, 19},0, {1941, 610},{0x67, 0x1, 0x4B, 0xFF}}},
	{{{-14, 9, 17},0, {883, 929},{0x1B, 0x59, 0x57, 0xFF}}},
	{{{-11, 8, -25},0, {1009, 934},{0x15, 0x52, 0xA2, 0xFF}}},
};

Gfx mario_001_switch_000_displaylist_005_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_000_displaylist_005_mesh_layer_1_vtx_0 + 0, 8, 8),
	gsSP2Triangles(1, 8, 9, 0, 1, 2, 8, 0),
	gsSP2Triangles(3, 10, 11, 0, 3, 11, 7, 0),
	gsSP2Triangles(4, 12, 5, 0, 4, 13, 12, 0),
	gsSP2Triangles(0, 6, 14, 0, 0, 14, 15, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_000_displaylist_005_mesh_layer_1_vtx_1[4] = {
	{{{-11, 8, -25},0, {1009, 934},{0x15, 0x52, 0xA2, 0xFF}}},
	{{{32, -8, 19},0, {876, 1003},{0x67, 0x1, 0x4B, 0xFF}}},
	{{{36, -9, -22},0, {1001, 1008},{0x6E, 0xFE, 0xC0, 0xFF}}},
	{{{-14, 9, 17},0, {883, 929},{0x1B, 0x59, 0x57, 0xFF}}},
};

Gfx mario_001_switch_000_displaylist_005_mesh_layer_1_tri_1[] = {
	gsSPVertex(mario_001_switch_000_displaylist_005_mesh_layer_1_vtx_1 + 0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_vanish_mesh_layer_5_vtx_0[5] = {
	{{{-8, 32, -83},0, {35, 679},{0xD5, 0x47, 0xA0, 0xFF}}},
	{{{-73, 35, -57},0, {111, 776},{0x96, 0x33, 0xD0, 0xFF}}},
	{{{-73, 41, 0},0, {284, 774},{0x8B, 0x31, 0x0, 0xFF}}},
	{{{-8, 32, 83},0, {539, 679},{0xD5, 0x47, 0x60, 0xFF}}},
	{{{-73, 35, 57},0, {459, 776},{0x96, 0x33, 0x30, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_vanish_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_vanish_mesh_layer_5_vtx_0 + 0, 5, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 2, 4, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_001_vanish_skinned_mesh_layer_5_vtx_0[12] = {
	{{{-8, 32, -83},0, {35, 679},{0xD5, 0x47, 0xA0, 0xFF}}},
	{{{-73, 41, 0},0, {284, 774},{0x8B, 0x31, 0x0, 0xFF}}},
	{{{-8, 32, 83},0, {539, 679},{0xD5, 0x47, 0x60, 0xFF}}},
	{{{-8, 32, -83},0, {1352, 281},{0xD5, 0x47, 0xA0, 0xFF}}},
	{{{-73, -29, -57},0, {1046, 778},{0xA3, 0xC2, 0xC3, 0xFF}}},
	{{{-73, -32, 0},0, {871, 778},{0x99, 0xB5, 0x0, 0xFF}}},
	{{{-73, -29, 57},0, {697, 778},{0xA3, 0xC2, 0x3D, 0xFF}}},
	{{{-73, -29, -57},0, {1157, 382},{0xA3, 0xC2, 0xC3, 0xFF}}},
	{{{-73, 35, -57},0, {1352, 385},{0x96, 0x33, 0xD0, 0xFF}}},
	{{{-8, 32, 83},0, {1556, 480},{0xD5, 0x47, 0x60, 0xFF}}},
	{{{-73, -29, 57},0, {1361, 380},{0xA3, 0xC2, 0x3D, 0xFF}}},
	{{{-73, 35, 57},0, {1556, 376},{0x96, 0x33, 0x30, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_001_vanish_skinned_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_001_vanish_skinned_mesh_layer_5_vtx_0 + 0, 12, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_001_vanish_mesh_layer_5_vtx_0[12] = {
	{{{-42, 54, 0},0, {282, 651},{0xD9, 0x79, 0x0, 0xFF}}},
	{{{-40, 21, -90},0, {14, 657},{0xD2, 0x41, 0x9D, 0xFF}}},
	{{{-40, 21, 90},0, {561, 657},{0xD2, 0x41, 0x63, 0xFF}}},
	{{{-40, 21, -90},0, {1352, 257},{0xD2, 0x41, 0x9D, 0xFF}}},
	{{{-47, -12, -85},0, {1250, 266},{0xD0, 0xF8, 0x8B, 0xFF}}},
	{{{-53, -45, -79},0, {1150, 275},{0xDA, 0xAD, 0xA8, 0xFF}}},
	{{{-53, -45, -79},0, {1112, 676},{0xDA, 0xAD, 0xA8, 0xFF}}},
	{{{-37, -64, 0},0, {871, 647},{0xEF, 0x82, 0x0, 0xFF}}},
	{{{-53, -45, 79},0, {630, 676},{0xDA, 0xAD, 0x58, 0xFF}}},
	{{{-47, -12, 85},0, {1455, 495},{0xD0, 0xF8, 0x75, 0xFF}}},
	{{{-40, 21, 90},0, {1556, 504},{0xD2, 0x41, 0x63, 0xFF}}},
	{{{-53, -45, 79},0, {1354, 486},{0xDA, 0xAD, 0x58, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_001_vanish_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_001_vanish_mesh_layer_5_vtx_0 + 0, 12, 12),
	gsSP2Triangles(12, 13, 0, 0, 1, 12, 0, 0),
	gsSP2Triangles(1, 2, 12, 0, 12, 2, 14, 0),
	gsSP2Triangles(3, 15, 16, 0, 8, 3, 16, 0),
	gsSP2Triangles(7, 8, 16, 0, 16, 17, 7, 0),
	gsSP2Triangles(4, 18, 19, 0, 4, 19, 5, 0),
	gsSP2Triangles(6, 5, 19, 0, 6, 19, 20, 0),
	gsSP2Triangles(9, 21, 22, 0, 11, 21, 9, 0),
	gsSP2Triangles(10, 21, 11, 0, 21, 10, 23, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_001_vanish_mesh_layer_5_vtx_1[61] = {
	{{{71, 29, -101},0, {1596, 717},{0x3F, 0x34, 0x9F, 0xFF}}},
	{{{38, 38, -49},0, {1596, 626},{0x54, 0x5D, 0x15, 0xFF}}},
	{{{71, 12, -35},0, {1499, 627},{0x69, 0x47, 0xF5, 0xFF}}},
	{{{-9, 66, 0},0, {595, 150},{0xFD, 0x7F, 0x0, 0xFF}}},
	{{{38, 38, -49},0, {563, 240},{0x54, 0x5D, 0x15, 0xFF}}},
	{{{71, 29, -101},0, {595, 319},{0x3F, 0x34, 0x9F, 0xFF}}},
	{{{-9, 66, 0},0, {595, 489},{0xFD, 0x7F, 0x0, 0xFF}}},
	{{{71, 29, 101},0, {595, 319},{0x3F, 0x36, 0x60, 0xFF}}},
	{{{38, 38, 49},0, {563, 399},{0x54, 0x5D, 0xEB, 0xFF}}},
	{{{71, 29, 101},0, {1683, 717},{0x3F, 0x36, 0x60, 0xFF}}},
	{{{71, 12, 35},0, {1683, 618},{0x69, 0x47, 0xB, 0xFF}}},
	{{{38, 38, 49},0, {1596, 635},{0x54, 0x5D, 0xEB, 0xFF}}},
	{{{-9, 66, 0},0, {281, 599},{0xFD, 0x7F, 0x0, 0xFF}}},
	{{{71, 29, -101},0, {-16, 489},{0x3F, 0x34, 0x9F, 0xFF}}},
	{{{-32, 20, -94},0, {3, 644},{0xF6, 0x2E, 0x8A, 0xFF}}},
	{{{-40, 21, -90},0, {14, 657},{0xD2, 0x41, 0x9D, 0xFF}}},
	{{{-42, 54, 0},0, {282, 651},{0xD9, 0x79, 0x0, 0xFF}}},
	{{{-40, 21, 90},0, {561, 657},{0xD2, 0x41, 0x63, 0xFF}}},
	{{{-32, 20, 94},0, {573, 644},{0xF6, 0x2E, 0x76, 0xFF}}},
	{{{71, 29, 101},0, {595, 489},{0x3F, 0x36, 0x60, 0xFF}}},
	{{{-33, -47, -87},0, {1136, 646},{0xF8, 0xB9, 0x97, 0xFF}}},
	{{{72, -58, -91},0, {1148, 485},{0x3F, 0xBB, 0xAA, 0xFF}}},
	{{{48, -72, 0},0, {871, 518},{0x31, 0x8B, 0x0, 0xFF}}},
	{{{-37, -64, 0},0, {871, 647},{0xEF, 0x82, 0x0, 0xFF}}},
	{{{-33, -47, 87},0, {606, 646},{0xF8, 0xB9, 0x69, 0xFF}}},
	{{{72, -58, 91},0, {595, 485},{0x3F, 0xBA, 0x56, 0xFF}}},
	{{{-37, -46, 86},0, {611, 652},{0xD7, 0xAE, 0x58, 0xFF}}},
	{{{-53, -45, 79},0, {630, 676},{0xDA, 0xAD, 0x58, 0xFF}}},
	{{{41, 45, 0},0, {1915, 716},{0x46, 0x6A, 0x0, 0xFF}}},
	{{{38, 38, -49},0, {1915, 642},{0x54, 0x5D, 0x15, 0xFF}}},
	{{{-9, 66, 0},0, {1777, 708},{0xFD, 0x7F, 0x0, 0xFF}}},
	{{{38, 38, 49},0, {1889, 790},{0x54, 0x5D, 0xEB, 0xFF}}},
	{{{71, 12, -35},0, {1271, 745},{0x69, 0x47, 0xF5, 0xFF}}},
	{{{38, 38, -49},0, {1186, 718},{0x54, 0x5D, 0x15, 0xFF}}},
	{{{41, 45, 0},0, {1148, 790},{0x46, 0x6A, 0x0, 0xFF}}},
	{{{88, -7, 0},0, {1320, 801},{0x7F, 0x8, 0x0, 0xFF}}},
	{{{71, 12, 35},0, {1247, 849},{0x69, 0x47, 0xB, 0xFF}}},
	{{{38, 38, 49},0, {1151, 865},{0x54, 0x5D, 0xEB, 0xFF}}},
	{{{84, -7, 23},0, {1311, 835},{0x7D, 0xB, 0x15, 0xFF}}},
	{{{48, -72, 0},0, {1499, 811},{0x31, 0x8B, 0x0, 0xFF}}},
	{{{72, -58, 91},0, {1434, 946},{0x3F, 0xBA, 0x56, 0xFF}}},
	{{{71, 29, 101},0, {1172, 946},{0x3F, 0x36, 0x60, 0xFF}}},
	{{{84, -7, -23},0, {1327, 766},{0x7D, 0xB, 0xEB, 0xFF}}},
	{{{72, -58, -91},0, {1499, 672},{0x3F, 0xBB, 0xAA, 0xFF}}},
	{{{71, 29, -101},0, {1244, 642},{0x3F, 0x34, 0x9F, 0xFF}}},
	{{{-37, -64, 0},0, {871, 647},{0xEF, 0x82, 0x0, 0xFF}}},
	{{{-37, -46, -86},0, {1131, 652},{0xD7, 0xAE, 0xA8, 0xFF}}},
	{{{-33, -47, -87},0, {1136, 646},{0xF8, 0xB9, 0x97, 0xFF}}},
	{{{-53, -45, -79},0, {1112, 676},{0xDA, 0xAD, 0xA8, 0xFF}}},
	{{{-47, -12, -85},0, {1250, 266},{0xD0, 0xF8, 0x8B, 0xFF}}},
	{{{-40, 21, -90},0, {1352, 257},{0xD2, 0x41, 0x9D, 0xFF}}},
	{{{-32, 20, -94},0, {1352, 243},{0xF6, 0x2E, 0x8A, 0xFF}}},
	{{{-33, -47, -87},0, {1148, 243},{0xF8, 0xB9, 0x97, 0xFF}}},
	{{{-37, -46, -86},0, {1148, 250},{0xD7, 0xAE, 0xA8, 0xFF}}},
	{{{-53, -45, -79},0, {1150, 275},{0xDA, 0xAD, 0xA8, 0xFF}}},
	{{{-47, -12, 85},0, {1455, 495},{0xD0, 0xF8, 0x75, 0xFF}}},
	{{{-32, 20, 94},0, {1556, 518},{0xF6, 0x2E, 0x76, 0xFF}}},
	{{{-40, 21, 90},0, {1556, 504},{0xD2, 0x41, 0x63, 0xFF}}},
	{{{-33, -47, 87},0, {1352, 518},{0xF8, 0xB9, 0x69, 0xFF}}},
	{{{-37, -46, 86},0, {1352, 511},{0xD7, 0xAE, 0x58, 0xFF}}},
	{{{-53, -45, 79},0, {1354, 486},{0xDA, 0xAD, 0x58, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_001_vanish_mesh_layer_5_tri_1[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_001_vanish_mesh_layer_5_vtx_1 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 14, 15, 12, 0),
	gsSP2Triangles(15, 16, 12, 0, 17, 12, 16, 0),
	gsSP2Triangles(18, 12, 17, 0, 12, 18, 19, 0),
	gsSP2Triangles(20, 21, 22, 0, 22, 23, 20, 0),
	gsSP2Triangles(22, 24, 23, 0, 24, 22, 25, 0),
	gsSP2Triangles(23, 24, 26, 0, 27, 23, 26, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 30, 31, 0),
	gsSPVertex(mario_001_switch_vanish_000_offset_001_vanish_mesh_layer_5_vtx_1 + 32, 29, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 3, 2, 0, 4, 2, 5, 0),
	gsSP2Triangles(6, 3, 4, 0, 7, 3, 6, 0),
	gsSP2Triangles(6, 8, 7, 0, 8, 6, 4, 0),
	gsSP2Triangles(8, 4, 9, 0, 7, 10, 3, 0),
	gsSP2Triangles(10, 7, 11, 0, 11, 0, 10, 0),
	gsSP2Triangles(11, 12, 0, 0, 10, 0, 3, 0),
	gsSP2Triangles(13, 14, 15, 0, 16, 14, 13, 0),
	gsSP2Triangles(17, 18, 19, 0, 17, 19, 20, 0),
	gsSP2Triangles(20, 21, 17, 0, 17, 21, 22, 0),
	gsSP2Triangles(23, 24, 25, 0, 23, 26, 24, 0),
	gsSP2Triangles(26, 23, 27, 0, 23, 28, 27, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_displaylist_vanish_mesh_layer_5_vtx_0[106] = {
	{{{62, 284, 0},0, {534, 926},{0xED, 0x7E, 0x0, 0xFF}}},
	{{{84, 68, -56},0, {637, 926},{0xED, 0x5F, 0xAE, 0xFF}}},
	{{{62, 74, 0},0, {637, 875},{0x8D, 0x36, 0x0, 0xFF}}},
	{{{62, 74, 0},0, {637, 926},{0x8D, 0x36, 0x0, 0xFF}}},
	{{{84, 68, 56},0, {637, 875},{0xED, 0x5F, 0x52, 0xFF}}},
	{{{78, 90, 103},0, {534, 926},{0xE7, 0x5B, 0x55, 0xFF}}},
	{{{-43, 55, 56},0, {637, 875},{0xA4, 0x3C, 0x41, 0xFF}}},
	{{{3, 28, 76},0, {637, 926},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{-18, -27, 0},0, {534, 926},{0xBC, 0x9C, 0x27, 0xFF}}},
	{{{3, 28, 76},0, {637, 875},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{-43, 55, 56},0, {637, 926},{0xA4, 0x3C, 0x41, 0xFF}}},
	{{{-44, 55, 0},0, {637, 926},{0x91, 0x39, 0x1A, 0xFF}}},
	{{{68, 44, 113},0, {637, 926},{0xF5, 0xC, 0x7E, 0xFF}}},
	{{{-43, 55, -56},0, {534, 926},{0x90, 0x30, 0xDC, 0xFF}}},
	{{{-18, -27, 0},0, {637, 875},{0xBC, 0x9C, 0x27, 0xFF}}},
	{{{3, 28, -76},0, {637, 875},{0xB0, 0xF9, 0x9D, 0xFF}}},
	{{{-18, -27, 0},0, {637, 926},{0xBC, 0x9C, 0x27, 0xFF}}},
	{{{3, 28, -76},0, {534, 926},{0xB0, 0xF9, 0x9D, 0xFF}}},
	{{{-43, 55, -56},0, {637, 875},{0x90, 0x30, 0xDC, 0xFF}}},
	{{{78, 90, -103},0, {637, 926},{0xE5, 0x5B, 0xAB, 0xFF}}},
	{{{78, 90, -103},0, {637, 875},{0xE5, 0x5B, 0xAB, 0xFF}}},
	{{{68, 44, -113},0, {637, 926},{0xF2, 0x10, 0x83, 0xFF}}},
	{{{125, 78, 0},0, {549, 436},{0x7A, 0x25, 0x0, 0xFF}}},
	{{{84, 68, -56},0, {511, 798},{0xED, 0x5F, 0xAE, 0xFF}}},
	{{{62, 284, 0},0, {549, 798},{0xED, 0x7E, 0x0, 0xFF}}},
	{{{84, 68, 56},0, {587, 798},{0xED, 0x5F, 0x52, 0xFF}}},
	{{{-6, -27, 65},0, {240, 496},{0xD8, 0xB6, 0x5F, 0xFF}}},
	{{{3, 28, 76},0, {240, 368},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{-18, -27, 0},0, {496, 368},{0xBC, 0x9C, 0x27, 0xFF}}},
	{{{83, -104, 145},0, {496, 496},{0x57, 0x25, 0x55, 0xFF}}},
	{{{-6, -27, 0},0, {240, 496},{0xD1, 0xA6, 0xB4, 0xFF}}},
	{{{3, 28, -76},0, {240, 368},{0xB0, 0xF9, 0x9D, 0xFF}}},
	{{{206, 72, 89},0, {535, 436},{0xD1, 0x57, 0x50, 0xFF}}},
	{{{111, 73, 89},0, {534, 650},{0x18, 0x62, 0x4E, 0xFF}}},
	{{{109, 3, 102},0, {628, 654},{0xF5, 0x5, 0x7E, 0xFF}}},
	{{{68, 44, 113},0, {572, 749},{0xF5, 0xC, 0x7E, 0xFF}}},
	{{{78, 90, 103},0, {529, 725},{0xE7, 0x5B, 0x55, 0xFF}}},
	{{{206, 80, 0},0, {1264, 112},{0xC7, 0x72, 0x0, 0xFF}}},
	{{{206, 72, 89},0, {1264, -16},{0xD1, 0x57, 0x50, 0xFF}}},
	{{{242, 95, 86},0, {1264, -16},{0x2A, 0x6F, 0x2D, 0xFF}}},
	{{{242, 121, 0},0, {1264, 112},{0xFF, 0x7A, 0x23, 0xFF}}},
	{{{242, 95, -86},0, {1264, -16},{0x30, 0x64, 0xC2, 0xFF}}},
	{{{206, 72, -89},0, {1264, -16},{0xEA, 0x4E, 0x9E, 0xFF}}},
	{{{206, 80, 0},0, {1008, 448},{0xC7, 0x72, 0x0, 0xFF}}},
	{{{111, 73, 89},0, {672, 652},{0x18, 0x62, 0x4E, 0xFF}}},
	{{{206, 72, 89},0, {670, 444},{0xD1, 0x57, 0x50, 0xFF}}},
	{{{111, 85, 0},0, {1008, 652},{0xD, 0x7E, 0xE, 0xFF}}},
	{{{111, 73, -89},0, {1344, 652},{0x15, 0x63, 0xB4, 0xFF}}},
	{{{206, 72, -89},0, {1346, 444},{0xEA, 0x4E, 0x9E, 0xFF}}},
	{{{78, 90, 0},0, {1008, 723},{0xE8, 0x7D, 0x3, 0xFF}}},
	{{{78, 90, 103},0, {620, 723},{0xE7, 0x5B, 0x55, 0xFF}}},
	{{{-43, 55, 56},0, {799, 939},{0xA4, 0x3C, 0x41, 0xFF}}},
	{{{-44, 55, 0},0, {1008, 940},{0x91, 0x39, 0x1A, 0xFF}}},
	{{{-43, 55, -56},0, {1217, 939},{0x90, 0x30, 0xDC, 0xFF}}},
	{{{78, 90, -103},0, {1396, 723},{0xE5, 0x5B, 0xAB, 0xFF}}},
	{{{206, 72, 89},0, {1264, 1008},{0xD1, 0x57, 0x50, 0xFF}}},
	{{{255, 10, 136},0, {1264, 880},{0x29, 0x1E, 0x74, 0xFF}}},
	{{{242, 95, 86},0, {1264, 1008},{0x2A, 0x6F, 0x2D, 0xFF}}},
	{{{188, -10, 104},0, {1264, 880},{0xED, 0x31, 0x74, 0xFF}}},
	{{{109, 3, 102},0, {1136, 880},{0xF5, 0x5, 0x7E, 0xFF}}},
	{{{216, -77, 182},0, {1136, 752},{0x4D, 0x2, 0x65, 0xFF}}},
	{{{88, -72, 77},0, {1008, 752},{0x1, 0xF5, 0x7F, 0xFF}}},
	{{{68, 44, 113},0, {1008, 880},{0xF5, 0xC, 0x7E, 0xFF}}},
	{{{3, 28, 76},0, {752, 880},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{3, 28, 76},0, {752, 880},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{-6, -27, 65},0, {752, 752},{0xD8, 0xB6, 0x5F, 0xFF}}},
	{{{88, -72, 77},0, {1008, 752},{0x1, 0xF5, 0x7F, 0xFF}}},
	{{{83, -104, 145},0, {752, 624},{0x57, 0x25, 0x55, 0xFF}}},
	{{{83, -168, 0},0, {1008, 624},{0x52, 0xA6, 0xDC, 0xFF}}},
	{{{-6, -27, 0},0, {752, 752},{0xD1, 0xA6, 0xB4, 0xFF}}},
	{{{60, -72, -77},0, {1008, 752},{0xC9, 0xBF, 0xA1, 0xFF}}},
	{{{3, 28, -76},0, {752, 880},{0xB0, 0xF9, 0x9D, 0xFF}}},
	{{{68, 44, -113},0, {1008, 880},{0xF2, 0x10, 0x83, 0xFF}}},
	{{{109, 3, -102},0, {1136, 880},{0x1, 0xF6, 0x81, 0xFF}}},
	{{{88, -77, -82},0, {1136, 752},{0xFC, 0xBE, 0x93, 0xFF}}},
	{{{188, -10, -104},0, {1264, 880},{0x3, 0x0, 0x81, 0xFF}}},
	{{{206, 72, -89},0, {1264, 1008},{0xEA, 0x4E, 0x9E, 0xFF}}},
	{{{258, 10, -94},0, {1264, 880},{0x53, 0xF, 0xA1, 0xFF}}},
	{{{242, 95, -86},0, {1264, 1008},{0x30, 0x64, 0xC2, 0xFF}}},
	{{{258, -49, -84},0, {1264, 752},{0x5E, 0xCB, 0xBD, 0xFF}}},
	{{{200, -99, -92},0, {1264, 752},{0x2A, 0xB4, 0xA4, 0xFF}}},
	{{{199, -129, 0},0, {1264, 624},{0x40, 0x92, 0x7, 0xFF}}},
	{{{265, -55, 0},0, {1264, 624},{0x6E, 0xC4, 0x18, 0xFF}}},
	{{{212, -70, 128},0, {1264, 752},{0x3F, 0x92, 0xFE, 0xFF}}},
	{{{274, -49, 200},0, {1264, 752},{0x2F, 0x1A, 0x73, 0xFF}}},
	{{{255, 10, 136},0, {1264, 880},{0x29, 0x1E, 0x74, 0xFF}}},
	{{{188, -10, 104},0, {1264, 880},{0xED, 0x31, 0x74, 0xFF}}},
	{{{216, -77, 182},0, {1136, 752},{0x4D, 0x2, 0x65, 0xFF}}},
	{{{88, -109, 0},0, {1136, 624},{0x5E, 0xB1, 0x22, 0xFF}}},
	{{{265, -55, 0},0, {1520, 496},{0x6E, 0xC4, 0x18, 0xFF}}},
	{{{255, 10, 136},0, {1776, 368},{0x29, 0x1E, 0x74, 0xFF}}},
	{{{274, -49, 200},0, {1776, 496},{0x2F, 0x1A, 0x73, 0xFF}}},
	{{{285, 73, 0},0, {1520, 368},{0x6D, 0x42, 0xFE, 0xFF}}},
	{{{258, 10, -94},0, {1776, 368},{0x53, 0xF, 0xA1, 0xFF}}},
	{{{258, -49, -84},0, {1776, 496},{0x5E, 0xCB, 0xBD, 0xFF}}},
	{{{242, 95, -86},0, {1776, 240},{0x30, 0x64, 0xC2, 0xFF}}},
	{{{285, 73, 0},0, {1520, 368},{0x6D, 0x42, 0xFE, 0xFF}}},
	{{{242, 95, -86},0, {1776, 240},{0x30, 0x64, 0xC2, 0xFF}}},
	{{{242, 121, 0},0, {1520, 240},{0xFF, 0x7A, 0x23, 0xFF}}},
	{{{242, 95, 86},0, {1776, 240},{0x2A, 0x6F, 0x2D, 0xFF}}},
	{{{255, 10, 136},0, {1776, 368},{0x29, 0x1E, 0x74, 0xFF}}},
	{{{206, 72, -89},0, {535, 436},{0xEA, 0x4E, 0x9E, 0xFF}}},
	{{{109, 3, -102},0, {628, 654},{0x1, 0xF6, 0x81, 0xFF}}},
	{{{111, 73, -89},0, {534, 650},{0x15, 0x63, 0xB4, 0xFF}}},
	{{{68, 44, -113},0, {572, 749},{0xF2, 0x10, 0x83, 0xFF}}},
	{{{78, 90, -103},0, {529, 725},{0xE5, 0x5B, 0xAB, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_displaylist_vanish_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_displaylist_vanish_mesh_layer_5_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 4, 0),
	gsSP2Triangles(5, 6, 7, 0, 8, 9, 10, 0),
	gsSP2Triangles(8, 6, 11, 0, 5, 9, 12, 0),
	gsSP2Triangles(13, 14, 11, 0, 13, 15, 16, 0),
	gsSP2Triangles(17, 18, 19, 0, 17, 20, 21, 0),
	gsSP2Triangles(22, 23, 24, 0, 22, 24, 25, 0),
	gsSP2Triangles(26, 27, 28, 0, 26, 28, 29, 0),
	gsSP2Triangles(30, 29, 28, 0, 30, 28, 31, 0),
	gsSPVertex(mario_001_switch_vanish_000_displaylist_vanish_mesh_layer_5_vtx_0 + 32, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 3, 2, 0),
	gsSP2Triangles(1, 4, 3, 0, 5, 6, 7, 0),
	gsSP2Triangles(5, 7, 8, 0, 9, 5, 8, 0),
	gsSP2Triangles(9, 10, 5, 0, 11, 12, 13, 0),
	gsSP2Triangles(11, 14, 12, 0, 15, 14, 11, 0),
	gsSP2Triangles(15, 11, 16, 0, 17, 14, 15, 0),
	gsSP2Triangles(17, 12, 14, 0, 17, 18, 12, 0),
	gsSP2Triangles(17, 19, 18, 0, 17, 20, 19, 0),
	gsSP2Triangles(21, 20, 17, 0, 21, 17, 22, 0),
	gsSP2Triangles(17, 15, 22, 0, 23, 24, 25, 0),
	gsSP2Triangles(23, 26, 24, 0, 23, 27, 26, 0),
	gsSP2Triangles(26, 27, 28, 0, 27, 29, 28, 0),
	gsSP2Triangles(27, 30, 29, 0, 31, 29, 30, 0),
	gsSPVertex(mario_001_switch_vanish_000_displaylist_vanish_mesh_layer_5_vtx_0 + 64, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
	gsSP2Triangles(2, 3, 4, 0, 5, 4, 3, 0),
	gsSP2Triangles(5, 6, 4, 0, 7, 6, 5, 0),
	gsSP2Triangles(7, 8, 6, 0, 9, 6, 8, 0),
	gsSP2Triangles(9, 10, 6, 0, 11, 10, 9, 0),
	gsSP2Triangles(12, 11, 9, 0, 13, 11, 12, 0),
	gsSP2Triangles(13, 12, 14, 0, 15, 11, 13, 0),
	gsSP2Triangles(15, 16, 11, 0, 17, 16, 15, 0),
	gsSP2Triangles(17, 15, 18, 0, 19, 17, 18, 0),
	gsSP2Triangles(19, 18, 20, 0, 19, 20, 21, 0),
	gsSP2Triangles(19, 21, 22, 0, 22, 23, 19, 0),
	gsSP2Triangles(19, 23, 24, 0, 2, 24, 23, 0),
	gsSP2Triangles(2, 4, 24, 0, 4, 10, 24, 0),
	gsSP2Triangles(4, 6, 10, 0, 24, 10, 16, 0),
	gsSP2Triangles(11, 16, 10, 0, 24, 16, 17, 0),
	gsSP2Triangles(19, 24, 17, 0, 25, 26, 27, 0),
	gsSP2Triangles(25, 28, 26, 0, 25, 29, 28, 0),
	gsSP2Triangles(25, 30, 29, 0, 28, 29, 31, 0),
	gsSPVertex(mario_001_switch_vanish_000_displaylist_vanish_mesh_layer_5_vtx_0 + 96, 10, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(0, 3, 4, 0, 5, 6, 7, 0),
	gsSP2Triangles(8, 7, 6, 0, 8, 9, 7, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_002_switch_option_head__no_cap__mesh_layer_5_vtx_0[106] = {
	{{{62, 295, 0},0, {534, 926},{0xED, 0x7E, 0x0, 0xFF}}},
	{{{84, 79, -56},0, {637, 926},{0xED, 0x5F, 0xAE, 0xFF}}},
	{{{62, 85, 0},0, {637, 875},{0x8D, 0x36, 0x0, 0xFF}}},
	{{{62, 85, 0},0, {637, 926},{0x8D, 0x36, 0x0, 0xFF}}},
	{{{84, 79, 56},0, {637, 875},{0xED, 0x5F, 0x52, 0xFF}}},
	{{{78, 101, 103},0, {534, 926},{0xE7, 0x5B, 0x55, 0xFF}}},
	{{{-43, 66, 56},0, {637, 875},{0xA4, 0x3C, 0x41, 0xFF}}},
	{{{3, 40, 76},0, {637, 926},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{-18, -16, 0},0, {534, 926},{0xBC, 0x9C, 0x27, 0xFF}}},
	{{{3, 40, 76},0, {637, 875},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{-43, 66, 56},0, {637, 926},{0xA4, 0x3C, 0x41, 0xFF}}},
	{{{-44, 66, 0},0, {637, 926},{0x91, 0x39, 0x1A, 0xFF}}},
	{{{68, 56, 113},0, {637, 926},{0xF5, 0xC, 0x7E, 0xFF}}},
	{{{-43, 66, -56},0, {534, 926},{0x90, 0x30, 0xDC, 0xFF}}},
	{{{-18, -16, 0},0, {637, 875},{0xBC, 0x9C, 0x27, 0xFF}}},
	{{{3, 40, -76},0, {637, 875},{0xB0, 0xF9, 0x9D, 0xFF}}},
	{{{-18, -16, 0},0, {637, 926},{0xBC, 0x9C, 0x27, 0xFF}}},
	{{{3, 40, -76},0, {534, 926},{0xB0, 0xF9, 0x9D, 0xFF}}},
	{{{-43, 66, -56},0, {637, 875},{0x90, 0x30, 0xDC, 0xFF}}},
	{{{78, 101, -103},0, {637, 926},{0xE5, 0x5B, 0xAB, 0xFF}}},
	{{{78, 101, -103},0, {637, 875},{0xE5, 0x5B, 0xAB, 0xFF}}},
	{{{68, 56, -113},0, {637, 926},{0xF2, 0x10, 0x83, 0xFF}}},
	{{{125, 89, 0},0, {549, 436},{0x7A, 0x25, 0x0, 0xFF}}},
	{{{84, 79, -56},0, {511, 798},{0xED, 0x5F, 0xAE, 0xFF}}},
	{{{62, 295, 0},0, {549, 798},{0xED, 0x7E, 0x0, 0xFF}}},
	{{{84, 79, 56},0, {587, 798},{0xED, 0x5F, 0x52, 0xFF}}},
	{{{-6, -16, 65},0, {240, 496},{0xD8, 0xB6, 0x5F, 0xFF}}},
	{{{3, 40, 76},0, {240, 368},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{-18, -16, 0},0, {496, 368},{0xBC, 0x9C, 0x27, 0xFF}}},
	{{{83, -93, 145},0, {496, 496},{0x57, 0x25, 0x55, 0xFF}}},
	{{{-6, -16, 0},0, {240, 496},{0xD1, 0xA6, 0xB4, 0xFF}}},
	{{{3, 40, -76},0, {240, 368},{0xB0, 0xF9, 0x9D, 0xFF}}},
	{{{206, 83, 89},0, {535, 436},{0xD1, 0x57, 0x50, 0xFF}}},
	{{{111, 84, 89},0, {534, 650},{0x18, 0x62, 0x4E, 0xFF}}},
	{{{109, 14, 102},0, {628, 654},{0xF5, 0x5, 0x7E, 0xFF}}},
	{{{68, 56, 113},0, {572, 749},{0xF5, 0xC, 0x7E, 0xFF}}},
	{{{78, 101, 103},0, {529, 725},{0xE7, 0x5B, 0x55, 0xFF}}},
	{{{206, 91, 0},0, {1264, 112},{0xC7, 0x72, 0x0, 0xFF}}},
	{{{206, 83, 89},0, {1264, -16},{0xD1, 0x57, 0x50, 0xFF}}},
	{{{242, 107, 86},0, {1264, -16},{0x2A, 0x6F, 0x2D, 0xFF}}},
	{{{242, 132, 0},0, {1264, 112},{0xFF, 0x7A, 0x23, 0xFF}}},
	{{{242, 107, -86},0, {1264, -16},{0x30, 0x64, 0xC2, 0xFF}}},
	{{{206, 83, -89},0, {1264, -16},{0xEA, 0x4E, 0x9E, 0xFF}}},
	{{{206, 91, 0},0, {1008, 448},{0xC7, 0x72, 0x0, 0xFF}}},
	{{{111, 84, 89},0, {672, 652},{0x18, 0x62, 0x4E, 0xFF}}},
	{{{206, 83, 89},0, {670, 444},{0xD1, 0x57, 0x50, 0xFF}}},
	{{{111, 96, 0},0, {1008, 652},{0xD, 0x7E, 0xE, 0xFF}}},
	{{{111, 84, -89},0, {1344, 652},{0x15, 0x63, 0xB4, 0xFF}}},
	{{{206, 83, -89},0, {1346, 444},{0xEA, 0x4E, 0x9E, 0xFF}}},
	{{{78, 101, 0},0, {1008, 723},{0xE8, 0x7D, 0x3, 0xFF}}},
	{{{78, 101, 103},0, {620, 723},{0xE7, 0x5B, 0x55, 0xFF}}},
	{{{-43, 66, 56},0, {799, 939},{0xA4, 0x3C, 0x41, 0xFF}}},
	{{{-44, 66, 0},0, {1008, 940},{0x91, 0x39, 0x1A, 0xFF}}},
	{{{-43, 66, -56},0, {1217, 939},{0x90, 0x30, 0xDC, 0xFF}}},
	{{{78, 101, -103},0, {1396, 723},{0xE5, 0x5B, 0xAB, 0xFF}}},
	{{{206, 83, 89},0, {1264, 1008},{0xD1, 0x57, 0x50, 0xFF}}},
	{{{255, 21, 136},0, {1264, 880},{0x29, 0x1E, 0x74, 0xFF}}},
	{{{242, 107, 86},0, {1264, 1008},{0x2A, 0x6F, 0x2D, 0xFF}}},
	{{{188, 2, 104},0, {1264, 880},{0xED, 0x31, 0x74, 0xFF}}},
	{{{109, 14, 102},0, {1136, 880},{0xF5, 0x5, 0x7E, 0xFF}}},
	{{{216, -66, 182},0, {1136, 752},{0x4D, 0x2, 0x65, 0xFF}}},
	{{{88, -60, 77},0, {1008, 752},{0x1, 0xF5, 0x7F, 0xFF}}},
	{{{68, 56, 113},0, {1008, 880},{0xF5, 0xC, 0x7E, 0xFF}}},
	{{{3, 40, 76},0, {752, 880},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{3, 40, 76},0, {752, 880},{0xD5, 0xD4, 0x6F, 0xFF}}},
	{{{-6, -16, 65},0, {752, 752},{0xD8, 0xB6, 0x5F, 0xFF}}},
	{{{88, -60, 77},0, {1008, 752},{0x1, 0xF5, 0x7F, 0xFF}}},
	{{{83, -93, 145},0, {752, 624},{0x57, 0x25, 0x55, 0xFF}}},
	{{{83, -157, 0},0, {1008, 624},{0x52, 0xA6, 0xDC, 0xFF}}},
	{{{-6, -16, 0},0, {752, 752},{0xD1, 0xA6, 0xB4, 0xFF}}},
	{{{60, -60, -77},0, {1008, 752},{0xC9, 0xBF, 0xA1, 0xFF}}},
	{{{3, 40, -76},0, {752, 880},{0xB0, 0xF9, 0x9D, 0xFF}}},
	{{{68, 56, -113},0, {1008, 880},{0xF2, 0x10, 0x83, 0xFF}}},
	{{{109, 14, -102},0, {1136, 880},{0x1, 0xF6, 0x81, 0xFF}}},
	{{{88, -66, -82},0, {1136, 752},{0xFC, 0xBE, 0x93, 0xFF}}},
	{{{188, 2, -104},0, {1264, 880},{0x3, 0x0, 0x81, 0xFF}}},
	{{{206, 83, -89},0, {1264, 1008},{0xEA, 0x4E, 0x9E, 0xFF}}},
	{{{258, 21, -94},0, {1264, 880},{0x53, 0xF, 0xA1, 0xFF}}},
	{{{242, 107, -86},0, {1264, 1008},{0x30, 0x64, 0xC2, 0xFF}}},
	{{{258, -38, -84},0, {1264, 752},{0x5E, 0xCB, 0xBD, 0xFF}}},
	{{{201, -88, -92},0, {1264, 752},{0x2A, 0xB4, 0xA4, 0xFF}}},
	{{{199, -118, 0},0, {1264, 624},{0x40, 0x92, 0x7, 0xFF}}},
	{{{266, -44, 0},0, {1264, 624},{0x6E, 0xC4, 0x18, 0xFF}}},
	{{{212, -59, 128},0, {1264, 752},{0x3F, 0x92, 0xFE, 0xFF}}},
	{{{274, -38, 200},0, {1264, 752},{0x2F, 0x1A, 0x73, 0xFF}}},
	{{{255, 21, 136},0, {1264, 880},{0x29, 0x1E, 0x74, 0xFF}}},
	{{{188, 2, 104},0, {1264, 880},{0xED, 0x31, 0x74, 0xFF}}},
	{{{216, -66, 182},0, {1136, 752},{0x4D, 0x2, 0x65, 0xFF}}},
	{{{88, -97, 0},0, {1136, 624},{0x5E, 0xB1, 0x22, 0xFF}}},
	{{{266, -44, 0},0, {1520, 496},{0x6E, 0xC4, 0x18, 0xFF}}},
	{{{255, 21, 136},0, {1776, 368},{0x29, 0x1E, 0x74, 0xFF}}},
	{{{274, -38, 200},0, {1776, 496},{0x2F, 0x1A, 0x73, 0xFF}}},
	{{{285, 84, 0},0, {1520, 368},{0x6D, 0x42, 0xFE, 0xFF}}},
	{{{258, 21, -94},0, {1776, 368},{0x53, 0xF, 0xA1, 0xFF}}},
	{{{258, -38, -84},0, {1776, 496},{0x5E, 0xCB, 0xBD, 0xFF}}},
	{{{242, 107, -86},0, {1776, 240},{0x30, 0x64, 0xC2, 0xFF}}},
	{{{285, 84, 0},0, {1520, 368},{0x6D, 0x42, 0xFE, 0xFF}}},
	{{{242, 107, -86},0, {1776, 240},{0x30, 0x64, 0xC2, 0xFF}}},
	{{{242, 132, 0},0, {1520, 240},{0xFF, 0x7A, 0x23, 0xFF}}},
	{{{242, 107, 86},0, {1776, 240},{0x2A, 0x6F, 0x2D, 0xFF}}},
	{{{255, 21, 136},0, {1776, 368},{0x29, 0x1E, 0x74, 0xFF}}},
	{{{206, 83, -89},0, {535, 436},{0xEA, 0x4E, 0x9E, 0xFF}}},
	{{{109, 14, -102},0, {628, 654},{0x1, 0xF6, 0x81, 0xFF}}},
	{{{111, 84, -89},0, {534, 650},{0x15, 0x63, 0xB4, 0xFF}}},
	{{{68, 56, -113},0, {572, 749},{0xF2, 0x10, 0x83, 0xFF}}},
	{{{78, 101, -103},0, {529, 725},{0xE5, 0x5B, 0xAB, 0xFF}}},
};

Gfx mario_001_switch_vanish_002_switch_option_head__no_cap__mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_002_switch_option_head__no_cap__mesh_layer_5_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 4, 0),
	gsSP2Triangles(5, 6, 7, 0, 8, 9, 10, 0),
	gsSP2Triangles(8, 6, 11, 0, 5, 9, 12, 0),
	gsSP2Triangles(13, 14, 11, 0, 13, 15, 16, 0),
	gsSP2Triangles(17, 18, 19, 0, 17, 20, 21, 0),
	gsSP2Triangles(22, 23, 24, 0, 22, 24, 25, 0),
	gsSP2Triangles(26, 27, 28, 0, 26, 28, 29, 0),
	gsSP2Triangles(30, 29, 28, 0, 30, 28, 31, 0),
	gsSPVertex(mario_001_switch_vanish_002_switch_option_head__no_cap__mesh_layer_5_vtx_0 + 32, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 3, 2, 0),
	gsSP2Triangles(1, 4, 3, 0, 5, 6, 7, 0),
	gsSP2Triangles(5, 7, 8, 0, 9, 5, 8, 0),
	gsSP2Triangles(9, 10, 5, 0, 11, 12, 13, 0),
	gsSP2Triangles(11, 14, 12, 0, 15, 14, 11, 0),
	gsSP2Triangles(15, 11, 16, 0, 17, 14, 15, 0),
	gsSP2Triangles(17, 12, 14, 0, 17, 18, 12, 0),
	gsSP2Triangles(17, 19, 18, 0, 17, 20, 19, 0),
	gsSP2Triangles(21, 20, 17, 0, 21, 17, 22, 0),
	gsSP2Triangles(17, 15, 22, 0, 23, 24, 25, 0),
	gsSP2Triangles(23, 26, 24, 0, 23, 27, 26, 0),
	gsSP2Triangles(26, 27, 28, 0, 27, 29, 28, 0),
	gsSP2Triangles(27, 30, 29, 0, 31, 29, 30, 0),
	gsSPVertex(mario_001_switch_vanish_002_switch_option_head__no_cap__mesh_layer_5_vtx_0 + 64, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
	gsSP2Triangles(2, 3, 4, 0, 5, 4, 3, 0),
	gsSP2Triangles(5, 6, 4, 0, 7, 6, 5, 0),
	gsSP2Triangles(7, 8, 6, 0, 9, 6, 8, 0),
	gsSP2Triangles(9, 10, 6, 0, 11, 10, 9, 0),
	gsSP2Triangles(12, 11, 9, 0, 13, 11, 12, 0),
	gsSP2Triangles(13, 12, 14, 0, 15, 11, 13, 0),
	gsSP2Triangles(15, 16, 11, 0, 17, 16, 15, 0),
	gsSP2Triangles(17, 15, 18, 0, 19, 17, 18, 0),
	gsSP2Triangles(19, 18, 20, 0, 19, 20, 21, 0),
	gsSP2Triangles(19, 21, 22, 0, 22, 23, 19, 0),
	gsSP2Triangles(19, 23, 24, 0, 2, 24, 23, 0),
	gsSP2Triangles(2, 4, 24, 0, 4, 10, 24, 0),
	gsSP2Triangles(4, 6, 10, 0, 24, 10, 16, 0),
	gsSP2Triangles(11, 16, 10, 0, 24, 16, 17, 0),
	gsSP2Triangles(19, 24, 17, 0, 25, 26, 27, 0),
	gsSP2Triangles(25, 28, 26, 0, 25, 29, 28, 0),
	gsSP2Triangles(25, 30, 29, 0, 28, 29, 31, 0),
	gsSPVertex(mario_001_switch_vanish_002_switch_option_head__no_cap__mesh_layer_5_vtx_0 + 96, 10, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(0, 3, 4, 0, 5, 6, 7, 0),
	gsSP2Triangles(8, 7, 6, 0, 8, 9, 7, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_displaylist_001_vanish_mesh_layer_5_vtx_0[4] = {
	{{{172, -31, 2},0, {-16, 2030},{0x5, 0x1E, 0x7B, 0xFF}}},
	{{{347, 32, -21},0, {1006, 2030},{0x6, 0x1E, 0x7B, 0xFF}}},
	{{{211, 374, -98},0, {1006, -34},{0x5, 0x1E, 0x7B, 0xFF}}},
	{{{38, 311, -75},0, {-16, -34},{0x4, 0x1E, 0x7B, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_displaylist_001_vanish_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_displaylist_001_vanish_mesh_layer_5_vtx_0 + 0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_displaylist_001_vanish_mesh_layer_5_vtx_1[4] = {
	{{{-136, 247, -53},0, {-16, -34},{0x4, 0x1E, 0x7B, 0xFF}}},
	{{{172, -31, 2},0, {1006, 2030},{0x5, 0x1E, 0x7B, 0xFF}}},
	{{{38, 311, -75},0, {1006, -34},{0x4, 0x1E, 0x7B, 0xFF}}},
	{{{-1, -95, 25},0, {-16, 2030},{0x4, 0x1E, 0x7B, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_displaylist_001_vanish_mesh_layer_5_tri_1[] = {
	gsSPVertex(mario_001_switch_vanish_000_displaylist_001_vanish_mesh_layer_5_vtx_1 + 0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_displaylist_002_vanish_mesh_layer_5_vtx_0[4] = {
	{{{173, -31, -1},0, {-16, 2030},{0xFB, 0xE2, 0x7B, 0xFF}}},
	{{{348, 32, 23},0, {1006, 2030},{0xFA, 0xE2, 0x7B, 0xFF}}},
	{{{212, 374, 99},0, {1006, -34},{0xFB, 0xE2, 0x7B, 0xFF}}},
	{{{39, 311, 77},0, {-16, -34},{0xFC, 0xE2, 0x7B, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_displaylist_002_vanish_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_displaylist_002_vanish_mesh_layer_5_vtx_0 + 0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_displaylist_002_vanish_mesh_layer_5_vtx_1[4] = {
	{{{-135, 247, 54},0, {-16, -34},{0xFC, 0xE2, 0x7B, 0xFF}}},
	{{{0, -95, -23},0, {-16, 2030},{0xFC, 0xE2, 0x7B, 0xFF}}},
	{{{173, -31, -1},0, {1006, 2030},{0xFB, 0xE2, 0x7B, 0xFF}}},
	{{{39, 311, 77},0, {1006, -34},{0xFC, 0xE2, 0x7B, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_displaylist_002_vanish_mesh_layer_5_tri_1[] = {
	gsSPVertex(mario_001_switch_vanish_000_displaylist_002_vanish_mesh_layer_5_vtx_1 + 0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_003_vanish_skinned_mesh_layer_5_vtx_0[12] = {
	{{{71, 29, 101},0, {271, 93},{0x3F, 0x36, 0x60, 0xFF}}},
	{{{-32, 20, 94},0, {495, 197},{0xF6, 0x2E, 0x76, 0xFF}}},
	{{{-32, 20, 94},0, {1272, 151},{0xF6, 0x2E, 0x76, 0xFF}}},
	{{{71, 29, 101},0, {1544, 1008},{0x3F, 0x36, 0x60, 0xFF}}},
	{{{72, -58, 91},0, {66, 195},{0x3F, 0xBA, 0x56, 0xFF}}},
	{{{-32, 20, 94},0, {1556, 518},{0xF6, 0x2E, 0x76, 0xFF}}},
	{{{-33, -47, 87},0, {1352, 518},{0xF8, 0xB9, 0x69, 0xFF}}},
	{{{72, -58, 91},0, {191, 62},{0x3F, 0xBA, 0x56, 0xFF}}},
	{{{-33, -47, 87},0, {30, 195},{0xF8, 0xB9, 0x69, 0xFF}}},
	{{{71, 29, 101},0, {1128, 485},{0x3F, 0x36, 0x60, 0xFF}}},
	{{{71, 29, 101},0, {1172, 946},{0x3F, 0x36, 0x60, 0xFF}}},
	{{{72, -58, 91},0, {1434, 946},{0x3F, 0xBA, 0x56, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_003_vanish_skinned_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_003_vanish_skinned_mesh_layer_5_vtx_0 + 0, 12, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_003_vanish_mesh_layer_5_vtx_0[12] = {
	{{{5, -29, -68},0, {495, 60},{0xD6, 0xA7, 0xAF, 0xFF}}},
	{{{1, 36, -68},0, {1272, 3},{0xC7, 0x50, 0xB0, 0xFF}}},
	{{{5, -29, -68},0, {1148, 79},{0xD6, 0xA7, 0xAF, 0xFF}}},
	{{{1, 36, -68},0, {1360, 610},{0xC7, 0x50, 0xB0, 0xFF}}},
	{{{1, 36, -68},0, {-16, 62},{0xC7, 0x50, 0xB0, 0xFF}}},
	{{{4, 46, 32},0, {1398, 1008},{0xB5, 0x49, 0x48, 0xFF}}},
	{{{5, -29, -68},0, {1777, 988},{0xD6, 0xA7, 0xAF, 0xFF}}},
	{{{10, -37, 31},0, {1499, 933},{0xB8, 0xB2, 0x47, 0xFF}}},
	{{{4, 46, 32},0, {-16, 270},{0xB5, 0x49, 0x48, 0xFF}}},
	{{{1, 36, -68},0, {271, 217},{0xC7, 0x50, 0xB0, 0xFF}}},
	{{{10, -37, 31},0, {1128, 430},{0xB8, 0xB2, 0x47, 0xFF}}},
	{{{4, 46, 32},0, {876, 435},{0xB5, 0x49, 0x48, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_003_vanish_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_003_vanish_mesh_layer_5_vtx_0 + 0, 12, 12),
	gsSP2Triangles(0, 1, 12, 0, 2, 13, 14, 0),
	gsSP2Triangles(5, 6, 15, 0, 7, 16, 8, 0),
	gsSP2Triangles(10, 17, 11, 0, 3, 18, 19, 0),
	gsSP2Triangles(4, 20, 21, 0, 9, 22, 23, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_003_vanish_mesh_layer_5_vtx_1[19] = {
	{{{10, -37, 31},0, {1499, 933},{0xB8, 0xB2, 0x47, 0xFF}}},
	{{{5, -29, -68},0, {1777, 988},{0xD6, 0xA7, 0xAF, 0xFF}}},
	{{{54, -23, -50},0, {1777, 907},{0x2A, 0xAD, 0xA9, 0xFF}}},
	{{{58, -28, 27},0, {1558, 865},{0x17, 0xA5, 0x55, 0xFF}}},
	{{{1, 36, -68},0, {1753, 70},{0xC7, 0x50, 0xB0, 0xFF}}},
	{{{54, -23, -50},0, {1939, 149},{0x2A, 0xAD, 0xA9, 0xFF}}},
	{{{5, -29, -68},0, {1951, 70},{0xD6, 0xA7, 0xAF, 0xFF}}},
	{{{67, 29, -45},0, {1783, 173},{0x27, 0x54, 0xA9, 0xFF}}},
	{{{70, 4, -44},0, {1860, 176},{0x2A, 0x1, 0x88, 0xFF}}},
	{{{4, 46, 32},0, {-16, 270},{0xB5, 0x49, 0x48, 0xFF}}},
	{{{67, 29, -45},0, {271, 322},{0x27, 0x54, 0xA9, 0xFF}}},
	{{{1, 36, -68},0, {271, 217},{0xC7, 0x50, 0xB0, 0xFF}}},
	{{{67, 35, 27},0, {65, 359},{0x17, 0x5C, 0x55, 0xFF}}},
	{{{58, -28, 27},0, {1106, 357},{0x17, 0xA5, 0x55, 0xFF}}},
	{{{4, 46, 32},0, {876, 435},{0xB5, 0x49, 0x48, 0xFF}}},
	{{{10, -37, 31},0, {1128, 430},{0xB8, 0xB2, 0x47, 0xFF}}},
	{{{67, 35, 27},0, {915, 340},{0xB, 0x0, 0x7F, 0xFF}}},
	{{{72, 5, 26},0, {1006, 335},{0xA, 0x0, 0x7F, 0xFF}}},
	{{{67, 35, 27},0, {914, 340},{0x17, 0x5C, 0x55, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_003_vanish_mesh_layer_5_tri_1[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_003_vanish_mesh_layer_5_vtx_1 + 0, 19, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 7, 5, 0),
	gsSP2Triangles(7, 8, 5, 0, 9, 10, 11, 0),
	gsSP2Triangles(9, 12, 10, 0, 13, 14, 15, 0),
	gsSP2Triangles(14, 13, 16, 0, 13, 17, 16, 0),
	gsSP1Triangle(14, 16, 18, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_004_vanish_skinned_mesh_layer_5_vtx_0[11] = {
	{{{70, 4, -44},0, {1860, 176},{0x2A, 0x1, 0x88, 0xFF}}},
	{{{54, -23, -50},0, {1939, 149},{0x2A, 0xAD, 0xA9, 0xFF}}},
	{{{58, -28, 27},0, {1558, 865},{0x17, 0xA5, 0x55, 0xFF}}},
	{{{54, -23, -50},0, {1777, 907},{0x2A, 0xAD, 0xA9, 0xFF}}},
	{{{67, 35, 27},0, {65, 359},{0x17, 0x5C, 0x55, 0xFF}}},
	{{{67, 35, 27},0, {915, 340},{0xB, 0x0, 0x7F, 0xFF}}},
	{{{72, 5, 26},0, {1006, 335},{0xA, 0x0, 0x7F, 0xFF}}},
	{{{67, 35, 27},0, {914, 340},{0x17, 0x5C, 0x55, 0xFF}}},
	{{{67, 29, -45},0, {1783, 173},{0x27, 0x54, 0xA9, 0xFF}}},
	{{{67, 29, -45},0, {271, 322},{0x27, 0x54, 0xA9, 0xFF}}},
	{{{58, -28, 27},0, {1106, 357},{0x17, 0xA5, 0x55, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_004_vanish_skinned_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_004_vanish_skinned_mesh_layer_5_vtx_0 + 0, 11, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_004_vanish_mesh_layer_5_vtx_0[8] = {
	{{{17, -18, -37},0, {1931, 206},{0x29, 0xAD, 0xA9, 0xFF}}},
	{{{-1, 28, -43},0, {1786, 181},{0x27, 0x54, 0xA9, 0xFF}}},
	{{{17, -18, -37},0, {1777, 849},{0x29, 0xAD, 0xA9, 0xFF}}},
	{{{19, -22, 25},0, {1601, 817},{0x17, 0xA6, 0x57, 0xFF}}},
	{{{-1, 34, 26},0, {917, 332},{0x16, 0x5B, 0x55, 0xFF}}},
	{{{19, -22, 25},0, {1090, 305},{0x17, 0xA6, 0x57, 0xFF}}},
	{{{-1, 28, -43},0, {271, 331},{0x27, 0x54, 0xA9, 0xFF}}},
	{{{-1, 34, 26},0, {72, 366},{0x16, 0x5B, 0x55, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_004_vanish_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_004_vanish_mesh_layer_5_vtx_0 + 0, 8, 11),
	gsSP2Triangles(0, 11, 1, 0, 12, 11, 0, 0),
	gsSP2Triangles(8, 12, 0, 0, 2, 3, 13, 0),
	gsSP2Triangles(2, 13, 14, 0, 5, 15, 7, 0),
	gsSP2Triangles(5, 6, 15, 0, 16, 15, 6, 0),
	gsSP2Triangles(10, 16, 6, 0, 4, 17, 9, 0),
	gsSP1Triangle(4, 18, 17, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_004_vanish_mesh_layer_5_vtx_1[20] = {
	{{{88, 19, -12},0, {1827, 323},{0x58, 0x47, 0xC6, 0xFF}}},
	{{{17, -18, -37},0, {1931, 206},{0x29, 0xAD, 0xA9, 0xFF}}},
	{{{-1, 28, -43},0, {1786, 181},{0x27, 0x54, 0xA9, 0xFF}}},
	{{{90, -9, -11},0, {1914, 324},{0x5D, 0xBF, 0xC7, 0xFF}}},
	{{{19, -22, 25},0, {1601, 817},{0x17, 0xA6, 0x57, 0xFF}}},
	{{{17, -18, -37},0, {1777, 849},{0x29, 0xAD, 0xA9, 0xFF}}},
	{{{90, -9, -11},0, {1777, 731},{0x5D, 0xBF, 0xC7, 0xFF}}},
	{{{89, -9, 19},0, {1689, 717},{0x54, 0xC2, 0x49, 0xFF}}},
	{{{-1, 34, 26},0, {72, 366},{0x16, 0x5B, 0x55, 0xFF}}},
	{{{88, 19, -12},0, {271, 476},{0x58, 0x47, 0xC6, 0xFF}}},
	{{{-1, 28, -43},0, {271, 331},{0x27, 0x54, 0xA9, 0xFF}}},
	{{{86, 19, 19},0, {182, 489},{0x4D, 0x46, 0x49, 0xFF}}},
	{{{86, 19, 19},0, {970, 200},{0x4D, 0x46, 0x49, 0xFF}}},
	{{{-1, 34, 26},0, {917, 332},{0x16, 0x5B, 0x55, 0xFF}}},
	{{{19, -22, 25},0, {1090, 305},{0x17, 0xA6, 0x57, 0xFF}}},
	{{{89, -9, 19},0, {1057, 198},{0x54, 0xC2, 0x49, 0xFF}}},
	{{{90, -9, -11},0, {1683, 717},{0x5D, 0xBF, 0xC7, 0xFF}}},
	{{{86, 19, 19},0, {1770, 671},{0x4D, 0x46, 0x49, 0xFF}}},
	{{{89, -9, 19},0, {1683, 671},{0x54, 0xC2, 0x49, 0xFF}}},
	{{{88, 19, -12},0, {1770, 717},{0x58, 0x47, 0xC6, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_004_vanish_mesh_layer_5_tri_1[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_004_vanish_mesh_layer_5_vtx_1 + 0, 20, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 0, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 11, 9, 0),
	gsSP2Triangles(12, 13, 14, 0, 15, 12, 14, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 19, 17, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_displaylist_003_vanish_mesh_layer_5_vtx_0[32] = {
	{{{1, 27, 21},0, {1264, 240},{0xAD, 0x41, 0x47, 0xFF}}},
	{{{4, 27, -14},0, {752, 240},{0xA9, 0x43, 0xC0, 0xFF}}},
	{{{4, -18, -14},0, {752, -16},{0xA9, 0xBD, 0xC0, 0xFF}}},
	{{{1, -18, 21},0, {1264, -16},{0xAD, 0xBF, 0x47, 0xFF}}},
	{{{25, 32, 21},0, {1008, 1008},{0x5, 0x5D, 0x57, 0xFF}}},
	{{{1, 27, 21},0, {752, 1008},{0xAD, 0x41, 0x47, 0xFF}}},
	{{{1, -18, 21},0, {752, 752},{0xAD, 0xBF, 0x47, 0xFF}}},
	{{{25, -23, 21},0, {1008, 752},{0x5, 0xA3, 0x57, 0xFF}}},
	{{{49, -18, 17},0, {1264, 752},{0x54, 0xBE, 0x45, 0xFF}}},
	{{{49, 27, 17},0, {1264, 1008},{0x54, 0x42, 0x45, 0xFF}}},
	{{{25, 32, 21},0, {752, 368},{0x5, 0x5D, 0x57, 0xFF}}},
	{{{4, 27, -14},0, {240, 240},{0xA9, 0x43, 0xC0, 0xFF}}},
	{{{1, 27, 21},0, {752, 240},{0xAD, 0x41, 0x47, 0xFF}}},
	{{{27, 32, -22},0, {240, 368},{0xFA, 0x59, 0xA5, 0xFF}}},
	{{{49, 27, 17},0, {752, 496},{0x54, 0x42, 0x45, 0xFF}}},
	{{{50, 27, -18},0, {240, 496},{0x57, 0x41, 0xBE, 0xFF}}},
	{{{4, 27, -14},0, {1264, 752},{0xA9, 0x43, 0xC0, 0xFF}}},
	{{{27, -23, -22},0, {1008, 496},{0xFA, 0xA7, 0xA5, 0xFF}}},
	{{{4, -18, -14},0, {1264, 496},{0xA9, 0xBD, 0xC0, 0xFF}}},
	{{{27, 32, -22},0, {1008, 752},{0xFA, 0x59, 0xA5, 0xFF}}},
	{{{50, -18, -18},0, {752, 496},{0x57, 0xBF, 0xBE, 0xFF}}},
	{{{50, 27, -18},0, {752, 752},{0x57, 0x41, 0xBE, 0xFF}}},
	{{{4, -18, -14},0, {752, 496},{0xA9, 0xBD, 0xC0, 0xFF}}},
	{{{25, -23, 21},0, {1264, 368},{0x5, 0xA3, 0x57, 0xFF}}},
	{{{1, -18, 21},0, {1264, 496},{0xAD, 0xBF, 0x47, 0xFF}}},
	{{{27, -23, -22},0, {752, 368},{0xFA, 0xA7, 0xA5, 0xFF}}},
	{{{49, -18, 17},0, {1264, 240},{0x54, 0xBE, 0x45, 0xFF}}},
	{{{50, -18, -18},0, {752, 240},{0x57, 0xBF, 0xBE, 0xFF}}},
	{{{49, -18, 17},0, {1776, 496},{0x54, 0xBE, 0x45, 0xFF}}},
	{{{50, 27, -18},0, {1264, 240},{0x57, 0x41, 0xBE, 0xFF}}},
	{{{49, 27, 17},0, {1776, 240},{0x54, 0x42, 0x45, 0xFF}}},
	{{{50, -18, -18},0, {1264, 496},{0x57, 0xBF, 0xBE, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_displaylist_003_vanish_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_displaylist_003_vanish_mesh_layer_5_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(4, 7, 8, 0, 4, 8, 9, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 13, 11, 0),
	gsSP2Triangles(14, 13, 10, 0, 14, 15, 13, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 19, 17, 0),
	gsSP2Triangles(19, 20, 17, 0, 19, 21, 20, 0),
	gsSP2Triangles(22, 23, 24, 0, 22, 25, 23, 0),
	gsSP2Triangles(25, 26, 23, 0, 25, 27, 26, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 31, 29, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_002_switch_option_right_hand_open_mesh_layer_5_vtx_0[40] = {
	{{{27, 40, 15},0, {1008, 1008},{0xEB, 0x58, 0x5A, 0xFF}}},
	{{{5, 28, 17},0, {752, 1008},{0xA5, 0x25, 0x51, 0xFF}}},
	{{{19, -16, 16},0, {752, 752},{0xDB, 0xAD, 0x59, 0xFF}}},
	{{{81, 52, 6},0, {752, 496},{0x3B, 0x5A, 0x43, 0xFF}}},
	{{{81, 52, -12},0, {240, 496},{0x35, 0x5D, 0xBB, 0xFF}}},
	{{{26, 40, -18},0, {240, 368},{0xE3, 0x5B, 0xAC, 0xFF}}},
	{{{27, 40, 15},0, {752, 368},{0xEB, 0x58, 0x5A, 0xFF}}},
	{{{5, 29, -18},0, {240, 240},{0xA0, 0x29, 0xB7, 0xFF}}},
	{{{5, 28, 17},0, {752, 240},{0xA5, 0x25, 0x51, 0xFF}}},
	{{{95, 8, 4},0, {1264, 752},{0x65, 0xD3, 0x3F, 0xFF}}},
	{{{81, 52, 6},0, {1264, 1008},{0x3B, 0x5A, 0x43, 0xFF}}},
	{{{43, -13, 13},0, {1008, 752},{0x35, 0xD0, 0x69, 0xFF}}},
	{{{95, 8, 4},0, {1776, 496},{0x65, 0xD3, 0x3F, 0xFF}}},
	{{{81, 52, -12},0, {1264, 240},{0x35, 0x5D, 0xBB, 0xFF}}},
	{{{81, 52, 6},0, {1776, 240},{0x3B, 0x5A, 0x43, 0xFF}}},
	{{{94, 9, -13},0, {1264, 496},{0x5F, 0xD6, 0xB6, 0xFF}}},
	{{{26, 40, -18},0, {1008, 752},{0xE3, 0x5B, 0xAC, 0xFF}}},
	{{{81, 52, -12},0, {752, 752},{0x35, 0x5D, 0xBB, 0xFF}}},
	{{{94, 9, -13},0, {752, 496},{0x5F, 0xD6, 0xB6, 0xFF}}},
	{{{42, -12, -19},0, {1008, 496},{0x2B, 0xD3, 0x91, 0xFF}}},
	{{{42, -12, -19},0, {752, 368},{0x2B, 0xD3, 0x91, 0xFF}}},
	{{{94, 9, -13},0, {752, 240},{0x5F, 0xD6, 0xB6, 0xFF}}},
	{{{95, 8, 4},0, {1264, 240},{0x65, 0xD3, 0x3F, 0xFF}}},
	{{{43, -13, 13},0, {1264, 368},{0x35, 0xD0, 0x69, 0xFF}}},
	{{{19, -16, 16},0, {753, 752},{0xDB, 0xAD, 0x59, 0xFF}}},
	{{{43, -13, 13},0, {1008, 819},{0x35, 0xD0, 0x69, 0xFF}}},
	{{{47, -26, 4},0, {1008, 752},{0x53, 0xA6, 0x22, 0xFF}}},
	{{{42, -12, -19},0, {1081, 569},{0x2B, 0xD3, 0x91, 0xFF}}},
	{{{47, -26, 4},0, {1264, 368},{0x53, 0xA6, 0x22, 0xFF}}},
	{{{46, -26, -11},0, {1008, 496},{0x4F, 0xA7, 0xD3, 0xFF}}},
	{{{18, -14, -19},0, {1264, 496},{0xBA, 0xBC, 0xAE, 0xFF}}},
	{{{5, 29, -18},0, {1264, 752},{0xA0, 0x29, 0xB7, 0xFF}}},
	{{{5, 28, 17},0, {1264, 240},{0xA5, 0x25, 0x51, 0xFF}}},
	{{{5, 29, -18},0, {752, 240},{0xA0, 0x29, 0xB7, 0xFF}}},
	{{{18, -14, -19},0, {752, -16},{0xBA, 0xBC, 0xAE, 0xFF}}},
	{{{19, -16, 16},0, {1264, -16},{0xDB, 0xAD, 0x59, 0xFF}}},
	{{{18, -14, -19},0, {752, 496},{0xBA, 0xBC, 0xAE, 0xFF}}},
	{{{47, -26, 4},0, {1264, 368},{0x53, 0xA6, 0x22, 0xFF}}},
	{{{19, -16, 16},0, {1264, 496},{0xDB, 0xAD, 0x59, 0xFF}}},
	{{{46, -26, -11},0, {752, 368},{0x4F, 0xA7, 0xD3, 0xFF}}},
};

Gfx mario_001_switch_vanish_002_switch_option_right_hand_open_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_002_switch_option_right_hand_open_mesh_layer_5_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(3, 5, 6, 0, 6, 5, 7, 0),
	gsSP2Triangles(6, 7, 8, 0, 0, 9, 10, 0),
	gsSP2Triangles(0, 11, 9, 0, 12, 13, 14, 0),
	gsSP2Triangles(12, 15, 13, 0, 16, 17, 18, 0),
	gsSP2Triangles(16, 18, 19, 0, 20, 21, 22, 0),
	gsSP2Triangles(20, 22, 23, 0, 0, 24, 25, 0),
	gsSP2Triangles(25, 24, 26, 0, 27, 25, 28, 0),
	gsSP2Triangles(27, 28, 29, 0, 30, 27, 29, 0),
	gsSP2Triangles(31, 27, 30, 0, 31, 16, 27, 0),
	gsSPVertex(mario_001_switch_vanish_002_switch_option_right_hand_open_mesh_layer_5_vtx_0 + 32, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 7, 5, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_006_vanish_skinned_mesh_layer_5_vtx_0[12] = {
	{{{72, -58, -91},0, {351, 489},{0x3F, 0xBB, 0xAA, 0xFF}}},
	{{{71, 29, -101},0, {1809, 324},{0x3F, 0x34, 0x9F, 0xFF}}},
	{{{71, 29, -101},0, {1244, 642},{0x3F, 0x34, 0x9F, 0xFF}}},
	{{{72, -58, -91},0, {1499, 672},{0x3F, 0xBB, 0xAA, 0xFF}}},
	{{{71, 29, -101},0, {876, 163},{0x3F, 0x34, 0x9F, 0xFF}}},
	{{{-32, 20, -94},0, {1099, 59},{0xF6, 0x2E, 0x8A, 0xFF}}},
	{{{-32, 20, -94},0, {1477, 3},{0xF6, 0x2E, 0x8A, 0xFF}}},
	{{{71, 29, -101},0, {640, 196},{0x3F, 0x34, 0x9F, 0xFF}}},
	{{{-32, 20, -94},0, {1352, 243},{0xF6, 0x2E, 0x8A, 0xFF}}},
	{{{-33, -47, -87},0, {1148, 243},{0xF8, 0xB9, 0x97, 0xFF}}},
	{{{72, -58, -91},0, {595, 60},{0x3F, 0xBB, 0xAA, 0xFF}}},
	{{{-33, -47, -87},0, {746, 196},{0xF8, 0xB9, 0x97, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_006_vanish_skinned_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_006_vanish_skinned_mesh_layer_5_vtx_0 + 0, 12, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_006_vanish_mesh_layer_5_vtx_0[12] = {
	{{{4, 46, -31},0, {1493, 610},{0xB5, 0x49, 0xB8, 0xFF}}},
	{{{5, -29, 69},0, {1099, 198},{0xD7, 0xA7, 0x51, 0xFF}}},
	{{{5, -29, 69},0, {1352, 76},{0xD7, 0xA7, 0x51, 0xFF}}},
	{{{1, 36, 69},0, {1477, 152},{0xC7, 0x51, 0x50, 0xFF}}},
	{{{1, 36, 69},0, {1156, 151},{0xC7, 0x51, 0x50, 0xFF}}},
	{{{1, 36, 69},0, {798, 60},{0xC7, 0x51, 0x50, 0xFF}}},
	{{{1, 36, 69},0, {558, 469},{0xC7, 0x51, 0x50, 0xFF}}},
	{{{4, 46, -31},0, {271, 416},{0xB5, 0x49, 0xB8, 0xFF}}},
	{{{4, 46, -31},0, {1556, 372},{0xB5, 0x49, 0xB8, 0xFF}}},
	{{{10, -37, -30},0, {1809, 377},{0xB9, 0xB2, 0xB9, 0xFF}}},
	{{{10, -37, -30},0, {595, 269},{0xB9, 0xB2, 0xB9, 0xFF}}},
	{{{5, -29, 69},0, {876, 213},{0xD7, 0xA7, 0x51, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_006_vanish_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_006_vanish_mesh_layer_5_vtx_0 + 0, 12, 12),
	gsSP2Triangles(2, 3, 12, 0, 4, 13, 5, 0),
	gsSP2Triangles(6, 14, 15, 0, 8, 16, 9, 0),
	gsSP2Triangles(10, 11, 17, 0, 0, 18, 19, 0),
	gsSP2Triangles(1, 20, 21, 0, 7, 22, 23, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_006_vanish_mesh_layer_5_vtx_1[19] = {
	{{{58, -28, -26},0, {1787, 450},{0x17, 0xA5, 0xAB, 0xFF}}},
	{{{10, -37, -30},0, {1809, 377},{0xB9, 0xB2, 0xB9, 0xFF}}},
	{{{4, 46, -31},0, {1556, 372},{0xB5, 0x49, 0xB8, 0xFF}}},
	{{{67, 35, -26},0, {1596, 468},{0xB, 0x0, 0x81, 0xFF}}},
	{{{67, 35, -26},0, {1595, 468},{0x17, 0x5C, 0xAB, 0xFF}}},
	{{{72, 5, -25},0, {1687, 473},{0xA, 0x0, 0x81, 0xFF}}},
	{{{4, 46, -31},0, {271, 416},{0xB5, 0x49, 0xB8, 0xFF}}},
	{{{1, 36, 69},0, {558, 469},{0xC7, 0x51, 0x50, 0xFF}}},
	{{{67, 29, 46},0, {558, 363},{0x27, 0x54, 0x57, 0xFF}}},
	{{{67, 35, -26},0, {352, 327},{0x17, 0x5C, 0xAB, 0xFF}}},
	{{{1, 36, 69},0, {1753, 70},{0xC7, 0x51, 0x50, 0xFF}}},
	{{{5, -29, 69},0, {1556, 70},{0xD7, 0xA7, 0x51, 0xFF}}},
	{{{54, -23, 51},0, {1568, 149},{0x2A, 0xAD, 0x57, 0xFF}}},
	{{{67, 29, 46},0, {1723, 173},{0x27, 0x54, 0x57, 0xFF}}},
	{{{70, 4, 45},0, {1647, 176},{0x2A, 0x1, 0x78, 0xFF}}},
	{{{10, -37, -30},0, {595, 269},{0xB9, 0xB2, 0xB9, 0xFF}}},
	{{{54, -23, 51},0, {876, 294},{0x2A, 0xAD, 0x57, 0xFF}}},
	{{{5, -29, 69},0, {876, 213},{0xD7, 0xA7, 0x51, 0xFF}}},
	{{{58, -28, -26},0, {655, 337},{0x17, 0xA5, 0xAB, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_006_vanish_mesh_layer_5_tri_1[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_006_vanish_mesh_layer_5_vtx_1 + 0, 19, 0),
	gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
	gsSP2Triangles(2, 4, 3, 0, 0, 3, 5, 0),
	gsSP2Triangles(6, 7, 8, 0, 6, 8, 9, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 12, 13, 0),
	gsSP2Triangles(13, 12, 14, 0, 15, 16, 17, 0),
	gsSP1Triangle(15, 18, 16, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_007_vanish_skinned_mesh_layer_5_vtx_0[11] = {
	{{{58, -28, -26},0, {1787, 450},{0x17, 0xA5, 0xAB, 0xFF}}},
	{{{72, 5, -25},0, {1687, 473},{0xA, 0x0, 0x81, 0xFF}}},
	{{{58, -28, -26},0, {655, 337},{0x17, 0xA5, 0xAB, 0xFF}}},
	{{{70, 4, 45},0, {1647, 176},{0x2A, 0x1, 0x78, 0xFF}}},
	{{{54, -23, 51},0, {1568, 149},{0x2A, 0xAD, 0x57, 0xFF}}},
	{{{54, -23, 51},0, {876, 294},{0x2A, 0xAD, 0x57, 0xFF}}},
	{{{67, 35, -26},0, {352, 327},{0x17, 0x5C, 0xAB, 0xFF}}},
	{{{67, 35, -26},0, {1596, 468},{0xB, 0x0, 0x81, 0xFF}}},
	{{{67, 35, -26},0, {1595, 468},{0x17, 0x5C, 0xAB, 0xFF}}},
	{{{67, 29, 46},0, {1723, 173},{0x27, 0x54, 0x57, 0xFF}}},
	{{{67, 29, 46},0, {558, 363},{0x27, 0x54, 0x57, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_007_vanish_skinned_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_007_vanish_skinned_mesh_layer_5_vtx_0 + 0, 11, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_007_vanish_mesh_layer_5_vtx_0[8] = {
	{{{19, -22, -24},0, {1771, 502},{0x17, 0xA6, 0xA9, 0xFF}}},
	{{{-1, 34, -25},0, {1598, 476},{0x16, 0x5B, 0xAB, 0xFF}}},
	{{{17, -18, 38},0, {1576, 206},{0x29, 0xAD, 0x57, 0xFF}}},
	{{{-1, 28, 44},0, {1721, 181},{0x27, 0x54, 0x57, 0xFF}}},
	{{{17, -18, 38},0, {876, 352},{0x29, 0xAD, 0x57, 0xFF}}},
	{{{19, -22, -24},0, {699, 385},{0x17, 0xA6, 0xA9, 0xFF}}},
	{{{-1, 28, 44},0, {558, 354},{0x27, 0x54, 0x57, 0xFF}}},
	{{{-1, 34, -25},0, {359, 319},{0x16, 0x5B, 0xAB, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_007_vanish_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_007_vanish_mesh_layer_5_vtx_0 + 0, 8, 11),
	gsSP2Triangles(0, 1, 11, 0, 11, 1, 12, 0),
	gsSP2Triangles(7, 12, 1, 0, 7, 8, 12, 0),
	gsSP2Triangles(3, 4, 13, 0, 14, 3, 13, 0),
	gsSP2Triangles(9, 3, 14, 0, 2, 15, 5, 0),
	gsSP2Triangles(2, 16, 15, 0, 6, 10, 17, 0),
	gsSP1Triangle(6, 17, 18, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_007_vanish_mesh_layer_5_vtx_1[20] = {
	{{{19, -22, -24},0, {699, 385},{0x17, 0xA6, 0xA9, 0xFF}}},
	{{{90, -9, 12},0, {876, 471},{0x5D, 0xBF, 0x39, 0xFF}}},
	{{{17, -18, 38},0, {876, 352},{0x29, 0xAD, 0x57, 0xFF}}},
	{{{89, -9, -18},0, {788, 485},{0x54, 0xC2, 0xB7, 0xFF}}},
	{{{17, -18, 38},0, {1576, 206},{0x29, 0xAD, 0x57, 0xFF}}},
	{{{90, -9, 12},0, {1593, 324},{0x5D, 0xBF, 0x39, 0xFF}}},
	{{{88, 19, 13},0, {1680, 323},{0x58, 0x47, 0x3A, 0xFF}}},
	{{{-1, 28, 44},0, {1721, 181},{0x27, 0x54, 0x57, 0xFF}}},
	{{{90, -9, 12},0, {1683, 625},{0x5D, 0xBF, 0x39, 0xFF}}},
	{{{86, 19, -18},0, {1770, 670},{0x4D, 0x46, 0xB7, 0xFF}}},
	{{{88, 19, 13},0, {1770, 625},{0x58, 0x47, 0x3A, 0xFF}}},
	{{{89, -9, -18},0, {1683, 671},{0x54, 0xC2, 0xB7, 0xFF}}},
	{{{89, -9, -18},0, {1738, 610},{0x54, 0xC2, 0xB7, 0xFF}}},
	{{{19, -22, -24},0, {1771, 502},{0x17, 0xA6, 0xA9, 0xFF}}},
	{{{86, 19, -18},0, {1651, 607},{0x4D, 0x46, 0xB7, 0xFF}}},
	{{{-1, 34, -25},0, {1598, 476},{0x16, 0x5B, 0xAB, 0xFF}}},
	{{{-1, 34, -25},0, {359, 319},{0x16, 0x5B, 0xAB, 0xFF}}},
	{{{88, 19, 13},0, {558, 209},{0x58, 0x47, 0x3A, 0xFF}}},
	{{{86, 19, -18},0, {470, 197},{0x4D, 0x46, 0xB7, 0xFF}}},
	{{{-1, 28, 44},0, {558, 354},{0x27, 0x54, 0x57, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_007_vanish_mesh_layer_5_tri_1[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_007_vanish_mesh_layer_5_vtx_1 + 0, 20, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 6, 7, 4, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 11, 9, 0),
	gsSP2Triangles(12, 13, 14, 0, 14, 13, 15, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 19, 17, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_displaylist_004_vanish_mesh_layer_5_vtx_0[32] = {
	{{{-1, 27, -20},0, {1264, 240},{0xAD, 0x41, 0xB9, 0xFF}}},
	{{{2, -18, 15},0, {752, -16},{0xA9, 0xBD, 0x40, 0xFF}}},
	{{{2, 27, 15},0, {752, 240},{0xA9, 0x43, 0x40, 0xFF}}},
	{{{-1, -18, -20},0, {1264, -16},{0xAD, 0xBF, 0xB9, 0xFF}}},
	{{{23, 32, -20},0, {1008, 1008},{0x5, 0x5D, 0xA9, 0xFF}}},
	{{{-1, -18, -20},0, {752, 752},{0xAD, 0xBF, 0xB9, 0xFF}}},
	{{{-1, 27, -20},0, {752, 1008},{0xAD, 0x41, 0xB9, 0xFF}}},
	{{{23, -23, -20},0, {1008, 752},{0x5, 0xA3, 0xA9, 0xFF}}},
	{{{46, -18, -16},0, {1264, 752},{0x54, 0xBE, 0xBB, 0xFF}}},
	{{{46, 27, -16},0, {1264, 1008},{0x54, 0x42, 0xBB, 0xFF}}},
	{{{23, 32, -20},0, {752, 368},{0x5, 0x5D, 0xA9, 0xFF}}},
	{{{-1, 27, -20},0, {752, 240},{0xAD, 0x41, 0xB9, 0xFF}}},
	{{{2, 27, 15},0, {240, 240},{0xA9, 0x43, 0x40, 0xFF}}},
	{{{25, 32, 23},0, {240, 368},{0xFA, 0x59, 0x5B, 0xFF}}},
	{{{46, 27, -16},0, {752, 496},{0x54, 0x42, 0xBB, 0xFF}}},
	{{{48, 27, 19},0, {240, 496},{0x57, 0x41, 0x42, 0xFF}}},
	{{{2, 27, 15},0, {1264, 752},{0xA9, 0x43, 0x40, 0xFF}}},
	{{{2, -18, 15},0, {1264, 496},{0xA9, 0xBD, 0x40, 0xFF}}},
	{{{25, -23, 23},0, {1008, 496},{0xFA, 0xA7, 0x5B, 0xFF}}},
	{{{25, 32, 23},0, {1008, 752},{0xFA, 0x59, 0x5B, 0xFF}}},
	{{{48, -18, 19},0, {752, 496},{0x57, 0xBF, 0x42, 0xFF}}},
	{{{48, 27, 19},0, {752, 752},{0x57, 0x41, 0x42, 0xFF}}},
	{{{2, -18, 15},0, {752, 496},{0xA9, 0xBD, 0x40, 0xFF}}},
	{{{-1, -18, -20},0, {1264, 496},{0xAD, 0xBF, 0xB9, 0xFF}}},
	{{{23, -23, -20},0, {1264, 368},{0x5, 0xA3, 0xA9, 0xFF}}},
	{{{25, -23, 23},0, {752, 368},{0xFA, 0xA7, 0x5B, 0xFF}}},
	{{{46, -18, -16},0, {1264, 240},{0x54, 0xBE, 0xBB, 0xFF}}},
	{{{48, -18, 19},0, {752, 240},{0x57, 0xBF, 0x42, 0xFF}}},
	{{{46, -18, -16},0, {1776, 496},{0x54, 0xBE, 0xBB, 0xFF}}},
	{{{46, 27, -16},0, {1776, 240},{0x54, 0x42, 0xBB, 0xFF}}},
	{{{48, 27, 19},0, {1264, 240},{0x57, 0x41, 0x42, 0xFF}}},
	{{{48, -18, 19},0, {1264, 496},{0x57, 0xBF, 0x42, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_displaylist_004_vanish_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_displaylist_004_vanish_mesh_layer_5_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 7, 5, 0),
	gsSP2Triangles(4, 8, 7, 0, 4, 9, 8, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 12, 13, 0),
	gsSP2Triangles(14, 10, 13, 0, 14, 13, 15, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
	gsSP2Triangles(19, 18, 20, 0, 19, 20, 21, 0),
	gsSP2Triangles(22, 23, 24, 0, 22, 24, 25, 0),
	gsSP2Triangles(25, 24, 26, 0, 25, 26, 27, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 30, 31, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_002_switch_option_left_hand_open_mesh_layer_5_vtx_0[40] = {
	{{{36, 40, -20},0, {1008, 1008},{0xEB, 0x58, 0xA6, 0xFF}}},
	{{{27, -16, -20},0, {752, 752},{0xC0, 0xB8, 0xAE, 0xFF}}},
	{{{14, 28, -22},0, {752, 1008},{0xA5, 0x25, 0xAF, 0xFF}}},
	{{{90, 52, -10},0, {752, 496},{0x3B, 0x5A, 0xBD, 0xFF}}},
	{{{34, 40, 13},0, {240, 368},{0xE3, 0x5B, 0x54, 0xFF}}},
	{{{89, 52, 7},0, {240, 496},{0x35, 0x5D, 0x45, 0xFF}}},
	{{{36, 40, -20},0, {752, 368},{0xEB, 0x58, 0xA6, 0xFF}}},
	{{{13, 29, 13},0, {240, 240},{0xA0, 0x29, 0x49, 0xFF}}},
	{{{14, 28, -22},0, {752, 240},{0xA5, 0x25, 0xAF, 0xFF}}},
	{{{90, 52, -10},0, {1264, 1008},{0x3B, 0x5A, 0xBD, 0xFF}}},
	{{{103, 8, -9},0, {1264, 752},{0x65, 0xD3, 0xC1, 0xFF}}},
	{{{52, -13, -18},0, {1008, 752},{0x35, 0xD0, 0x97, 0xFF}}},
	{{{103, 8, -9},0, {1776, 496},{0x65, 0xD3, 0xC1, 0xFF}}},
	{{{90, 52, -10},0, {1776, 240},{0x3B, 0x5A, 0xBD, 0xFF}}},
	{{{89, 52, 7},0, {1264, 240},{0x35, 0x5D, 0x45, 0xFF}}},
	{{{102, 9, 9},0, {1264, 496},{0x5F, 0xD6, 0x4A, 0xFF}}},
	{{{34, 40, 13},0, {1008, 752},{0xE3, 0x5B, 0x54, 0xFF}}},
	{{{102, 9, 9},0, {752, 496},{0x5F, 0xD6, 0x4A, 0xFF}}},
	{{{89, 52, 7},0, {752, 752},{0x35, 0x5D, 0x45, 0xFF}}},
	{{{50, -12, 14},0, {1008, 496},{0x2B, 0xD3, 0x6F, 0xFF}}},
	{{{50, -12, 14},0, {752, 368},{0x2B, 0xD3, 0x6F, 0xFF}}},
	{{{103, 8, -9},0, {1264, 240},{0x65, 0xD3, 0xC1, 0xFF}}},
	{{{102, 9, 9},0, {752, 240},{0x5F, 0xD6, 0x4A, 0xFF}}},
	{{{52, -13, -18},0, {1264, 368},{0x35, 0xD0, 0x97, 0xFF}}},
	{{{52, -13, -18},0, {1008, 819},{0x35, 0xD0, 0x97, 0xFF}}},
	{{{27, -16, -20},0, {753, 752},{0xC0, 0xB8, 0xAE, 0xFF}}},
	{{{55, -26, -9},0, {1008, 752},{0x53, 0xA6, 0xDE, 0xFF}}},
	{{{50, -12, 14},0, {1081, 569},{0x2B, 0xD3, 0x6F, 0xFF}}},
	{{{55, -26, -9},0, {1264, 368},{0x53, 0xA6, 0xDE, 0xFF}}},
	{{{55, -26, 6},0, {1008, 496},{0x4F, 0xA7, 0x2D, 0xFF}}},
	{{{27, -14, 15},0, {1264, 496},{0xBA, 0xBC, 0x52, 0xFF}}},
	{{{13, 29, 13},0, {1264, 752},{0xA0, 0x29, 0x49, 0xFF}}},
	{{{14, 28, -22},0, {1264, 240},{0xA5, 0x25, 0xAF, 0xFF}}},
	{{{27, -14, 15},0, {752, -16},{0xBA, 0xBC, 0x52, 0xFF}}},
	{{{13, 29, 13},0, {752, 240},{0xA0, 0x29, 0x49, 0xFF}}},
	{{{27, -16, -20},0, {1264, -16},{0xC0, 0xB8, 0xAE, 0xFF}}},
	{{{27, -14, 15},0, {752, 496},{0xBA, 0xBC, 0x52, 0xFF}}},
	{{{27, -16, -20},0, {1264, 496},{0xC0, 0xB8, 0xAE, 0xFF}}},
	{{{55, -26, -9},0, {1264, 368},{0x53, 0xA6, 0xDE, 0xFF}}},
	{{{55, -26, 6},0, {752, 368},{0x4F, 0xA7, 0x2D, 0xFF}}},
};

Gfx mario_001_switch_vanish_002_switch_option_left_hand_open_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_002_switch_option_left_hand_open_mesh_layer_5_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(3, 6, 4, 0, 6, 7, 4, 0),
	gsSP2Triangles(6, 8, 7, 0, 0, 9, 10, 0),
	gsSP2Triangles(0, 10, 11, 0, 12, 13, 14, 0),
	gsSP2Triangles(12, 14, 15, 0, 16, 17, 18, 0),
	gsSP2Triangles(16, 19, 17, 0, 20, 21, 22, 0),
	gsSP2Triangles(20, 23, 21, 0, 0, 24, 25, 0),
	gsSP2Triangles(24, 26, 25, 0, 27, 28, 24, 0),
	gsSP2Triangles(27, 29, 28, 0, 30, 29, 27, 0),
	gsSP2Triangles(31, 30, 27, 0, 31, 27, 16, 0),
	gsSPVertex(mario_001_switch_vanish_002_switch_option_left_hand_open_mesh_layer_5_vtx_0 + 32, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_004_switch_option_left_hand_peace_mesh_layer_1_vtx_0[35] = {
	{{{110, -48, -29},0, {1349, 240},{0x1D, 0xA6, 0xAB, 0xFF}}},
	{{{114, -57, 9},0, {1179, -16},{0x28, 0x8C, 0x20, 0xFF}}},
	{{{73, -55, -11},0, {1008, 240},{0xCA, 0x92, 0xDF, 0xFF}}},
	{{{95, -5, -52},0, {1349, 496},{0x6, 0xE8, 0x83, 0xFF}}},
	{{{42, -16, -27},0, {1008, 496},{0x9D, 0xD0, 0xC1, 0xFF}}},
	{{{70, -45, 23},0, {667, 240},{0xC6, 0xAB, 0x4A, 0xFF}}},
	{{{114, -57, 9},0, {837, -16},{0x28, 0x8C, 0x20, 0xFF}}},
	{{{38, -2, 21},0, {667, 496},{0x97, 0xEB, 0x44, 0xFF}}},
	{{{105, -28, 40},0, {325, 240},{0x11, 0xD4, 0x76, 0xFF}}},
	{{{114, -57, 9},0, {496, -16},{0x28, 0x8C, 0x20, 0xFF}}},
	{{{88, 23, 45},0, {325, 496},{0xFA, 0x18, 0x7D, 0xFF}}},
	{{{142, -20, 22},0, {-16, 240},{0x65, 0xE2, 0x47, 0xFF}}},
	{{{114, -57, 9},0, {155, -16},{0x28, 0x8C, 0x20, 0xFF}}},
	{{{140, 33, 20},0, {-16, 496},{0x63, 0x30, 0x3F, 0xFF}}},
	{{{72, 65, 21},0, {325, 752},{0xE3, 0x5A, 0x55, 0xFF}}},
	{{{110, 72, 4},0, {-16, 752},{0x36, 0x6E, 0x21, 0xFF}}},
	{{{68, 74, -17},0, {155, 1008},{0xD8, 0x74, 0xE0, 0xFF}}},
	{{{38, 48, 5},0, {667, 752},{0x93, 0x36, 0x25, 0xFF}}},
	{{{40, 38, -29},0, {1008, 752},{0x9B, 0x1E, 0xB9, 0xFF}}},
	{{{68, 74, -17},0, {837, 1008},{0xD8, 0x74, 0xE0, 0xFF}}},
	{{{77, 45, -47},0, {1349, 752},{0xEF, 0x2C, 0x8A, 0xFF}}},
	{{{68, 74, -17},0, {1179, 1008},{0xD8, 0x74, 0xE0, 0xFF}}},
	{{{112, 63, -31},0, {1691, 752},{0x3A, 0x55, 0xB6, 0xFF}}},
	{{{68, 74, -17},0, {1520, 1008},{0xD8, 0x74, 0xE0, 0xFF}}},
	{{{144, 19, -29},0, {1691, 496},{0x69, 0x15, 0xBC, 0xFF}}},
	{{{110, 72, 4},0, {2032, 752},{0x36, 0x6E, 0x21, 0xFF}}},
	{{{68, 74, -17},0, {1861, 1008},{0xD8, 0x74, 0xE0, 0xFF}}},
	{{{140, 33, 20},0, {2032, 496},{0x63, 0x30, 0x3F, 0xFF}}},
	{{{145, -30, -12},0, {1691, 240},{0x6D, 0xCA, 0xDB, 0xFF}}},
	{{{142, -20, 22},0, {2032, 240},{0x65, 0xE2, 0x47, 0xFF}}},
	{{{114, -57, 9},0, {1861, -16},{0x28, 0x8C, 0x20, 0xFF}}},
	{{{114, -57, 9},0, {1520, -16},{0x28, 0x8C, 0x20, 0xFF}}},
	{{{68, 74, -17},0, {496, 1008},{0xD8, 0x74, 0xE0, 0xFF}}},
	{{{38, 48, 5},0, {667, 752},{0x93, 0x36, 0x25, 0xFF}}},
	{{{72, 65, 21},0, {325, 752},{0xE3, 0x5A, 0x55, 0xFF}}},
};

Gfx mario_001_switch_vanish_004_switch_option_left_hand_peace_mesh_layer_1_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_004_switch_option_left_hand_peace_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
	gsSP2Triangles(3, 2, 4, 0, 4, 2, 5, 0),
	gsSP2Triangles(2, 6, 5, 0, 4, 5, 7, 0),
	gsSP2Triangles(7, 5, 8, 0, 5, 9, 8, 0),
	gsSP2Triangles(7, 8, 10, 0, 10, 8, 11, 0),
	gsSP2Triangles(8, 12, 11, 0, 10, 11, 13, 0),
	gsSP2Triangles(14, 10, 13, 0, 14, 13, 15, 0),
	gsSP2Triangles(16, 14, 15, 0, 17, 10, 14, 0),
	gsSP2Triangles(17, 7, 10, 0, 18, 7, 17, 0),
	gsSP2Triangles(19, 18, 17, 0, 18, 4, 7, 0),
	gsSP2Triangles(20, 4, 18, 0, 21, 20, 18, 0),
	gsSP2Triangles(20, 3, 4, 0, 22, 3, 20, 0),
	gsSP2Triangles(23, 22, 20, 0, 22, 24, 3, 0),
	gsSP2Triangles(25, 24, 22, 0, 26, 25, 22, 0),
	gsSP2Triangles(25, 27, 24, 0, 27, 28, 24, 0),
	gsSP2Triangles(27, 29, 28, 0, 29, 30, 28, 0),
	gsSP2Triangles(24, 28, 0, 0, 28, 31, 0, 0),
	gsSP1Triangle(24, 0, 3, 0),
	gsSPVertex(mario_001_switch_vanish_004_switch_option_left_hand_peace_mesh_layer_1_vtx_0 + 32, 3, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_004_switch_option_left_hand_peace_mesh_layer_4_vtx_0[8] = {
	{{{85, 188, -47},0, {0, 1024},{0xFA, 0x19, 0x7C, 0xFF}}},
	{{{141, 28, -11},0, {1536, 1024},{0xFA, 0x19, 0x7C, 0xFF}}},
	{{{235, 60, -13},0, {1536, 0},{0xFA, 0x19, 0x7C, 0xFF}}},
	{{{179, 221, -48},0, {0, 0},{0xFA, 0x19, 0x7C, 0xFF}}},
	{{{139, 33, 4},0, {1536, 1024},{0x6, 0xE7, 0x84, 0xFF}}},
	{{{233, 66, 3},0, {1536, 0},{0x6, 0xE7, 0x84, 0xFF}}},
	{{{289, -95, 38},0, {0, 0},{0x6, 0xE7, 0x84, 0xFF}}},
	{{{195, -127, 40},0, {0, 1024},{0x6, 0xE7, 0x84, 0xFF}}},
};

Gfx mario_001_switch_vanish_004_switch_option_left_hand_peace_mesh_layer_4_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_004_switch_option_left_hand_peace_mesh_layer_4_vtx_0 + 0, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_004_switch_option_left_hand_peace_mesh_layer_5_vtx_0[32] = {
	{{{-10, 32, 33},0, {1264, 240},{0xA1, 0x2E, 0x47, 0xFF}}},
	{{{-6, 33, -2},0, {752, 240},{0xA0, 0x34, 0xBE, 0xFF}}},
	{{{4, -11, -2},0, {752, -16},{0xB7, 0xAB, 0xC4, 0xFF}}},
	{{{7, -12, 33},0, {1264, -16},{0xCB, 0xAA, 0x4D, 0xFF}}},
	{{{20, 42, 33},0, {1008, 1008},{0x18, 0x59, 0x58, 0xFF}}},
	{{{-10, 32, 33},0, {752, 1008},{0xA1, 0x2E, 0x47, 0xFF}}},
	{{{7, -12, 33},0, {752, 752},{0xCB, 0xAA, 0x4D, 0xFF}}},
	{{{25, -11, 33},0, {1008, 752},{0x2F, 0xB1, 0x58, 0xFF}}},
	{{{48, -2, 9},0, {1264, 752},{0x6F, 0xCE, 0x26, 0xFF}}},
	{{{38, 43, 9},0, {1264, 1008},{0x50, 0x5D, 0x21, 0xFF}}},
	{{{20, 42, 33},0, {752, 368},{0x18, 0x59, 0x58, 0xFF}}},
	{{{-6, 33, -2},0, {240, 240},{0xA0, 0x34, 0xBE, 0xFF}}},
	{{{-10, 32, 33},0, {752, 240},{0xA1, 0x2E, 0x47, 0xFF}}},
	{{{21, 43, -10},0, {240, 368},{0xF0, 0x57, 0xA5, 0xFF}}},
	{{{38, 43, 9},0, {752, 496},{0x50, 0x5D, 0x21, 0xFF}}},
	{{{39, 43, -6},0, {240, 496},{0x49, 0x54, 0xC2, 0xFF}}},
	{{{-6, 33, -2},0, {1264, 752},{0xA0, 0x34, 0xBE, 0xFF}}},
	{{{27, -11, -10},0, {1008, 496},{0xC, 0xA7, 0xA6, 0xFF}}},
	{{{4, -11, -2},0, {1264, 496},{0xB7, 0xAB, 0xC4, 0xFF}}},
	{{{21, 43, -10},0, {1008, 752},{0xF0, 0x57, 0xA5, 0xFF}}},
	{{{49, -1, -6},0, {752, 496},{0x64, 0xD3, 0xC0, 0xFF}}},
	{{{39, 43, -6},0, {752, 752},{0x49, 0x54, 0xC2, 0xFF}}},
	{{{4, -11, -2},0, {752, 496},{0xB7, 0xAB, 0xC4, 0xFF}}},
	{{{25, -11, 33},0, {1264, 368},{0x2F, 0xB1, 0x58, 0xFF}}},
	{{{7, -12, 33},0, {1264, 496},{0xCB, 0xAA, 0x4D, 0xFF}}},
	{{{27, -11, -10},0, {752, 368},{0xC, 0xA7, 0xA6, 0xFF}}},
	{{{48, -2, 9},0, {1264, 240},{0x6F, 0xCE, 0x26, 0xFF}}},
	{{{49, -1, -6},0, {752, 240},{0x64, 0xD3, 0xC0, 0xFF}}},
	{{{48, -2, 9},0, {1776, 496},{0x6F, 0xCE, 0x26, 0xFF}}},
	{{{39, 43, -6},0, {1264, 240},{0x49, 0x54, 0xC2, 0xFF}}},
	{{{38, 43, 9},0, {1776, 240},{0x50, 0x5D, 0x21, 0xFF}}},
	{{{49, -1, -6},0, {1264, 496},{0x64, 0xD3, 0xC0, 0xFF}}},
};

Gfx mario_001_switch_vanish_004_switch_option_left_hand_peace_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_004_switch_option_left_hand_peace_mesh_layer_5_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(4, 7, 8, 0, 4, 8, 9, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 13, 11, 0),
	gsSP2Triangles(14, 13, 10, 0, 14, 15, 13, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 19, 17, 0),
	gsSP2Triangles(19, 20, 17, 0, 19, 21, 20, 0),
	gsSP2Triangles(22, 23, 24, 0, 22, 25, 23, 0),
	gsSP2Triangles(25, 26, 23, 0, 25, 27, 26, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 31, 29, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_005_switch_option_left_hand_cap_mesh_layer_4_vtx_0[8] = {
	{{{94, 5, 30},0, {543, 372},{0x7B, 0xF1, 0xE2, 0xFF}}},
	{{{79, -79, 9},0, {880, 372},{0x51, 0xA8, 0xD4, 0xFF}}},
	{{{60, -53, -81},0, {880, 12},{0x51, 0xA8, 0xD4, 0xFF}}},
	{{{75, 31, -60},0, {543, 12},{0x7B, 0xF1, 0xE2, 0xFF}}},
	{{{94, 5, 30},0, {481, 372},{0x7B, 0xF1, 0xE2, 0xFF}}},
	{{{75, 31, -60},0, {481, 12},{0x7B, 0xF1, 0xE2, 0xFF}}},
	{{{91, 115, -39},0, {144, 12},{0x6D, 0x41, 0xFA, 0xFF}}},
	{{{110, 89, 51},0, {144, 372},{0x6D, 0x41, 0xFA, 0xFF}}},
};

Gfx mario_001_switch_vanish_005_switch_option_left_hand_cap_mesh_layer_4_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_005_switch_option_left_hand_cap_mesh_layer_4_vtx_0 + 0, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_005_switch_option_left_hand_cap_mesh_layer_5_vtx_0[32] = {
	{{{4, 33, 20},0, {1264, 240},{0xA1, 0x2E, 0x47, 0xFF}}},
	{{{8, 33, -15},0, {752, 240},{0x9D, 0x2F, 0xC0, 0xFF}}},
	{{{17, -11, -15},0, {752, -16},{0xB9, 0xAC, 0xC0, 0xFF}}},
	{{{14, -12, 20},0, {1264, -16},{0xBC, 0xAF, 0x47, 0xFF}}},
	{{{27, 42, 20},0, {1008, 1008},{0xF2, 0x5C, 0x57, 0xFF}}},
	{{{4, 33, 20},0, {752, 1008},{0xA1, 0x2E, 0x47, 0xFF}}},
	{{{14, -12, 20},0, {752, 752},{0xBC, 0xAF, 0x47, 0xFF}}},
	{{{39, -11, 20},0, {1008, 752},{0x19, 0xA6, 0x57, 0xFF}}},
	{{{60, -2, 16},0, {1264, 752},{0x60, 0xD2, 0x45, 0xFF}}},
	{{{51, 43, 16},0, {1264, 1008},{0x44, 0x52, 0x45, 0xFF}}},
	{{{27, 42, 20},0, {752, 368},{0xF2, 0x5C, 0x57, 0xFF}}},
	{{{8, 33, -15},0, {240, 240},{0x9D, 0x2F, 0xC0, 0xFF}}},
	{{{4, 33, 20},0, {752, 240},{0xA1, 0x2E, 0x47, 0xFF}}},
	{{{29, 43, -22},0, {240, 368},{0xE7, 0x56, 0xA5, 0xFF}}},
	{{{51, 43, 16},0, {752, 496},{0x44, 0x52, 0x45, 0xFF}}},
	{{{52, 43, -19},0, {240, 496},{0x47, 0x52, 0xBE, 0xFF}}},
	{{{8, 33, -15},0, {1264, 752},{0x9D, 0x2F, 0xC0, 0xFF}}},
	{{{40, -11, -22},0, {1008, 496},{0xC, 0xA8, 0xA6, 0xFF}}},
	{{{17, -11, -15},0, {1264, 496},{0xB9, 0xAC, 0xC0, 0xFF}}},
	{{{29, 43, -22},0, {1008, 752},{0xE7, 0x56, 0xA5, 0xFF}}},
	{{{62, -1, -19},0, {752, 496},{0x63, 0xD3, 0xBE, 0xFF}}},
	{{{52, 43, -19},0, {752, 752},{0x47, 0x52, 0xBE, 0xFF}}},
	{{{17, -11, -15},0, {752, 496},{0xB9, 0xAC, 0xC0, 0xFF}}},
	{{{39, -11, 20},0, {1264, 368},{0x19, 0xA6, 0x57, 0xFF}}},
	{{{14, -12, 20},0, {1264, 496},{0xBC, 0xAF, 0x47, 0xFF}}},
	{{{40, -11, -22},0, {752, 368},{0xC, 0xA8, 0xA6, 0xFF}}},
	{{{60, -2, 16},0, {1264, 240},{0x60, 0xD2, 0x45, 0xFF}}},
	{{{62, -1, -19},0, {752, 240},{0x63, 0xD3, 0xBE, 0xFF}}},
	{{{60, -2, 16},0, {1776, 496},{0x60, 0xD2, 0x45, 0xFF}}},
	{{{52, 43, -19},0, {1264, 240},{0x47, 0x52, 0xBE, 0xFF}}},
	{{{51, 43, 16},0, {1776, 240},{0x44, 0x52, 0x45, 0xFF}}},
	{{{62, -1, -19},0, {1264, 496},{0x63, 0xD3, 0xBE, 0xFF}}},
};

Gfx mario_001_switch_vanish_005_switch_option_left_hand_cap_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_005_switch_option_left_hand_cap_mesh_layer_5_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(4, 7, 8, 0, 4, 8, 9, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 13, 11, 0),
	gsSP2Triangles(14, 13, 10, 0, 14, 15, 13, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 19, 17, 0),
	gsSP2Triangles(19, 20, 17, 0, 19, 21, 20, 0),
	gsSP2Triangles(22, 23, 24, 0, 22, 25, 23, 0),
	gsSP2Triangles(25, 26, 23, 0, 25, 27, 26, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 31, 29, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_006_switch_option_left_hand_wing_cap_mesh_layer_4_vtx_0[8] = {
	{{{94, 5, 30},0, {543, 372},{0x7B, 0xF1, 0xE2, 0xFF}}},
	{{{79, -79, 9},0, {880, 372},{0x51, 0xA8, 0xD4, 0xFF}}},
	{{{60, -53, -81},0, {880, 12},{0x51, 0xA8, 0xD4, 0xFF}}},
	{{{75, 31, -60},0, {543, 12},{0x7B, 0xF1, 0xE2, 0xFF}}},
	{{{94, 5, 30},0, {481, 372},{0x7B, 0xF1, 0xE2, 0xFF}}},
	{{{75, 31, -60},0, {481, 12},{0x7B, 0xF1, 0xE2, 0xFF}}},
	{{{91, 115, -39},0, {144, 12},{0x6D, 0x41, 0xFA, 0xFF}}},
	{{{110, 89, 51},0, {144, 372},{0x6D, 0x41, 0xFA, 0xFF}}},
};

Gfx mario_001_switch_vanish_006_switch_option_left_hand_wing_cap_mesh_layer_4_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_006_switch_option_left_hand_wing_cap_mesh_layer_4_vtx_0 + 0, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_006_switch_option_left_hand_wing_cap_mesh_layer_5_vtx_0[32] = {
	{{{4, 33, 20},0, {1264, 240},{0xA1, 0x2E, 0x47, 0xFF}}},
	{{{8, 33, -15},0, {752, 240},{0x9D, 0x2F, 0xC0, 0xFF}}},
	{{{17, -11, -15},0, {752, -16},{0xB9, 0xAC, 0xC0, 0xFF}}},
	{{{14, -12, 20},0, {1264, -16},{0xBC, 0xAF, 0x47, 0xFF}}},
	{{{27, 42, 20},0, {1008, 1008},{0xF2, 0x5C, 0x57, 0xFF}}},
	{{{4, 33, 20},0, {752, 1008},{0xA1, 0x2E, 0x47, 0xFF}}},
	{{{14, -12, 20},0, {752, 752},{0xBC, 0xAF, 0x47, 0xFF}}},
	{{{39, -11, 20},0, {1008, 752},{0x19, 0xA6, 0x57, 0xFF}}},
	{{{60, -2, 16},0, {1264, 752},{0x60, 0xD2, 0x45, 0xFF}}},
	{{{51, 43, 16},0, {1264, 1008},{0x44, 0x52, 0x45, 0xFF}}},
	{{{27, 42, 20},0, {752, 368},{0xF2, 0x5C, 0x57, 0xFF}}},
	{{{8, 33, -15},0, {240, 240},{0x9D, 0x2F, 0xC0, 0xFF}}},
	{{{4, 33, 20},0, {752, 240},{0xA1, 0x2E, 0x47, 0xFF}}},
	{{{29, 43, -22},0, {240, 368},{0xE7, 0x56, 0xA5, 0xFF}}},
	{{{51, 43, 16},0, {752, 496},{0x44, 0x52, 0x45, 0xFF}}},
	{{{52, 43, -19},0, {240, 496},{0x47, 0x52, 0xBE, 0xFF}}},
	{{{8, 33, -15},0, {1264, 752},{0x9D, 0x2F, 0xC0, 0xFF}}},
	{{{40, -11, -22},0, {1008, 496},{0xC, 0xA8, 0xA6, 0xFF}}},
	{{{17, -11, -15},0, {1264, 496},{0xB9, 0xAC, 0xC0, 0xFF}}},
	{{{29, 43, -22},0, {1008, 752},{0xE7, 0x56, 0xA5, 0xFF}}},
	{{{62, -1, -19},0, {752, 496},{0x63, 0xD3, 0xBE, 0xFF}}},
	{{{52, 43, -19},0, {752, 752},{0x47, 0x52, 0xBE, 0xFF}}},
	{{{17, -11, -15},0, {752, 496},{0xB9, 0xAC, 0xC0, 0xFF}}},
	{{{39, -11, 20},0, {1264, 368},{0x19, 0xA6, 0x57, 0xFF}}},
	{{{14, -12, 20},0, {1264, 496},{0xBC, 0xAF, 0x47, 0xFF}}},
	{{{40, -11, -22},0, {752, 368},{0xC, 0xA8, 0xA6, 0xFF}}},
	{{{60, -2, 16},0, {1264, 240},{0x60, 0xD2, 0x45, 0xFF}}},
	{{{62, -1, -19},0, {752, 240},{0x63, 0xD3, 0xBE, 0xFF}}},
	{{{60, -2, 16},0, {1776, 496},{0x60, 0xD2, 0x45, 0xFF}}},
	{{{52, 43, -19},0, {1264, 240},{0x47, 0x52, 0xBE, 0xFF}}},
	{{{51, 43, 16},0, {1776, 240},{0x44, 0x52, 0x45, 0xFF}}},
	{{{62, -1, -19},0, {1264, 496},{0x63, 0xD3, 0xBE, 0xFF}}},
};

Gfx mario_001_switch_vanish_006_switch_option_left_hand_wing_cap_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_006_switch_option_left_hand_wing_cap_mesh_layer_5_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(4, 7, 8, 0, 4, 8, 9, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 13, 11, 0),
	gsSP2Triangles(14, 13, 10, 0, 14, 15, 13, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 19, 17, 0),
	gsSP2Triangles(19, 20, 17, 0, 19, 21, 20, 0),
	gsSP2Triangles(22, 23, 24, 0, 22, 25, 23, 0),
	gsSP2Triangles(25, 26, 23, 0, 25, 27, 26, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 31, 29, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_006_switch_option_left_hand_wing_cap_wings_mesh_layer_4_vtx_0[8] = {
	{{{4, 126, 44},0, {-16, 1996},{0x62, 0x4A, 0x21, 0xFF}}},
	{{{-17, 215, -93},0, {-16, -16},{0x62, 0x4A, 0x21, 0xFF}}},
	{{{-69, 265, -54},0, {974, -16},{0x62, 0x4A, 0x21, 0xFF}}},
	{{{-47, 175, 83},0, {974, 1996},{0x62, 0x4A, 0x21, 0xFF}}},
	{{{-110, -133, -162},0, {974, -16},{0x50, 0x9E, 0xF3, 0xFF}}},
	{{{-48, -80, -174},0, {-16, -16},{0x50, 0x9E, 0xF3, 0xFF}}},
	{{{-17, -78, -12},0, {-16, 1996},{0x50, 0x9E, 0xF3, 0xFF}}},
	{{{-80, -131, 0},0, {974, 1996},{0x50, 0x9E, 0xF3, 0xFF}}},
};

Gfx mario_001_switch_vanish_006_switch_option_left_hand_wing_cap_wings_mesh_layer_4_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_006_switch_option_left_hand_wing_cap_wings_mesh_layer_4_vtx_0 + 0, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_006_switch_option_left_hand_wing_cap_wings_mesh_layer_4_vtx_1[8] = {
	{{{-48, -80, -174},0, {974, -16},{0x50, 0x9E, 0xF3, 0xFF}}},
	{{{45, -27, -25},0, {-16, 1996},{0x4F, 0x9E, 0xF3, 0xFF}}},
	{{{-17, -78, -12},0, {974, 1996},{0x50, 0x9E, 0xF3, 0xFF}}},
	{{{14, -29, -186},0, {-16, -16},{0x50, 0x9E, 0xF3, 0xFF}}},
	{{{4, 126, 44},0, {974, 1996},{0x62, 0x4A, 0x21, 0xFF}}},
	{{{56, 76, 3},0, {-16, 1996},{0x62, 0x4A, 0x21, 0xFF}}},
	{{{-17, 215, -93},0, {974, -16},{0x62, 0x4A, 0x21, 0xFF}}},
	{{{34, 165, -133},0, {-16, -16},{0x62, 0x4A, 0x20, 0xFF}}},
};

Gfx mario_001_switch_vanish_006_switch_option_left_hand_wing_cap_wings_mesh_layer_4_tri_1[] = {
	gsSPVertex(mario_001_switch_vanish_006_switch_option_left_hand_wing_cap_wings_mesh_layer_4_vtx_1 + 0, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 5, 7, 6, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_009_vanish_skinned_mesh_layer_5_vtx_0[8] = {
	{{{-73, 41, 0},0, {2000, 790},{0x8B, 0x31, 0x0, 0xFF}}},
	{{{-73, 41, 0},0, {284, 774},{0x8B, 0x31, 0x0, 0xFF}}},
	{{{-73, 35, 57},0, {1556, 376},{0x96, 0x33, 0x30, 0xFF}}},
	{{{-73, 35, 57},0, {459, 776},{0x96, 0x33, 0x30, 0xFF}}},
	{{{-73, -29, 57},0, {1361, 380},{0xA3, 0xC2, 0x3D, 0xFF}}},
	{{{-73, -32, 0},0, {871, 778},{0x99, 0xB5, 0x0, 0xFF}}},
	{{{-73, -29, 57},0, {697, 778},{0xA3, 0xC2, 0x3D, 0xFF}}},
	{{{-73, -32, 0},0, {1777, 790},{0x99, 0xB5, 0x0, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_009_vanish_skinned_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_009_vanish_skinned_mesh_layer_5_vtx_0 + 0, 8, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_009_vanish_mesh_layer_5_vtx_0[9] = {
	{{{48, -24, 29},0, {436, 848},{0xE6, 0x9F, 0x4E, 0xFF}}},
	{{{48, -22, -20},0, {289, 849},{0xE1, 0xA2, 0xB0, 0xFF}}},
	{{{5, 32, 36},0, {1362, 374},{0xBE, 0x46, 0x53, 0xFF}}},
	{{{48, -24, 29},0, {1526, 304},{0xE6, 0x9F, 0x4E, 0xFF}}},
	{{{5, 32, 36},0, {699, 783},{0xBE, 0x46, 0x53, 0xFF}}},
	{{{5, 35, -21},0, {871, 782},{0xBA, 0x4C, 0xB6, 0xFF}}},
	{{{5, 35, -21},0, {1778, 795},{0xBA, 0x4C, 0xB6, 0xFF}}},
	{{{49, 4, -19},0, {1873, 861},{0x5, 0x2, 0x81, 0xFF}}},
	{{{48, -22, -20},0, {1952, 861},{0xE1, 0xA2, 0xB0, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_009_vanish_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_009_vanish_mesh_layer_5_vtx_0 + 0, 9, 8),
	gsSP2Triangles(1, 8, 3, 0, 1, 9, 8, 0),
	gsSP2Triangles(2, 10, 4, 0, 10, 2, 11, 0),
	gsSP2Triangles(5, 6, 12, 0, 5, 12, 13, 0),
	gsSP2Triangles(0, 7, 14, 0, 15, 0, 14, 0),
	gsSP1Triangle(0, 15, 16, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_009_vanish_mesh_layer_5_vtx_1[10] = {
	{{{5, 35, -21},0, {871, 782},{0xBA, 0x4C, 0xB6, 0xFF}}},
	{{{5, 32, 36},0, {699, 783},{0xBE, 0x46, 0x53, 0xFF}}},
	{{{42, 29, 31},0, {715, 840},{0x15, 0x56, 0x5B, 0xFF}}},
	{{{39, 30, -19},0, {866, 835},{0xD, 0x5A, 0xA7, 0xFF}}},
	{{{5, 32, 36},0, {1362, 374},{0xBE, 0x46, 0x53, 0xFF}}},
	{{{48, -24, 29},0, {1526, 304},{0xE6, 0x9F, 0x4E, 0xFF}}},
	{{{42, 29, 31},0, {1367, 317},{0x15, 0x56, 0x5B, 0xFF}}},
	{{{49, 4, -19},0, {1873, 861},{0x5, 0x2, 0x81, 0xFF}}},
	{{{5, 35, -21},0, {1778, 795},{0xBA, 0x4C, 0xB6, 0xFF}}},
	{{{39, 30, -19},0, {1793, 846},{0xD, 0x5A, 0xA7, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_009_vanish_mesh_layer_5_tri_1[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_009_vanish_mesh_layer_5_vtx_1 + 0, 10, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 7, 8, 9, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_010_vanish_skinned_mesh_layer_5_vtx_0[9] = {
	{{{49, 4, -19},0, {1873, 861},{0x5, 0x2, 0x81, 0xFF}}},
	{{{48, -22, -20},0, {289, 849},{0xE1, 0xA2, 0xB0, 0xFF}}},
	{{{48, -24, 29},0, {1526, 304},{0xE6, 0x9F, 0x4E, 0xFF}}},
	{{{48, -24, 29},0, {436, 848},{0xE6, 0x9F, 0x4E, 0xFF}}},
	{{{48, -22, -20},0, {1952, 861},{0xE1, 0xA2, 0xB0, 0xFF}}},
	{{{39, 30, -19},0, {1793, 846},{0xD, 0x5A, 0xA7, 0xFF}}},
	{{{42, 29, 31},0, {715, 840},{0x15, 0x56, 0x5B, 0xFF}}},
	{{{39, 30, -19},0, {866, 835},{0xD, 0x5A, 0xA7, 0xFF}}},
	{{{42, 29, 31},0, {1367, 317},{0x15, 0x56, 0x5B, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_010_vanish_skinned_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_010_vanish_skinned_mesh_layer_5_vtx_0 + 0, 9, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_010_vanish_mesh_layer_5_vtx_0[11] = {
	{{{3, -23, 28},0, {433, 855},{0x1F, 0xA6, 0x55, 0xFF}}},
	{{{3, -21, -19},0, {289, 856},{0x14, 0xAB, 0xA3, 0xFF}}},
	{{{3, -21, -19},0, {1949, 867},{0x14, 0xAB, 0xA3, 0xFF}}},
	{{{43, -13, -18},0, {1923, 927},{0x18, 0xAD, 0xA3, 0xFF}}},
	{{{35, 27, -17},0, {1801, 917},{0x13, 0x5F, 0xAE, 0xFF}}},
	{{{6, 29, -18},0, {1796, 873},{0xA, 0x5C, 0xA9, 0xFF}}},
	{{{6, 29, -18},0, {864, 861},{0xA, 0x5C, 0xA9, 0xFF}}},
	{{{11, 27, 28},0, {724, 869},{0x15, 0x56, 0x5B, 0xFF}}},
	{{{3, -23, 28},0, {1523, 297},{0x1F, 0xA6, 0x55, 0xFF}}},
	{{{0, 2, 29},0, {1446, 302},{0x14, 0xFE, 0x7D, 0xFF}}},
	{{{11, 27, 28},0, {1370, 288},{0x15, 0x56, 0x5B, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_010_vanish_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_010_vanish_mesh_layer_5_vtx_0 + 0, 11, 9),
	gsSP2Triangles(1, 9, 3, 0, 1, 10, 9, 0),
	gsSP2Triangles(11, 4, 0, 0, 11, 0, 12, 0),
	gsSP2Triangles(12, 0, 13, 0, 13, 0, 14, 0),
	gsSP2Triangles(0, 5, 14, 0, 6, 15, 7, 0),
	gsSP2Triangles(6, 16, 15, 0, 2, 17, 18, 0),
	gsSP2Triangles(2, 18, 8, 0, 18, 19, 8, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_010_vanish_mesh_layer_5_vtx_1[13] = {
	{{{11, 27, 28},0, {724, 869},{0x15, 0x56, 0x5B, 0xFF}}},
	{{{35, 27, -17},0, {859, 905},{0x13, 0x5F, 0xAE, 0xFF}}},
	{{{6, 29, -18},0, {864, 861},{0xA, 0x5C, 0xA9, 0xFF}}},
	{{{43, 24, 23},0, {739, 917},{0x13, 0x5B, 0x57, 0xFF}}},
	{{{43, -16, 21},0, {1496, 236},{0x1F, 0xA1, 0x4E, 0xFF}}},
	{{{0, 2, 29},0, {1446, 302},{0x14, 0xFE, 0x7D, 0xFF}}},
	{{{3, -23, 28},0, {1523, 297},{0x1F, 0xA6, 0x55, 0xFF}}},
	{{{43, 24, 23},0, {1375, 239},{0x13, 0x5B, 0x57, 0xFF}}},
	{{{11, 27, 28},0, {1370, 288},{0x15, 0x56, 0x5B, 0xFF}}},
	{{{3, -21, -19},0, {289, 856},{0x14, 0xAB, 0xA3, 0xFF}}},
	{{{43, -16, 21},0, {413, 917},{0x1F, 0xA1, 0x4E, 0xFF}}},
	{{{3, -23, 28},0, {433, 855},{0x1F, 0xA6, 0x55, 0xFF}}},
	{{{43, -13, -18},0, {293, 917},{0x18, 0xAD, 0xA3, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_010_vanish_mesh_layer_5_tri_1[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_010_vanish_mesh_layer_5_vtx_1 + 0, 13, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 5, 4, 7, 0),
	gsSP2Triangles(5, 7, 8, 0, 9, 10, 11, 0),
	gsSP1Triangle(9, 12, 10, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_011_vanish_skinned_mesh_layer_5_vtx_0[8] = {
	{{{43, 24, 23},0, {739, 917},{0x13, 0x5B, 0x57, 0xFF}}},
	{{{43, -16, 21},0, {1496, 236},{0x1F, 0xA1, 0x4E, 0xFF}}},
	{{{43, 24, 23},0, {1375, 239},{0x13, 0x5B, 0x57, 0xFF}}},
	{{{43, -16, 21},0, {413, 917},{0x1F, 0xA1, 0x4E, 0xFF}}},
	{{{43, -13, -18},0, {1923, 927},{0x18, 0xAD, 0xA3, 0xFF}}},
	{{{35, 27, -17},0, {1801, 917},{0x13, 0x5F, 0xAE, 0xFF}}},
	{{{35, 27, -17},0, {859, 905},{0x13, 0x5F, 0xAE, 0xFF}}},
	{{{43, -13, -18},0, {293, 917},{0x18, 0xAD, 0xA3, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_011_vanish_skinned_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_011_vanish_skinned_mesh_layer_5_vtx_0 + 0, 8, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_011_vanish_mesh_layer_5_vtx_0[8] = {
	{{{36, -9, 22},0, {1428, 152},{0x6E, 0xFE, 0x40, 0xFF}}},
	{{{-11, 8, 25},0, {1382, 223},{0x15, 0x52, 0x5E, 0xFF}}},
	{{{32, -8, -19},0, {291, 1003},{0x67, 0x1, 0xB5, 0xFF}}},
	{{{36, -9, 22},0, {416, 1008},{0x6E, 0xFE, 0x40, 0xFF}}},
	{{{-14, 9, -17},0, {1816, 939},{0x1B, 0x59, 0xA9, 0xFF}}},
	{{{32, -8, -19},0, {1868, 1008},{0x67, 0x1, 0xB5, 0xFF}}},
	{{{-14, 9, -17},0, {860, 929},{0x1B, 0x59, 0xA9, 0xFF}}},
	{{{-11, 8, 25},0, {734, 934},{0x15, 0x52, 0x5E, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_011_vanish_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_011_vanish_mesh_layer_5_vtx_0 + 0, 8, 8),
	gsSP2Triangles(1, 8, 9, 0, 1, 9, 2, 0),
	gsSP2Triangles(3, 10, 11, 0, 3, 7, 10, 0),
	gsSP2Triangles(4, 5, 12, 0, 4, 12, 13, 0),
	gsSP2Triangles(0, 14, 6, 0, 0, 15, 14, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_011_vanish_mesh_layer_5_vtx_1[4] = {
	{{{-11, 8, 25},0, {734, 934},{0x15, 0x52, 0x5E, 0xFF}}},
	{{{36, -9, 22},0, {741, 1008},{0x6E, 0xFE, 0x40, 0xFF}}},
	{{{32, -8, -19},0, {867, 1003},{0x67, 0x1, 0xB5, 0xFF}}},
	{{{-14, 9, -17},0, {860, 929},{0x1B, 0x59, 0xA9, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_011_vanish_mesh_layer_5_tri_1[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_011_vanish_mesh_layer_5_vtx_1 + 0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_012_vanish_skinned_mesh_layer_5_vtx_0[8] = {
	{{{-73, 41, 0},0, {1809, 392},{0x8B, 0x31, 0x0, 0xFF}}},
	{{{-73, 41, 0},0, {284, 774},{0x8B, 0x31, 0x0, 0xFF}}},
	{{{-73, 35, -57},0, {1352, 385},{0x96, 0x33, 0xD0, 0xFF}}},
	{{{-73, 35, -57},0, {111, 776},{0x96, 0x33, 0xD0, 0xFF}}},
	{{{-73, -29, -57},0, {1157, 382},{0xA3, 0xC2, 0xC3, 0xFF}}},
	{{{-73, -32, 0},0, {871, 778},{0x99, 0xB5, 0x0, 0xFF}}},
	{{{-73, -29, -57},0, {1046, 778},{0xA3, 0xC2, 0xC3, 0xFF}}},
	{{{-73, -32, 0},0, {2032, 392},{0x99, 0xB5, 0x0, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_012_vanish_skinned_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_012_vanish_skinned_mesh_layer_5_vtx_0 + 0, 8, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_012_vanish_mesh_layer_5_vtx_0[9] = {
	{{{48, -24, -29},0, {134, 848},{0xE6, 0x9F, 0xB2, 0xFF}}},
	{{{48, -22, 20},0, {281, 849},{0xE1, 0xA2, 0x50, 0xFF}}},
	{{{5, 32, -36},0, {1157, 387},{0xBE, 0x46, 0xAD, 0xFF}}},
	{{{48, -24, -29},0, {1322, 457},{0xE6, 0x9F, 0xB2, 0xFF}}},
	{{{5, 32, -36},0, {1044, 783},{0xBE, 0x46, 0xAD, 0xFF}}},
	{{{5, 35, 21},0, {872, 782},{0xBA, 0x4C, 0x4A, 0xFF}}},
	{{{5, 35, 21},0, {2031, 396},{0xBA, 0x4C, 0x4A, 0xFF}}},
	{{{49, 4, 19},0, {1936, 463},{0x5, 0x2, 0x7F, 0xFF}}},
	{{{48, -22, 20},0, {1857, 462},{0xE1, 0xA2, 0x50, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_012_vanish_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_012_vanish_mesh_layer_5_vtx_0 + 0, 9, 8),
	gsSP2Triangles(1, 3, 8, 0, 1, 8, 9, 0),
	gsSP2Triangles(2, 4, 10, 0, 10, 11, 2, 0),
	gsSP2Triangles(5, 12, 6, 0, 5, 13, 12, 0),
	gsSP2Triangles(0, 14, 7, 0, 15, 14, 0, 0),
	gsSP1Triangle(0, 16, 15, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_012_vanish_mesh_layer_5_vtx_1[10] = {
	{{{5, 35, 21},0, {872, 782},{0xBA, 0x4C, 0x4A, 0xFF}}},
	{{{42, 29, -31},0, {1028, 840},{0x15, 0x56, 0xA5, 0xFF}}},
	{{{5, 32, -36},0, {1044, 783},{0xBE, 0x46, 0xAD, 0xFF}}},
	{{{39, 30, 19},0, {877, 835},{0xD, 0x5A, 0x59, 0xFF}}},
	{{{5, 32, -36},0, {1157, 387},{0xBE, 0x46, 0xAD, 0xFF}}},
	{{{42, 29, -31},0, {1163, 444},{0x15, 0x56, 0xA5, 0xFF}}},
	{{{48, -24, -29},0, {1322, 457},{0xE6, 0x9F, 0xB2, 0xFF}}},
	{{{49, 4, 19},0, {1936, 463},{0x5, 0x2, 0x7F, 0xFF}}},
	{{{39, 30, 19},0, {2016, 448},{0xD, 0x5A, 0x59, 0xFF}}},
	{{{5, 35, 21},0, {2031, 396},{0xBA, 0x4C, 0x4A, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_012_vanish_mesh_layer_5_tri_1[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_012_vanish_mesh_layer_5_vtx_1 + 0, 10, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 7, 8, 9, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_013_vanish_skinned_mesh_layer_5_vtx_0[9] = {
	{{{49, 4, 19},0, {1936, 463},{0x5, 0x2, 0x7F, 0xFF}}},
	{{{39, 30, 19},0, {2016, 448},{0xD, 0x5A, 0x59, 0xFF}}},
	{{{42, 29, -31},0, {1028, 840},{0x15, 0x56, 0xA5, 0xFF}}},
	{{{39, 30, 19},0, {877, 835},{0xD, 0x5A, 0x59, 0xFF}}},
	{{{48, -22, 20},0, {281, 849},{0xE1, 0xA2, 0x50, 0xFF}}},
	{{{48, -24, -29},0, {1322, 457},{0xE6, 0x9F, 0xB2, 0xFF}}},
	{{{48, -24, -29},0, {134, 848},{0xE6, 0x9F, 0xB2, 0xFF}}},
	{{{48, -22, 20},0, {1857, 462},{0xE1, 0xA2, 0x50, 0xFF}}},
	{{{42, 29, -31},0, {1163, 444},{0x15, 0x56, 0xA5, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_013_vanish_skinned_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_013_vanish_skinned_mesh_layer_5_vtx_0 + 0, 9, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_013_vanish_mesh_layer_5_vtx_0[11] = {
	{{{6, 29, 18},0, {2013, 474},{0xA, 0x5C, 0x57, 0xFF}}},
	{{{35, 27, 17},0, {2008, 518},{0x13, 0x5F, 0x52, 0xFF}}},
	{{{43, -13, 18},0, {1886, 529},{0x18, 0xAD, 0x5D, 0xFF}}},
	{{{3, -21, 19},0, {1860, 469},{0x14, 0xAB, 0x5D, 0xFF}}},
	{{{6, 29, 18},0, {879, 861},{0xA, 0x5C, 0x57, 0xFF}}},
	{{{11, 27, -28},0, {1019, 869},{0x15, 0x56, 0xA5, 0xFF}}},
	{{{3, -23, -28},0, {136, 855},{0x1F, 0xA6, 0xAB, 0xFF}}},
	{{{3, -21, 19},0, {281, 856},{0x14, 0xAB, 0x5D, 0xFF}}},
	{{{0, 2, -29},0, {1242, 459},{0x14, 0xFE, 0x83, 0xFF}}},
	{{{3, -23, -28},0, {1319, 464},{0x1F, 0xA6, 0xAB, 0xFF}}},
	{{{11, 27, -28},0, {1166, 473},{0x15, 0x56, 0xA5, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_013_vanish_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_013_vanish_mesh_layer_5_vtx_0 + 0, 11, 9),
	gsSP2Triangles(0, 9, 1, 0, 10, 9, 0, 0),
	gsSP2Triangles(11, 10, 0, 0, 12, 11, 0, 0),
	gsSP2Triangles(12, 0, 7, 0, 2, 3, 13, 0),
	gsSP2Triangles(2, 13, 14, 0, 4, 6, 15, 0),
	gsSP2Triangles(4, 15, 16, 0, 5, 17, 18, 0),
	gsSP2Triangles(5, 8, 17, 0, 17, 8, 19, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_offset_013_vanish_mesh_layer_5_vtx_1[13] = {
	{{{11, 27, -28},0, {1019, 869},{0x15, 0x56, 0xA5, 0xFF}}},
	{{{6, 29, 18},0, {879, 861},{0xA, 0x5C, 0x57, 0xFF}}},
	{{{35, 27, 17},0, {884, 905},{0x13, 0x5F, 0x52, 0xFF}}},
	{{{43, 24, -23},0, {1004, 917},{0x13, 0x5B, 0xA9, 0xFF}}},
	{{{43, -16, -21},0, {1292, 525},{0x1F, 0xA1, 0xB2, 0xFF}}},
	{{{3, -23, -28},0, {1319, 464},{0x1F, 0xA6, 0xAB, 0xFF}}},
	{{{0, 2, -29},0, {1242, 459},{0x14, 0xFE, 0x83, 0xFF}}},
	{{{43, 24, -23},0, {1171, 522},{0x13, 0x5B, 0xA9, 0xFF}}},
	{{{11, 27, -28},0, {1166, 473},{0x15, 0x56, 0xA5, 0xFF}}},
	{{{3, -21, 19},0, {281, 856},{0x14, 0xAB, 0x5D, 0xFF}}},
	{{{3, -23, -28},0, {136, 855},{0x1F, 0xA6, 0xAB, 0xFF}}},
	{{{43, -16, -21},0, {157, 917},{0x1F, 0xA1, 0xB2, 0xFF}}},
	{{{43, -13, 18},0, {278, 917},{0x18, 0xAD, 0x5D, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_offset_013_vanish_mesh_layer_5_tri_1[] = {
	gsSPVertex(mario_001_switch_vanish_000_offset_013_vanish_mesh_layer_5_vtx_1 + 0, 13, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 6, 7, 4, 0),
	gsSP2Triangles(6, 8, 7, 0, 9, 10, 11, 0),
	gsSP1Triangle(9, 11, 12, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_displaylist_005_vanish_skinned_mesh_layer_5_vtx_0[8] = {
	{{{43, 24, -23},0, {1004, 917},{0x13, 0x5B, 0xA9, 0xFF}}},
	{{{43, -16, -21},0, {1292, 525},{0x1F, 0xA1, 0xB2, 0xFF}}},
	{{{43, 24, -23},0, {1171, 522},{0x13, 0x5B, 0xA9, 0xFF}}},
	{{{43, -16, -21},0, {157, 917},{0x1F, 0xA1, 0xB2, 0xFF}}},
	{{{43, -13, 18},0, {1886, 529},{0x18, 0xAD, 0x5D, 0xFF}}},
	{{{35, 27, 17},0, {2008, 518},{0x13, 0x5F, 0x52, 0xFF}}},
	{{{35, 27, 17},0, {884, 905},{0x13, 0x5F, 0x52, 0xFF}}},
	{{{43, -13, 18},0, {278, 917},{0x18, 0xAD, 0x5D, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_displaylist_005_vanish_skinned_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_displaylist_005_vanish_skinned_mesh_layer_5_vtx_0 + 0, 8, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_displaylist_005_vanish_mesh_layer_5_vtx_0[8] = {
	{{{-11, 8, -25},0, {1178, 538},{0x15, 0x52, 0xA2, 0xFF}}},
	{{{36, -9, -22},0, {1224, 610},{0x6E, 0xFE, 0xC0, 0xFF}}},
	{{{36, -9, -22},0, {157, 1008},{0x6E, 0xFE, 0xC0, 0xFF}}},
	{{{32, -8, 19},0, {283, 1003},{0x67, 0x1, 0x4B, 0xFF}}},
	{{{-14, 9, 17},0, {1993, 540},{0x1B, 0x59, 0x57, 0xFF}}},
	{{{32, -8, 19},0, {1941, 610},{0x67, 0x1, 0x4B, 0xFF}}},
	{{{-14, 9, 17},0, {883, 929},{0x1B, 0x59, 0x57, 0xFF}}},
	{{{-11, 8, -25},0, {1009, 934},{0x15, 0x52, 0xA2, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_displaylist_005_vanish_mesh_layer_5_tri_0[] = {
	gsSPVertex(mario_001_switch_vanish_000_displaylist_005_vanish_mesh_layer_5_vtx_0 + 0, 8, 8),
	gsSP2Triangles(1, 8, 9, 0, 1, 2, 8, 0),
	gsSP2Triangles(3, 10, 11, 0, 3, 11, 7, 0),
	gsSP2Triangles(4, 12, 5, 0, 4, 13, 12, 0),
	gsSP2Triangles(0, 6, 14, 0, 0, 14, 15, 0),
	gsSPEndDisplayList(),
};

Vtx mario_001_switch_vanish_000_displaylist_005_vanish_mesh_layer_5_vtx_1[4] = {
	{{{-11, 8, -25},0, {1009, 934},{0x15, 0x52, 0xA2, 0xFF}}},
	{{{32, -8, 19},0, {876, 1003},{0x67, 0x1, 0x4B, 0xFF}}},
	{{{36, -9, -22},0, {1001, 1008},{0x6E, 0xFE, 0xC0, 0xFF}}},
	{{{-14, 9, 17},0, {883, 929},{0x1B, 0x59, 0x57, 0xFF}}},
};

Gfx mario_001_switch_vanish_000_displaylist_005_vanish_mesh_layer_5_tri_1[] = {
	gsSPVertex(mario_001_switch_vanish_000_displaylist_005_vanish_mesh_layer_5_vtx_1 + 0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSPEndDisplayList(),
};


Gfx mat_mario_Spamton_Suit_f3d_v4_001[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsSPSetLights1(mario_Spamton_Suit_f3d_v4_001_lights),
	gsSPEndDisplayList(),
};

Gfx mat_mario_Spamton_Hands_f3d_v4_001[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsSPSetLights1(mario_Spamton_Hands_f3d_v4_001_lights),
	gsSPEndDisplayList(),
};

Gfx mat_mario_face_0___eye_open_v4_001[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0),
	gsDPSetTextureConvert(G_TC_CONV),
	gsDPSetTextureFilter(G_TF_POINT),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, mario_Head1_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPSetLights1(mario_face_0___eye_open_v4_001_lights),
	gsSPEndDisplayList(),
};

Gfx mat_revert_mario_face_0___eye_open_v4_001[] = {
	gsDPPipeSync(),
	gsDPSetTextureConvert(G_TC_FILT),
	gsDPSetTextureFilter(G_TF_BILERP),
	gsSPEndDisplayList(),
};

Gfx mat_mario_Spamton_Hair_f3d_v4_001[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsSPSetLights1(mario_Spamton_Hair_f3d_v4_001_lights),
	gsSPEndDisplayList(),
};

Gfx mat_mario_face_1___eye_half_v4_001[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0),
	gsDPSetTextureConvert(G_TC_CONV),
	gsDPSetTextureFilter(G_TF_POINT),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, mario_Head2_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPSetLights1(mario_face_1___eye_half_v4_001_lights),
	gsSPEndDisplayList(),
};

Gfx mat_revert_mario_face_1___eye_half_v4_001[] = {
	gsDPPipeSync(),
	gsDPSetTextureConvert(G_TC_FILT),
	gsDPSetTextureFilter(G_TF_BILERP),
	gsSPEndDisplayList(),
};

Gfx mat_mario_face_2___eye_closed_v4_001[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0),
	gsDPSetTextureConvert(G_TC_CONV),
	gsDPSetTextureFilter(G_TF_POINT),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, mario_Head3_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPSetLights1(mario_face_2___eye_closed_v4_001_lights),
	gsSPEndDisplayList(),
};

Gfx mat_revert_mario_face_2___eye_closed_v4_001[] = {
	gsDPPipeSync(),
	gsDPSetTextureConvert(G_TC_FILT),
	gsDPSetTextureFilter(G_TF_BILERP),
	gsSPEndDisplayList(),
};

Gfx mat_mario_face_7___eye_X_v4_001[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0),
	gsDPSetTextureConvert(G_TC_CONV),
	gsDPSetTextureFilter(G_TF_POINT),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, mario_Head4_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPSetLights1(mario_face_7___eye_X_v4_001_lights),
	gsSPEndDisplayList(),
};

Gfx mat_revert_mario_face_7___eye_X_v4_001[] = {
	gsDPPipeSync(),
	gsDPSetTextureConvert(G_TC_FILT),
	gsDPSetTextureFilter(G_TF_BILERP),
	gsSPEndDisplayList(),
};

Gfx mat_mario_Spamton_Wing2_f3d_v4_001[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0),
	gsSPGeometryMode(G_CULL_BACK, 0),
	gsDPSetTextureConvert(G_TC_CONV),
	gsDPSetTextureFilter(G_TF_POINT),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, mario_neo_wing2_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 2047, 256),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 252),
	gsSPSetLights1(mario_Spamton_Wing2_f3d_v4_001_lights),
	gsSPEndDisplayList(),
};

Gfx mat_revert_mario_Spamton_Wing2_f3d_v4_001[] = {
	gsDPPipeSync(),
	gsSPGeometryMode(0, G_CULL_BACK),
	gsDPSetTextureConvert(G_TC_FILT),
	gsDPSetTextureFilter(G_TF_BILERP),
	gsSPEndDisplayList(),
};

Gfx mat_mario_Spamton_Wing1_f3d_v4_001[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0),
	gsSPGeometryMode(G_CULL_BACK, 0),
	gsDPSetTextureConvert(G_TC_CONV),
	gsDPSetTextureFilter(G_TF_POINT),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, mario_neo_wing1_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 2047, 256),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 252),
	gsSPSetLights1(mario_Spamton_Wing1_f3d_v4_001_lights),
	gsSPEndDisplayList(),
};

Gfx mat_revert_mario_Spamton_Wing1_f3d_v4_001[] = {
	gsDPPipeSync(),
	gsSPGeometryMode(0, G_CULL_BACK),
	gsDPSetTextureConvert(G_TC_FILT),
	gsDPSetTextureFilter(G_TF_BILERP),
	gsSPEndDisplayList(),
};

Gfx mat_mario_pipis_001[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsSPSetLights1(mario_pipis_001_lights),
	gsSPEndDisplayList(),
};

Gfx mat_mario_label_for_the_above_mentioned_pipis_001_layer4[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, TEXEL0, 0, ENVIRONMENT, 0, 0, 0, 0, TEXEL0, TEXEL0, 0, ENVIRONMENT, 0),
	gsDPSetTextureConvert(G_TC_CONV),
	gsDPSetTextureFilter(G_TF_POINT),
	gsDPSetRenderMode(G_RM_AA_ZB_TEX_EDGE, G_RM_AA_ZB_TEX_EDGE2),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b, 48, mario_pipis_label_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 12, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 6, 0),
	gsDPLoadSync(),
	gsDPLoadTile(7, 0, 0, 188, 124),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 12, 0, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 6, 0),
	gsDPSetTileSize(0, 0, 0, 188, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_mario_label_for_the_above_mentioned_pipis_001_layer4[] = {
	gsDPPipeSync(),
	gsDPSetTextureConvert(G_TC_FILT),
	gsDPSetTextureFilter(G_TF_BILERP),
	gsDPSetRenderMode(G_RM_AA_ZB_TEX_EDGE, G_RM_AA_ZB_TEX_EDGE2),
	gsSPEndDisplayList(),
};

Gfx mat_mario_wing_2_v4_001[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0),
	gsSPGeometryMode(G_CULL_BACK, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, mario_wing_2_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 2047, 256),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 252),
	gsSPSetLights1(mario_wing_2_v4_001_lights),
	gsSPEndDisplayList(),
};

Gfx mat_revert_mario_wing_2_v4_001[] = {
	gsDPPipeSync(),
	gsSPGeometryMode(0, G_CULL_BACK),
	gsSPEndDisplayList(),
};

Gfx mat_mario_wing_1_v4_001[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0),
	gsSPGeometryMode(G_CULL_BACK, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, mario_wing1_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 2047, 256),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 252),
	gsSPSetLights1(mario_wing_1_v4_001_lights),
	gsSPEndDisplayList(),
};

Gfx mat_revert_mario_wing_1_v4_001[] = {
	gsDPPipeSync(),
	gsSPGeometryMode(0, G_CULL_BACK),
	gsSPEndDisplayList(),
};

Gfx mat_mario_Spamton_Legs_f3d_v4_001[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsSPSetLights1(mario_Spamton_Legs_f3d_v4_001_lights),
	gsSPEndDisplayList(),
};

Gfx mat_mario_Spamton_Metal_001[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, ENVIRONMENT, 0, 0, 0, TEXEL0, 0, 0, 0, ENVIRONMENT),
	gsSPGeometryMode(0, G_TEXTURE_GEN),
	gsSPTexture(4031, 1983, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, mario_metal_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 6, 0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 2047, 128),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 0, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 6, 0),
	gsDPSetTileSize(0, 0, 0, 252, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_mario_Spamton_Metal_001[] = {
	gsDPPipeSync(),
	gsSPGeometryMode(G_TEXTURE_GEN, 0),
	gsSPEndDisplayList(),
};

Gfx mat_mario_Spamton_Metal_Wing2_001[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0),
	gsSPGeometryMode(G_CULL_BACK, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, mario_neo_wing_metal2_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 2047, 256),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 252),
	gsSPSetLights1(mario_Spamton_Metal_Wing2_001_lights),
	gsSPEndDisplayList(),
};

Gfx mat_revert_mario_Spamton_Metal_Wing2_001[] = {
	gsDPPipeSync(),
	gsSPGeometryMode(0, G_CULL_BACK),
	gsSPEndDisplayList(),
};

Gfx mat_mario_Spamton_Metal_Wing1_001[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0),
	gsSPGeometryMode(G_CULL_BACK, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, mario_neo_wing_metal1_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 2047, 256),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 252),
	gsSPSetLights1(mario_Spamton_Metal_Wing1_001_lights),
	gsSPEndDisplayList(),
};

Gfx mat_revert_mario_Spamton_Metal_Wing1_001[] = {
	gsDPPipeSync(),
	gsSPGeometryMode(0, G_CULL_BACK),
	gsSPEndDisplayList(),
};

Gfx mat_mario_Pipis_Metal_001[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, ENVIRONMENT, 0, 0, 0, TEXEL0, 0, 0, 0, ENVIRONMENT),
	gsSPGeometryMode(0, G_TEXTURE_GEN),
	gsSPTexture(4031, 1983, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, mario_metal_pipis_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 6, 0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 2047, 128),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 0, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 6, 0),
	gsDPSetTileSize(0, 0, 0, 252, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_mario_Pipis_Metal_001[] = {
	gsDPPipeSync(),
	gsSPGeometryMode(G_TEXTURE_GEN, 0),
	gsSPEndDisplayList(),
};

Gfx mat_mario_metalwing2_001[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0),
	gsSPGeometryMode(G_CULL_BACK, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, mario_mario_metal_wing_tip_unused_rgba16_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 2047, 256),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 252),
	gsSPSetLights1(mario_metalwing2_001_lights),
	gsSPEndDisplayList(),
};

Gfx mat_revert_mario_metalwing2_001[] = {
	gsDPPipeSync(),
	gsSPGeometryMode(0, G_CULL_BACK),
	gsSPEndDisplayList(),
};

Gfx mat_mario_metakwing1_001[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0),
	gsSPGeometryMode(G_CULL_BACK, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, mario_mario_metal_wing_unused_rgba16_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 2047, 256),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 252),
	gsSPSetLights1(mario_metakwing1_001_lights),
	gsSPEndDisplayList(),
};

Gfx mat_revert_mario_metakwing1_001[] = {
	gsDPPipeSync(),
	gsSPGeometryMode(0, G_CULL_BACK),
	gsSPEndDisplayList(),
};

Gfx mat_mario_Trans_Metal_001[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, ENVIRONMENT, 0, 0, 0, TEXEL0, 0, 0, 0, ENVIRONMENT),
	gsSPGeometryMode(0, G_TEXTURE_GEN),
	gsSPTexture(4031, 1983, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, mario_gold_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 6, 0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 2047, 128),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 0, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 6, 0),
	gsDPSetTileSize(0, 0, 0, 252, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_mario_Trans_Metal_001[] = {
	gsDPPipeSync(),
	gsSPGeometryMode(G_TEXTURE_GEN, 0),
	gsSPEndDisplayList(),
};

Gfx mat_mario_Trans_Wing2_001[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0),
	gsSPGeometryMode(G_CULL_BACK, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, mario_neo_wing_gold2_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 2047, 256),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 252),
	gsSPSetLights1(mario_Trans_Wing2_001_lights),
	gsSPEndDisplayList(),
};

Gfx mat_revert_mario_Trans_Wing2_001[] = {
	gsDPPipeSync(),
	gsSPGeometryMode(0, G_CULL_BACK),
	gsSPEndDisplayList(),
};

Gfx mat_mario_Trans_Wing1_001[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, ENVIRONMENT, 0),
	gsSPGeometryMode(G_CULL_BACK, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, mario_neo_wing_gold1_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 2047, 256),
	gsDPPipeSync(),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 252),
	gsSPSetLights1(mario_Trans_Wing1_001_lights),
	gsSPEndDisplayList(),
};

Gfx mat_revert_mario_Trans_Wing1_001[] = {
	gsDPPipeSync(),
	gsSPGeometryMode(0, G_CULL_BACK),
	gsSPEndDisplayList(),
};

Gfx mario_000_offset_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Suit_f3d_v4_001),
	gsSPDisplayList(mario_000_offset_mesh_layer_1_tri_0),
	gsSPEndDisplayList(),
};

Gfx mario_000_offset_001_skinned_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Suit_f3d_v4_001),
	gsSPDisplayList(mario_000_offset_001_skinned_mesh_layer_1_tri_0),
	gsSPEndDisplayList(),
};

Gfx mario_000_offset_001_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Suit_f3d_v4_001),
	gsSPDisplayList(mario_000_offset_001_mesh_layer_1_tri_0),
	gsSPDisplayList(mario_000_offset_001_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_mario_Spamton_Hands_f3d_v4_001),
	gsSPDisplayList(mario_000_offset_001_mesh_layer_1_tri_2),
	gsSPEndDisplayList(),
};

Gfx mario_000_displaylist_mesh_layer_4[] = {
	gsSPDisplayList(mat_mario_face_0___eye_open_v4_001),
	gsSPDisplayList(mario_000_displaylist_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_mario_face_0___eye_open_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_000_displaylist_mesh_layer_4_mat_override_face_1___eye_half_v4_001_0[] = {
	gsSPDisplayList(mat_mario_face_1___eye_half_v4_001),
	gsSPDisplayList(mario_000_displaylist_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_mario_face_1___eye_half_v4_001),
	gsSPDisplayList(mat_revert_mario_face_1___eye_half_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_000_displaylist_mesh_layer_4_mat_override_face_2___eye_closed_v4_001_1[] = {
	gsSPDisplayList(mat_mario_face_2___eye_closed_v4_001),
	gsSPDisplayList(mario_000_displaylist_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_mario_face_2___eye_closed_v4_001),
	gsSPDisplayList(mat_revert_mario_face_2___eye_closed_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_000_displaylist_mesh_layer_4_mat_override_face_7___eye_X_v4_001_2[] = {
	gsSPDisplayList(mat_mario_face_7___eye_X_v4_001),
	gsSPDisplayList(mario_000_displaylist_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_mario_face_7___eye_X_v4_001),
	gsSPDisplayList(mat_revert_mario_face_7___eye_X_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_000_displaylist_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Hair_f3d_v4_001),
	gsSPDisplayList(mario_000_displaylist_mesh_layer_1_tri_0),
	gsSPEndDisplayList(),
};

Gfx mario_000_displaylist_mesh_layer_1_mat_override_face_1___eye_half_v4_001_0[] = {
	gsSPDisplayList(mat_mario_Spamton_Hair_f3d_v4_001),
	gsSPDisplayList(mario_000_displaylist_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_face_1___eye_half_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_000_displaylist_mesh_layer_1_mat_override_face_2___eye_closed_v4_001_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Hair_f3d_v4_001),
	gsSPDisplayList(mario_000_displaylist_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_face_2___eye_closed_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_000_displaylist_mesh_layer_1_mat_override_face_7___eye_X_v4_001_2[] = {
	gsSPDisplayList(mat_mario_Spamton_Hair_f3d_v4_001),
	gsSPDisplayList(mario_000_displaylist_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_face_7___eye_X_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_002_switch_option_head__no_cap__mesh_layer_4[] = {
	gsSPDisplayList(mat_mario_face_0___eye_open_v4_001),
	gsSPDisplayList(mario_002_switch_option_head__no_cap__mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_mario_face_0___eye_open_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_002_switch_option_head__no_cap__mesh_layer_4_mat_override_face_1___eye_half_v4_001_0[] = {
	gsSPDisplayList(mat_mario_face_1___eye_half_v4_001),
	gsSPDisplayList(mario_002_switch_option_head__no_cap__mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_mario_face_1___eye_half_v4_001),
	gsSPDisplayList(mat_revert_mario_face_1___eye_half_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_002_switch_option_head__no_cap__mesh_layer_4_mat_override_face_2___eye_closed_v4_001_1[] = {
	gsSPDisplayList(mat_mario_face_2___eye_closed_v4_001),
	gsSPDisplayList(mario_002_switch_option_head__no_cap__mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_mario_face_2___eye_closed_v4_001),
	gsSPDisplayList(mat_revert_mario_face_2___eye_closed_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_002_switch_option_head__no_cap__mesh_layer_4_mat_override_face_7___eye_X_v4_001_2[] = {
	gsSPDisplayList(mat_mario_face_7___eye_X_v4_001),
	gsSPDisplayList(mario_002_switch_option_head__no_cap__mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_mario_face_7___eye_X_v4_001),
	gsSPDisplayList(mat_revert_mario_face_7___eye_X_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_002_switch_option_head__no_cap__mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Hair_f3d_v4_001),
	gsSPDisplayList(mario_002_switch_option_head__no_cap__mesh_layer_1_tri_0),
	gsSPEndDisplayList(),
};

Gfx mario_002_switch_option_head__no_cap__mesh_layer_1_mat_override_face_1___eye_half_v4_001_0[] = {
	gsSPDisplayList(mat_mario_Spamton_Hair_f3d_v4_001),
	gsSPDisplayList(mario_002_switch_option_head__no_cap__mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_face_1___eye_half_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_002_switch_option_head__no_cap__mesh_layer_1_mat_override_face_2___eye_closed_v4_001_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Hair_f3d_v4_001),
	gsSPDisplayList(mario_002_switch_option_head__no_cap__mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_face_2___eye_closed_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_002_switch_option_head__no_cap__mesh_layer_1_mat_override_face_7___eye_X_v4_001_2[] = {
	gsSPDisplayList(mat_mario_Spamton_Hair_f3d_v4_001),
	gsSPDisplayList(mario_002_switch_option_head__no_cap__mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_face_7___eye_X_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_000_displaylist_001_mesh_layer_4[] = {
	gsSPDisplayList(mat_mario_Spamton_Wing2_f3d_v4_001),
	gsSPDisplayList(mario_000_displaylist_001_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Wing2_f3d_v4_001),
	gsSPDisplayList(mat_mario_Spamton_Wing1_f3d_v4_001),
	gsSPDisplayList(mario_000_displaylist_001_mesh_layer_4_tri_1),
	gsSPDisplayList(mat_revert_mario_Spamton_Wing1_f3d_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_000_displaylist_002_mesh_layer_4[] = {
	gsSPDisplayList(mat_mario_Spamton_Wing2_f3d_v4_001),
	gsSPDisplayList(mario_000_displaylist_002_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Wing2_f3d_v4_001),
	gsSPDisplayList(mat_mario_Spamton_Wing1_f3d_v4_001),
	gsSPDisplayList(mario_000_displaylist_002_mesh_layer_4_tri_1),
	gsSPDisplayList(mat_revert_mario_Spamton_Wing1_f3d_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_000_offset_003_skinned_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Suit_f3d_v4_001),
	gsSPDisplayList(mario_000_offset_003_skinned_mesh_layer_1_tri_0),
	gsSPEndDisplayList(),
};

Gfx mario_000_offset_003_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Suit_f3d_v4_001),
	gsSPDisplayList(mario_000_offset_003_mesh_layer_1_tri_0),
	gsSPDisplayList(mario_000_offset_003_mesh_layer_1_tri_1),
	gsSPEndDisplayList(),
};

Gfx mario_000_offset_004_skinned_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Suit_f3d_v4_001),
	gsSPDisplayList(mario_000_offset_004_skinned_mesh_layer_1_tri_0),
	gsSPEndDisplayList(),
};

Gfx mario_000_offset_004_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Suit_f3d_v4_001),
	gsSPDisplayList(mario_000_offset_004_mesh_layer_1_tri_0),
	gsSPDisplayList(mario_000_offset_004_mesh_layer_1_tri_1),
	gsSPEndDisplayList(),
};

Gfx mario_000_displaylist_003_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Hands_f3d_v4_001),
	gsSPDisplayList(mario_000_displaylist_003_mesh_layer_1_tri_0),
	gsSPEndDisplayList(),
};

Gfx mario_002_switch_option_right_hand_open_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Hands_f3d_v4_001),
	gsSPDisplayList(mario_002_switch_option_right_hand_open_mesh_layer_1_tri_0),
	gsSPEndDisplayList(),
};

Gfx mario_000_offset_006_skinned_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Suit_f3d_v4_001),
	gsSPDisplayList(mario_000_offset_006_skinned_mesh_layer_1_tri_0),
	gsSPEndDisplayList(),
};

Gfx mario_000_offset_006_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Suit_f3d_v4_001),
	gsSPDisplayList(mario_000_offset_006_mesh_layer_1_tri_0),
	gsSPDisplayList(mario_000_offset_006_mesh_layer_1_tri_1),
	gsSPEndDisplayList(),
};

Gfx mario_000_offset_007_skinned_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Suit_f3d_v4_001),
	gsSPDisplayList(mario_000_offset_007_skinned_mesh_layer_1_tri_0),
	gsSPEndDisplayList(),
};

Gfx mario_000_offset_007_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Suit_f3d_v4_001),
	gsSPDisplayList(mario_000_offset_007_mesh_layer_1_tri_0),
	gsSPDisplayList(mario_000_offset_007_mesh_layer_1_tri_1),
	gsSPEndDisplayList(),
};

Gfx mario_000_displaylist_004_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Hands_f3d_v4_001),
	gsSPDisplayList(mario_000_displaylist_004_mesh_layer_1_tri_0),
	gsSPEndDisplayList(),
};

Gfx mario_002_switch_option_left_hand_open_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Hands_f3d_v4_001),
	gsSPDisplayList(mario_002_switch_option_left_hand_open_mesh_layer_1_tri_0),
	gsSPEndDisplayList(),
};

Gfx mario_004_switch_option_left_hand_peace_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_pipis_001),
	gsSPDisplayList(mario_004_switch_option_left_hand_peace_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_mario_Spamton_Hands_f3d_v4_001),
	gsSPDisplayList(mario_004_switch_option_left_hand_peace_mesh_layer_1_tri_1),
	gsSPEndDisplayList(),
};

Gfx mario_004_switch_option_left_hand_peace_mesh_layer_4[] = {
	gsSPDisplayList(mat_mario_label_for_the_above_mentioned_pipis_001_layer4),
	gsSPDisplayList(mario_004_switch_option_left_hand_peace_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_mario_label_for_the_above_mentioned_pipis_001_layer4),
	gsSPEndDisplayList(),
};

Gfx mario_005_switch_option_left_hand_cap_mesh_layer_4[] = {
	gsSPDisplayList(mat_mario_face_0___eye_open_v4_001),
	gsSPDisplayList(mario_005_switch_option_left_hand_cap_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_mario_face_0___eye_open_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_005_switch_option_left_hand_cap_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Hands_f3d_v4_001),
	gsSPDisplayList(mario_005_switch_option_left_hand_cap_mesh_layer_1_tri_0),
	gsSPEndDisplayList(),
};

Gfx mario_006_switch_option_left_hand_wing_cap_mesh_layer_4[] = {
	gsSPDisplayList(mat_mario_face_0___eye_open_v4_001),
	gsSPDisplayList(mario_006_switch_option_left_hand_wing_cap_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_mario_face_0___eye_open_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_006_switch_option_left_hand_wing_cap_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Hands_f3d_v4_001),
	gsSPDisplayList(mario_006_switch_option_left_hand_wing_cap_mesh_layer_1_tri_0),
	gsSPEndDisplayList(),
};

Gfx mario_006_switch_option_left_hand_wing_cap_wings_mesh_layer_4[] = {
	gsSPDisplayList(mat_mario_wing_2_v4_001),
	gsSPDisplayList(mario_006_switch_option_left_hand_wing_cap_wings_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_mario_wing_2_v4_001),
	gsSPDisplayList(mat_mario_wing_1_v4_001),
	gsSPDisplayList(mario_006_switch_option_left_hand_wing_cap_wings_mesh_layer_4_tri_1),
	gsSPDisplayList(mat_revert_mario_wing_1_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_000_offset_009_skinned_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Legs_f3d_v4_001),
	gsSPDisplayList(mario_000_offset_009_skinned_mesh_layer_1_tri_0),
	gsSPEndDisplayList(),
};

Gfx mario_000_offset_009_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Legs_f3d_v4_001),
	gsSPDisplayList(mario_000_offset_009_mesh_layer_1_tri_0),
	gsSPDisplayList(mario_000_offset_009_mesh_layer_1_tri_1),
	gsSPEndDisplayList(),
};

Gfx mario_000_offset_010_skinned_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Legs_f3d_v4_001),
	gsSPDisplayList(mario_000_offset_010_skinned_mesh_layer_1_tri_0),
	gsSPEndDisplayList(),
};

Gfx mario_000_offset_010_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Legs_f3d_v4_001),
	gsSPDisplayList(mario_000_offset_010_mesh_layer_1_tri_0),
	gsSPDisplayList(mario_000_offset_010_mesh_layer_1_tri_1),
	gsSPEndDisplayList(),
};

Gfx mario_000_offset_011_skinned_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Legs_f3d_v4_001),
	gsSPDisplayList(mario_000_offset_011_skinned_mesh_layer_1_tri_0),
	gsSPEndDisplayList(),
};

Gfx mario_000_offset_011_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Legs_f3d_v4_001),
	gsSPDisplayList(mario_000_offset_011_mesh_layer_1_tri_0),
	gsSPDisplayList(mario_000_offset_011_mesh_layer_1_tri_1),
	gsSPEndDisplayList(),
};

Gfx mario_000_offset_012_skinned_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Legs_f3d_v4_001),
	gsSPDisplayList(mario_000_offset_012_skinned_mesh_layer_1_tri_0),
	gsSPEndDisplayList(),
};

Gfx mario_000_offset_012_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Legs_f3d_v4_001),
	gsSPDisplayList(mario_000_offset_012_mesh_layer_1_tri_0),
	gsSPDisplayList(mario_000_offset_012_mesh_layer_1_tri_1),
	gsSPEndDisplayList(),
};

Gfx mario_000_offset_013_skinned_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Legs_f3d_v4_001),
	gsSPDisplayList(mario_000_offset_013_skinned_mesh_layer_1_tri_0),
	gsSPEndDisplayList(),
};

Gfx mario_000_offset_013_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Legs_f3d_v4_001),
	gsSPDisplayList(mario_000_offset_013_mesh_layer_1_tri_0),
	gsSPDisplayList(mario_000_offset_013_mesh_layer_1_tri_1),
	gsSPEndDisplayList(),
};

Gfx mario_000_displaylist_005_skinned_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Legs_f3d_v4_001),
	gsSPDisplayList(mario_000_displaylist_005_skinned_mesh_layer_1_tri_0),
	gsSPEndDisplayList(),
};

Gfx mario_000_displaylist_005_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Legs_f3d_v4_001),
	gsSPDisplayList(mario_000_displaylist_005_mesh_layer_1_tri_0),
	gsSPDisplayList(mario_000_displaylist_005_mesh_layer_1_tri_1),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_offset_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_offset_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_offset_001_skinned_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_offset_001_skinned_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_offset_001_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_offset_001_mesh_layer_1_tri_0),
	gsSPDisplayList(mario_001_switch_000_offset_001_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_displaylist_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_displaylist_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_displaylist_mesh_layer_1_mat_override_face_1___eye_half_v4_001_0[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_displaylist_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPDisplayList(mat_revert_mario_face_1___eye_half_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_displaylist_mesh_layer_1_mat_override_face_2___eye_closed_v4_001_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_displaylist_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPDisplayList(mat_revert_mario_face_2___eye_closed_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_displaylist_mesh_layer_1_mat_override_face_7___eye_X_v4_001_2[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_displaylist_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPDisplayList(mat_revert_mario_face_7___eye_X_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_002_switch_option_head__no_cap__mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_002_switch_option_head__no_cap__mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_002_switch_option_head__no_cap__mesh_layer_1_mat_override_face_1___eye_half_v4_001_0[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_002_switch_option_head__no_cap__mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPDisplayList(mat_revert_mario_face_1___eye_half_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_002_switch_option_head__no_cap__mesh_layer_1_mat_override_face_2___eye_closed_v4_001_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_002_switch_option_head__no_cap__mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPDisplayList(mat_revert_mario_face_2___eye_closed_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_002_switch_option_head__no_cap__mesh_layer_1_mat_override_face_7___eye_X_v4_001_2[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_002_switch_option_head__no_cap__mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPDisplayList(mat_revert_mario_face_7___eye_X_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_displaylist_001_mesh_layer_4[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_Wing2_001),
	gsSPDisplayList(mario_001_switch_000_displaylist_001_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_Wing2_001),
	gsSPDisplayList(mat_mario_Spamton_Metal_Wing1_001),
	gsSPDisplayList(mario_001_switch_000_displaylist_001_mesh_layer_4_tri_1),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_Wing1_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_displaylist_002_mesh_layer_4[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_Wing2_001),
	gsSPDisplayList(mario_001_switch_000_displaylist_002_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_Wing2_001),
	gsSPDisplayList(mat_mario_Spamton_Metal_Wing1_001),
	gsSPDisplayList(mario_001_switch_000_displaylist_002_mesh_layer_4_tri_1),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_Wing1_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_offset_003_skinned_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_offset_003_skinned_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_offset_003_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_offset_003_mesh_layer_1_tri_0),
	gsSPDisplayList(mario_001_switch_000_offset_003_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_offset_004_skinned_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_offset_004_skinned_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_offset_004_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_offset_004_mesh_layer_1_tri_0),
	gsSPDisplayList(mario_001_switch_000_offset_004_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_displaylist_003_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_displaylist_003_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_002_switch_option_right_hand_open_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_002_switch_option_right_hand_open_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_offset_006_skinned_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_offset_006_skinned_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_offset_006_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_offset_006_mesh_layer_1_tri_0),
	gsSPDisplayList(mario_001_switch_000_offset_006_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_offset_007_skinned_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_offset_007_skinned_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_offset_007_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_offset_007_mesh_layer_1_tri_0),
	gsSPDisplayList(mario_001_switch_000_offset_007_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_displaylist_004_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_displaylist_004_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_002_switch_option_left_hand_open_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_002_switch_option_left_hand_open_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_004_switch_option_left_hand_peace_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Pipis_Metal_001),
	gsSPDisplayList(mario_001_switch_004_switch_option_left_hand_peace_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Pipis_Metal_001),
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_004_switch_option_left_hand_peace_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_004_switch_option_left_hand_peace_mesh_layer_4[] = {
	gsSPDisplayList(mat_mario_label_for_the_above_mentioned_pipis_001_layer4),
	gsSPDisplayList(mario_001_switch_004_switch_option_left_hand_peace_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_mario_label_for_the_above_mentioned_pipis_001_layer4),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_005_switch_option_left_hand_cap_mesh_layer_4[] = {
	gsSPDisplayList(mat_mario_face_0___eye_open_v4_001),
	gsSPDisplayList(mario_001_switch_005_switch_option_left_hand_cap_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_mario_face_0___eye_open_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_005_switch_option_left_hand_cap_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_005_switch_option_left_hand_cap_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_006_switch_option_left_hand_wing_cap_mesh_layer_4[] = {
	gsSPDisplayList(mat_mario_face_0___eye_open_v4_001),
	gsSPDisplayList(mario_001_switch_006_switch_option_left_hand_wing_cap_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_mario_face_0___eye_open_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_006_switch_option_left_hand_wing_cap_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_006_switch_option_left_hand_wing_cap_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_006_switch_option_left_hand_wing_cap_wings_mesh_layer_4[] = {
	gsSPDisplayList(mat_mario_metalwing2_001),
	gsSPDisplayList(mario_001_switch_006_switch_option_left_hand_wing_cap_wings_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_mario_metalwing2_001),
	gsSPDisplayList(mat_mario_metakwing1_001),
	gsSPDisplayList(mario_001_switch_006_switch_option_left_hand_wing_cap_wings_mesh_layer_4_tri_1),
	gsSPDisplayList(mat_revert_mario_metakwing1_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_offset_009_skinned_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_offset_009_skinned_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_offset_009_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_offset_009_mesh_layer_1_tri_0),
	gsSPDisplayList(mario_001_switch_000_offset_009_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_offset_010_skinned_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_offset_010_skinned_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_offset_010_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_offset_010_mesh_layer_1_tri_0),
	gsSPDisplayList(mario_001_switch_000_offset_010_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_offset_011_skinned_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_offset_011_skinned_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_offset_011_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_offset_011_mesh_layer_1_tri_0),
	gsSPDisplayList(mario_001_switch_000_offset_011_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_offset_012_skinned_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_offset_012_skinned_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_offset_012_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_offset_012_mesh_layer_1_tri_0),
	gsSPDisplayList(mario_001_switch_000_offset_012_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_offset_013_skinned_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_offset_013_skinned_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_offset_013_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_offset_013_mesh_layer_1_tri_0),
	gsSPDisplayList(mario_001_switch_000_offset_013_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_displaylist_005_skinned_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_displaylist_005_skinned_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_000_displaylist_005_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Spamton_Metal_001),
	gsSPDisplayList(mario_001_switch_000_displaylist_005_mesh_layer_1_tri_0),
	gsSPDisplayList(mario_001_switch_000_displaylist_005_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_mario_Spamton_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_offset_vanish_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_vanish_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_offset_001_vanish_skinned_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_001_vanish_skinned_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_offset_001_vanish_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_001_vanish_mesh_layer_5_tri_0),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_001_vanish_mesh_layer_5_tri_1),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_displaylist_vanish_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_displaylist_vanish_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_displaylist_vanish_mesh_layer_5_mat_override_face_1___eye_half_v4_001_0[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_displaylist_vanish_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPDisplayList(mat_revert_mario_face_1___eye_half_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_displaylist_vanish_mesh_layer_5_mat_override_face_2___eye_closed_v4_001_1[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_displaylist_vanish_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPDisplayList(mat_revert_mario_face_2___eye_closed_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_displaylist_vanish_mesh_layer_5_mat_override_face_7___eye_X_v4_001_2[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_displaylist_vanish_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPDisplayList(mat_revert_mario_face_7___eye_X_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_002_switch_option_head__no_cap__mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_002_switch_option_head__no_cap__mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_002_switch_option_head__no_cap__mesh_layer_5_mat_override_face_1___eye_half_v4_001_0[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_002_switch_option_head__no_cap__mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPDisplayList(mat_revert_mario_face_1___eye_half_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_002_switch_option_head__no_cap__mesh_layer_5_mat_override_face_2___eye_closed_v4_001_1[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_002_switch_option_head__no_cap__mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPDisplayList(mat_revert_mario_face_2___eye_closed_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_002_switch_option_head__no_cap__mesh_layer_5_mat_override_face_7___eye_X_v4_001_2[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_002_switch_option_head__no_cap__mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPDisplayList(mat_revert_mario_face_7___eye_X_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_displaylist_001_vanish_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Wing2_001),
	gsSPDisplayList(mario_001_switch_vanish_000_displaylist_001_vanish_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Wing2_001),
	gsSPDisplayList(mat_mario_Trans_Wing1_001),
	gsSPDisplayList(mario_001_switch_vanish_000_displaylist_001_vanish_mesh_layer_5_tri_1),
	gsSPDisplayList(mat_revert_mario_Trans_Wing1_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_displaylist_002_vanish_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Wing2_001),
	gsSPDisplayList(mario_001_switch_vanish_000_displaylist_002_vanish_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Wing2_001),
	gsSPDisplayList(mat_mario_Trans_Wing1_001),
	gsSPDisplayList(mario_001_switch_vanish_000_displaylist_002_vanish_mesh_layer_5_tri_1),
	gsSPDisplayList(mat_revert_mario_Trans_Wing1_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_offset_003_vanish_skinned_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_003_vanish_skinned_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_offset_003_vanish_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_003_vanish_mesh_layer_5_tri_0),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_003_vanish_mesh_layer_5_tri_1),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_offset_004_vanish_skinned_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_004_vanish_skinned_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_offset_004_vanish_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_004_vanish_mesh_layer_5_tri_0),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_004_vanish_mesh_layer_5_tri_1),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_displaylist_003_vanish_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_displaylist_003_vanish_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_002_switch_option_right_hand_open_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_002_switch_option_right_hand_open_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_offset_006_vanish_skinned_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_006_vanish_skinned_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_offset_006_vanish_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_006_vanish_mesh_layer_5_tri_0),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_006_vanish_mesh_layer_5_tri_1),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_offset_007_vanish_skinned_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_007_vanish_skinned_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_offset_007_vanish_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_007_vanish_mesh_layer_5_tri_0),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_007_vanish_mesh_layer_5_tri_1),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_displaylist_004_vanish_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_displaylist_004_vanish_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_002_switch_option_left_hand_open_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_002_switch_option_left_hand_open_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_004_switch_option_left_hand_peace_mesh_layer_1[] = {
	gsSPDisplayList(mat_mario_Pipis_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_004_switch_option_left_hand_peace_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_mario_Pipis_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_004_switch_option_left_hand_peace_mesh_layer_4[] = {
	gsSPDisplayList(mat_mario_label_for_the_above_mentioned_pipis_001_layer4),
	gsSPDisplayList(mario_001_switch_vanish_004_switch_option_left_hand_peace_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_mario_label_for_the_above_mentioned_pipis_001_layer4),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_004_switch_option_left_hand_peace_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_004_switch_option_left_hand_peace_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_005_switch_option_left_hand_cap_mesh_layer_4[] = {
	gsSPDisplayList(mat_mario_face_0___eye_open_v4_001),
	gsSPDisplayList(mario_001_switch_vanish_005_switch_option_left_hand_cap_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_mario_face_0___eye_open_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_005_switch_option_left_hand_cap_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_005_switch_option_left_hand_cap_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_006_switch_option_left_hand_wing_cap_mesh_layer_4[] = {
	gsSPDisplayList(mat_mario_face_0___eye_open_v4_001),
	gsSPDisplayList(mario_001_switch_vanish_006_switch_option_left_hand_wing_cap_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_mario_face_0___eye_open_v4_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_006_switch_option_left_hand_wing_cap_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_006_switch_option_left_hand_wing_cap_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_006_switch_option_left_hand_wing_cap_wings_mesh_layer_4[] = {
	gsSPDisplayList(mat_mario_metalwing2_001),
	gsSPDisplayList(mario_001_switch_vanish_006_switch_option_left_hand_wing_cap_wings_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_mario_metalwing2_001),
	gsSPDisplayList(mat_mario_metakwing1_001),
	gsSPDisplayList(mario_001_switch_vanish_006_switch_option_left_hand_wing_cap_wings_mesh_layer_4_tri_1),
	gsSPDisplayList(mat_revert_mario_metakwing1_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_offset_009_vanish_skinned_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_009_vanish_skinned_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_offset_009_vanish_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_009_vanish_mesh_layer_5_tri_0),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_009_vanish_mesh_layer_5_tri_1),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_offset_010_vanish_skinned_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_010_vanish_skinned_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_offset_010_vanish_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_010_vanish_mesh_layer_5_tri_0),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_010_vanish_mesh_layer_5_tri_1),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_offset_011_vanish_skinned_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_011_vanish_skinned_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_offset_011_vanish_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_011_vanish_mesh_layer_5_tri_0),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_011_vanish_mesh_layer_5_tri_1),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_offset_012_vanish_skinned_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_012_vanish_skinned_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_offset_012_vanish_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_012_vanish_mesh_layer_5_tri_0),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_012_vanish_mesh_layer_5_tri_1),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_offset_013_vanish_skinned_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_013_vanish_skinned_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_offset_013_vanish_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_013_vanish_mesh_layer_5_tri_0),
	gsSPDisplayList(mario_001_switch_vanish_000_offset_013_vanish_mesh_layer_5_tri_1),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_displaylist_005_vanish_skinned_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_displaylist_005_vanish_skinned_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_001_switch_vanish_000_displaylist_005_vanish_mesh_layer_5[] = {
	gsSPDisplayList(mat_mario_Trans_Metal_001),
	gsSPDisplayList(mario_001_switch_vanish_000_displaylist_005_vanish_mesh_layer_5_tri_0),
	gsSPDisplayList(mario_001_switch_vanish_000_displaylist_005_vanish_mesh_layer_5_tri_1),
	gsSPDisplayList(mat_revert_mario_Trans_Metal_001),
	gsSPEndDisplayList(),
};

Gfx mario_material_revert_render_settings[] = {
	gsDPPipeSync(),
	gsSPSetGeometryMode(G_LIGHTING),
	gsSPClearGeometryMode(G_TEXTURE_GEN),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPSetEnvColor(255, 255, 255, 255),
	gsDPSetAlphaCompare(G_AC_NONE),
	gsSPEndDisplayList(),
};

